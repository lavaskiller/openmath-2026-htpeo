import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog00
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_180 : RB (Real.log ((3365523 : ℝ) / 3200000)) ((50432564691 : ℝ) / 1000000000000) ((12608141173 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3365523 : ℝ) / 3200000)) (t := ((165523 : ℝ) / 6565523))
    (lo := ((50432564691 : ℝ) / 1000000000000)) (hi := ((12608141173 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_181 : RB (Real.log ((51150624999 : ℝ) / 1000000000000)) ((-743245141929 : ℝ) / 250000000000) ((-1486490283857 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((51150624999 : ℝ) / 62500000000)) (t := ((-11349375001 : ℝ) / 113650624999))
    (lo := ((-50097961369 : ℝ) / 250000000000)) (hi := ((-8015673819 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51150624999 : ℝ) / 1000000000000) = Real.log ((51150624999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((51150624999 : ℝ) / 1000000000000) = ((51150624999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_182 : RB (Real.log ((165523 : ℝ) / 3200000)) ((-1480897965409 : ℝ) / 500000000000) ((-46278061419 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((165523 : ℝ) / 200000)) (t := ((-34477 : ℝ) / 365523))
    (lo := ((-94603604289 : ℝ) / 500000000000)) (hi := ((-189207208577 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((165523 : ℝ) / 3200000) = Real.log ((165523 : ℝ) / 200000) - 4 * Real.log 2 := by
    rw [show ((165523 : ℝ) / 3200000) = ((165523 : ℝ) / 200000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_183 : RB (Real.log ((692678838729 : ℝ) / 1000000000000)) ((-36718882339 : ℝ) / 100000000000) ((-91797205847 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((692678838729 : ℝ) / 1000000000000)) (t := ((-307321161271 : ℝ) / 1692678838729))
    (lo := ((-36718882339 : ℝ) / 100000000000)) (hi := ((-91797205847 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_184 : RB (Real.log ((692779290681 : ℝ) / 1000000000000)) ((-183521907193 : ℝ) / 500000000000) ((-22940238399 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((692779290681 : ℝ) / 1000000000000)) (t := ((-307220709319 : ℝ) / 1692779290681))
    (lo := ((-183521907193 : ℝ) / 500000000000)) (hi := ((-22940238399 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_185 : RB (Real.log ((205400574353 : ℝ) / 500000000000)) ((-444823002333 : ℝ) / 500000000000) ((-111205750583 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((205400574353 : ℝ) / 250000000000)) (t := ((-44599425647 : ℝ) / 455400574353))
    (lo := ((-98249412053 : ℝ) / 500000000000)) (hi := ((-39299764821 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((205400574353 : ℝ) / 500000000000) = Real.log ((205400574353 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((205400574353 : ℝ) / 500000000000) = ((205400574353 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_186 : RB (Real.log ((1652176001489 : ℝ) / 500000000000)) ((597620194207 : ℝ) / 500000000000) ((18675631069 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((1652176001489 : ℝ) / 2000000000000)) (t := ((-347823998511 : ℝ) / 3652176001489))
    (lo := ((-38210794541 : ℝ) / 200000000000)) (hi := ((-5970436647 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1652176001489 : ℝ) / 500000000000) = Real.log ((1652176001489 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1652176001489 : ℝ) / 500000000000) = ((1652176001489 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_187 : RB (Real.log ((3304488754647 : ℝ) / 1000000000000)) ((1195281772879 : ℝ) / 1000000000000) ((1195281772881 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3304488754647 : ℝ) / 4000000000000)) (t := ((-695511245353 : ℝ) / 7304488754647))
    (lo := ((-2387657353 : ℝ) / 12500000000)) (hi := ((-191012588239 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3304488754647 : ℝ) / 1000000000000) = Real.log ((3304488754647 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3304488754647 : ℝ) / 1000000000000) = ((3304488754647 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_188 : RB (Real.log ((1432800382103 : ℝ) / 1000000000000)) ((179815419223 : ℝ) / 500000000000) ((22476927403 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((1432800382103 : ℝ) / 2000000000000)) (t := ((-567199617897 : ℝ) / 3432800382103))
    (lo := ((-333516342113 : ℝ) / 1000000000000)) (hi := ((-10422385691 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1432800382103 : ℝ) / 1000000000000) = Real.log ((1432800382103 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1432800382103 : ℝ) / 1000000000000) = ((1432800382103 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_189 : RB (Real.log ((1051725937499 : ℝ) / 1000000000000)) ((5043256469 : ℝ) / 100000000000) ((50432564691 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1051725937499 : ℝ) / 1000000000000)) (t := ((51725937499 : ℝ) / 2051725937499))
    (lo := ((5043256469 : ℝ) / 100000000000)) (hi := ((50432564691 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_190 : RB (Real.log ((841841 : ℝ) / 800000)) ((25489716319 : ℝ) / 500000000000) ((50979432639 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((841841 : ℝ) / 800000)) (t := ((41841 : ℝ) / 1641841))
    (lo := ((25489716319 : ℝ) / 500000000000)) (hi := ((50979432639 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_191 : RB (Real.log ((51725937499 : ℝ) / 1000000000000)) ((-2961795930837 : ℝ) / 1000000000000) ((-592359186167 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((51725937499 : ℝ) / 62500000000)) (t := ((-10774062501 : ℝ) / 114225937499))
    (lo := ((-189207208597 : ℝ) / 1000000000000)) (hi := ((-47301802149 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51725937499 : ℝ) / 1000000000000) = Real.log ((51725937499 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((51725937499 : ℝ) / 1000000000000) = ((51725937499 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_192 : RB (Real.log ((41841 : ℝ) / 800000)) ((-368841875953 : ℝ) / 125000000000) ((-1475367503811 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((41841 : ℝ) / 50000)) (t := ((-8159 : ℝ) / 91841))
    (lo := ((-22268285673 : ℝ) / 125000000000)) (hi := ((-178146285383 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41841 : ℝ) / 800000) = Real.log ((41841 : ℝ) / 50000) - 4 * Real.log 2 := by
    rw [show ((41841 : ℝ) / 800000) = ((41841 : ℝ) / 50000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_193 : RB (Real.log ((172242227839 : ℝ) / 250000000000)) ((-372559130387 : ℝ) / 1000000000000) ((-23284945649 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((172242227839 : ℝ) / 250000000000)) (t := ((-77757772161 : ℝ) / 422242227839))
    (lo := ((-372559130387 : ℝ) / 1000000000000)) (hi := ((-23284945649 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_194 : RB (Real.log ((172267567567 : ℝ) / 250000000000)) ((-46551503049 : ℝ) / 125000000000) ((-37241202439 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((172267567567 : ℝ) / 250000000000)) (t := ((-77732432433 : ℝ) / 422267567567))
    (lo := ((-46551503049 : ℝ) / 125000000000)) (hi := ((-37241202439 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_195 : RB (Real.log ((409542370767 : ℝ) / 1000000000000)) ((-446357455763 : ℝ) / 500000000000) ((-223178727881 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((409542370767 : ℝ) / 500000000000)) (t := ((-90457629233 : ℝ) / 909542370767))
    (lo := ((-99783865483 : ℝ) / 500000000000)) (hi := ((-39913546193 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((409542370767 : ℝ) / 1000000000000) = Real.log ((409542370767 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((409542370767 : ℝ) / 1000000000000) = ((409542370767 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_196 : RB (Real.log ((1651292006567 : ℝ) / 500000000000)) ((1194705196343 : ℝ) / 1000000000000) ((238941039269 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1651292006567 : ℝ) / 2000000000000)) (t := ((-348707993433 : ℝ) / 3651292006567))
    (lo := ((-23948645597 : ℝ) / 125000000000)) (hi := ((-7663566591 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1651292006567 : ℝ) / 500000000000) = Real.log ((1651292006567 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1651292006567 : ℝ) / 500000000000) = ((1651292006567 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_197 : RB (Real.log ((6605444393 : ℝ) / 2000000000)) ((298686759113 : ℝ) / 250000000000) ((597373518227 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((6605444393 : ℝ) / 8000000000)) (t := ((-1394555607 : ℝ) / 14605444393))
    (lo := ((-191547324667 : ℝ) / 1000000000000)) (hi := ((-95773662333 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((6605444393 : ℝ) / 2000000000) = Real.log ((6605444393 : ℝ) / 8000000000) + 2 * Real.log 2 := by
    rw [show ((6605444393 : ℝ) / 2000000000) = ((6605444393 : ℝ) / 8000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_198 : RB (Real.log ((716553353441 : ℝ) / 500000000000)) ((359844610051 : ℝ) / 1000000000000) ((359844610053 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((716553353441 : ℝ) / 1000000000000)) (t := ((-283446646559 : ℝ) / 1716553353441))
    (lo := ((-83325642627 : ℝ) / 250000000000)) (hi := ((-333302570507 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((716553353441 : ℝ) / 500000000000) = Real.log ((716553353441 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((716553353441 : ℝ) / 500000000000) = ((716553353441 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_199 : RB (Real.log ((1052301249999 : ℝ) / 1000000000000)) ((50979432637 : ℝ) / 1000000000000) ((25489716319 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1052301249999 : ℝ) / 1000000000000)) (t := ((52301249999 : ℝ) / 2052301249999))
    (lo := ((50979432637 : ℝ) / 1000000000000)) (hi := ((25489716319 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_200 : RB (Real.log ((673841 : ℝ) / 640000)) ((12881500421 : ℝ) / 250000000000) ((10305200337 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((673841 : ℝ) / 640000)) (t := ((33841 : ℝ) / 1313841))
    (lo := ((12881500421 : ℝ) / 250000000000)) (hi := ((10305200337 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_201 : RB (Real.log ((52301249999 : ℝ) / 1000000000000)) ((-2950735007643 : ℝ) / 1000000000000) ((-2950735007641 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((52301249999 : ℝ) / 62500000000)) (t := ((-10198750001 : ℝ) / 114801249999))
    (lo := ((-178146285403 : ℝ) / 1000000000000)) (hi := ((-89073142701 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((52301249999 : ℝ) / 1000000000000) = Real.log ((52301249999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((52301249999 : ℝ) / 1000000000000) = ((52301249999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_202 : RB (Real.log ((33841 : ℝ) / 640000)) ((-1469897545613 : ℝ) / 500000000000) ((-367474386403 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((33841 : ℝ) / 40000)) (t := ((-6159 : ℝ) / 73841))
    (lo := ((-83603184493 : ℝ) / 500000000000)) (hi := ((-33441273797 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33841 : ℝ) / 640000) = Real.log ((33841 : ℝ) / 40000) - 4 * Real.log 2 := by
    rw [show ((33841 : ℝ) / 640000) = ((33841 : ℝ) / 40000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_203 : RB (Real.log ((34262893643 : ℝ) / 50000000000)) ((-377960054833 : ℝ) / 1000000000000) ((-377960054831 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((34262893643 : ℝ) / 50000000000)) (t := ((-15737106357 : ℝ) / 84262893643))
    (lo := ((-377960054833 : ℝ) / 1000000000000)) (hi := ((-377960054831 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_204 : RB (Real.log ((685360133917 : ℝ) / 1000000000000)) ((-377810835931 : ℝ) / 1000000000000) ((-47226354491 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((685360133917 : ℝ) / 1000000000000)) (t := ((-314639866083 : ℝ) / 1685360133917))
    (lo := ((-377810835931 : ℝ) / 1000000000000)) (hi := ((-47226354491 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_205 : RB (Real.log ((408278053349 : ℝ) / 1000000000000)) ((-89580683339 : ℝ) / 100000000000) ((-223951708347 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((408278053349 : ℝ) / 500000000000)) (t := ((-91721946651 : ℝ) / 908278053349))
    (lo := ((-20265965283 : ℝ) / 100000000000)) (hi := ((-202659652829 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((408278053349 : ℝ) / 1000000000000) = Real.log ((408278053349 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((408278053349 : ℝ) / 1000000000000) = ((408278053349 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_206 : RB (Real.log ((3300800770847 : ℝ) / 1000000000000)) ((1194165096867 : ℝ) / 1000000000000) ((1194165096869 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3300800770847 : ℝ) / 4000000000000)) (t := ((-699199229153 : ℝ) / 7300800770847))
    (lo := ((-48032316063 : ℝ) / 250000000000)) (hi := ((-192129264251 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3300800770847 : ℝ) / 1000000000000) = Real.log ((3300800770847 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3300800770847 : ℝ) / 1000000000000) = ((3300800770847 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_207 : RB (Real.log ((412617547863 : ℝ) / 125000000000)) ((1194207392393 : ℝ) / 1000000000000) ((238841478479 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((412617547863 : ℝ) / 500000000000)) (t := ((-87382452137 : ℝ) / 912617547863))
    (lo := ((-96043484363 : ℝ) / 500000000000)) (hi := ((-7683478749 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((412617547863 : ℝ) / 125000000000) = Real.log ((412617547863 : ℝ) / 500000000000) + 2 * Real.log 2 := by
    rw [show ((412617547863 : ℝ) / 125000000000) = ((412617547863 : ℝ) / 500000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_208 : RB (Real.log ((14334160879 : ℝ) / 10000000000)) ((360060468107 : ℝ) / 1000000000000) ((36006046811 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((14334160879 : ℝ) / 20000000000)) (t := ((-5665839121 : ℝ) / 34334160879))
    (lo := ((-83271678113 : ℝ) / 250000000000)) (hi := ((-6661734249 : ℝ) / 20000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14334160879 : ℝ) / 10000000000) = Real.log ((14334160879 : ℝ) / 20000000000) + 1 * Real.log 2 := by
    rw [show ((14334160879 : ℝ) / 10000000000) = ((14334160879 : ℝ) / 20000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_209 : RB (Real.log ((1052876562499 : ℝ) / 1000000000000)) ((51526001683 : ℝ) / 1000000000000) ((12881500421 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1052876562499 : ℝ) / 1000000000000)) (t := ((52876562499 : ℝ) / 2052876562499))
    (lo := ((51526001683 : ℝ) / 1000000000000)) (hi := ((12881500421 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_210 : RB (Real.log ((1685523 : ℝ) / 1600000)) ((10414454431 : ℝ) / 200000000000) ((13018068039 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1685523 : ℝ) / 1600000)) (t := ((85523 : ℝ) / 3285523))
    (lo := ((10414454431 : ℝ) / 200000000000)) (hi := ((13018068039 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_211 : RB (Real.log ((52876562499 : ℝ) / 1000000000000)) ((-587959018249 : ℝ) / 200000000000) ((-2939795091243 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((52876562499 : ℝ) / 62500000000)) (t := ((-9623437501 : ℝ) / 115376562499))
    (lo := ((-33441273801 : ℝ) / 200000000000)) (hi := ((-41801592251 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((52876562499 : ℝ) / 1000000000000) = Real.log ((52876562499 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((52876562499 : ℝ) / 1000000000000) = ((52876562499 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_212 : RB (Real.log ((85523 : ℝ) / 1600000)) ((-1464486781307 : ℝ) / 500000000000) ((-732243390653 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((85523 : ℝ) / 100000)) (t := ((-14477 : ℝ) / 185523))
    (lo := ((-78192420187 : ℝ) / 500000000000)) (hi := ((-156384840373 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((85523 : ℝ) / 1600000) = Real.log ((85523 : ℝ) / 100000) - 4 * Real.log 2 := by
    rw [show ((85523 : ℝ) / 1600000) = ((85523 : ℝ) / 100000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_213 : RB (Real.log ((85193220873 : ℝ) / 125000000000)) ((-95847968463 : ℝ) / 250000000000) ((-383391873849 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((85193220873 : ℝ) / 125000000000)) (t := ((-39806779127 : ℝ) / 210193220873))
    (lo := ((-95847968463 : ℝ) / 250000000000)) (hi := ((-383391873849 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_214 : RB (Real.log ((681648925373 : ℝ) / 1000000000000)) ((-383240525861 : ℝ) / 1000000000000) ((-191620262929 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((681648925373 : ℝ) / 1000000000000)) (t := ((-318351074627 : ℝ) / 1681648925373))
    (lo := ((-383240525861 : ℝ) / 1000000000000)) (hi := ((-191620262929 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_215 : RB (Real.log ((407008172697 : ℝ) / 1000000000000)) ((-179784402681 : ℝ) / 200000000000) ((-898922013403 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((407008172697 : ℝ) / 500000000000)) (t := ((-92991827303 : ℝ) / 907008172697))
    (lo := ((-41154966569 : ℝ) / 200000000000)) (hi := ((-51443708211 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((407008172697 : ℝ) / 1000000000000) = Real.log ((407008172697 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((407008172697 : ℝ) / 1000000000000) = ((407008172697 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_216 : RB (Real.log ((3299002557067 : ℝ) / 1000000000000)) ((298405041837 : ℝ) / 250000000000) ((23872403347 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((3299002557067 : ℝ) / 4000000000000)) (t := ((-700997442933 : ℝ) / 7299002557067))
    (lo := ((-192674193771 : ℝ) / 1000000000000)) (hi := ((-19267419377 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3299002557067 : ℝ) / 1000000000000) = Real.log ((3299002557067 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3299002557067 : ℝ) / 1000000000000) = ((3299002557067 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_217 : RB (Real.log ((1649571797399 : ℝ) / 500000000000)) ((1193662918063 : ℝ) / 1000000000000) ((238732583613 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1649571797399 : ℝ) / 2000000000000)) (t := ((-350428202601 : ℝ) / 3649571797399))
    (lo := ((-12039465191 : ℝ) / 62500000000)) (hi := ((-38526288611 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1649571797399 : ℝ) / 500000000000) = Real.log ((1649571797399 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1649571797399 : ℝ) / 500000000000) = ((1649571797399 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_218 : RB (Real.log ((716864242711 : ℝ) / 500000000000)) ((360278383539 : ℝ) / 1000000000000) ((360278383541 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((716864242711 : ℝ) / 1000000000000)) (t := ((-283135757289 : ℝ) / 1716864242711))
    (lo := ((-16643439851 : ℝ) / 50000000000)) (hi := ((-332868797019 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((716864242711 : ℝ) / 500000000000) = Real.log ((716864242711 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((716864242711 : ℝ) / 500000000000) = ((716864242711 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_219 : RB (Real.log ((1053451874999 : ℝ) / 1000000000000)) ((26036136077 : ℝ) / 500000000000) ((10414454431 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1053451874999 : ℝ) / 1000000000000)) (t := ((53451874999 : ℝ) / 2053451874999))
    (lo := ((26036136077 : ℝ) / 500000000000)) (hi := ((10414454431 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_220 : RB (Real.log ((3372887 : ℝ) / 3200000)) ((26309122189 : ℝ) / 500000000000) ((52618244379 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3372887 : ℝ) / 3200000)) (t := ((172887 : ℝ) / 6572887))
    (lo := ((26309122189 : ℝ) / 500000000000)) (hi := ((52618244379 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_221 : RB (Real.log ((53451874999 : ℝ) / 1000000000000)) ((-366121695329 : ℝ) / 125000000000) ((-292897356263 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((53451874999 : ℝ) / 62500000000)) (t := ((-9048125001 : ℝ) / 115951874999))
    (lo := ((-19548105049 : ℝ) / 125000000000)) (hi := ((-156384840391 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((53451874999 : ℝ) / 1000000000000) = Real.log ((53451874999 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((53451874999 : ℝ) / 1000000000000) = ((53451874999 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_222 : RB (Real.log ((172887 : ℝ) / 3200000)) ((-182391742931 : ℝ) / 62500000000) ((-1459133943447 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((172887 : ℝ) / 200000)) (t := ((-27113 : ℝ) / 372887))
    (lo := ((-9104947791 : ℝ) / 62500000000)) (hi := ((-29135832931 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((172887 : ℝ) / 3200000) = Real.log ((172887 : ℝ) / 200000) - 4 * Real.log 2 := by
    rw [show ((172887 : ℝ) / 3200000) = ((172887 : ℝ) / 200000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_223 : RB (Real.log ((677832636051 : ℝ) / 1000000000000)) ((-194427435499 : ℝ) / 500000000000) ((-194427435497 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((677832636051 : ℝ) / 1000000000000)) (t := ((-322167363949 : ℝ) / 1677832636051))
    (lo := ((-194427435499 : ℝ) / 500000000000)) (hi := ((-194427435497 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_224 : RB (Real.log ((677936686957 : ℝ) / 1000000000000)) ((-388701377473 : ℝ) / 1000000000000) ((-38870137747 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((677936686957 : ℝ) / 1000000000000)) (t := ((-322063313043 : ℝ) / 1677936686957))
    (lo := ((-388701377473 : ℝ) / 1000000000000)) (hi := ((-38870137747 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_225 : RB (Real.log ((405732704451 : ℝ) / 1000000000000)) ((-902060699619 : ℝ) / 1000000000000) ((-902060699617 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((405732704451 : ℝ) / 500000000000)) (t := ((-94267295549 : ℝ) / 905732704451))
    (lo := ((-208913519059 : ℝ) / 1000000000000)) (hi := ((-104456759529 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((405732704451 : ℝ) / 1000000000000) = Real.log ((405732704451 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((405732704451 : ℝ) / 1000000000000) = ((405732704451 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_226 : RB (Real.log ((3297189645913 : ℝ) / 1000000000000)) ((74566905199 : ℝ) / 62500000000) ((596535241593 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3297189645913 : ℝ) / 4000000000000)) (t := ((-702810354087 : ℝ) / 7297189645913))
    (lo := ((-38644775587 : ℝ) / 200000000000)) (hi := ((-96611938967 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3297189645913 : ℝ) / 1000000000000) = Real.log ((3297189645913 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3297189645913 : ℝ) / 1000000000000) = ((3297189645913 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_227 : RB (Real.log ((1648666053143 : ℝ) / 500000000000)) ((149139211107 : ℝ) / 125000000000) ((596556844429 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1648666053143 : ℝ) / 2000000000000)) (t := ((-351333946857 : ℝ) / 3648666053143))
    (lo := ((-193180672263 : ℝ) / 1000000000000)) (hi := ((-96590336131 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1648666053143 : ℝ) / 500000000000) = Real.log ((1648666053143 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1648666053143 : ℝ) / 500000000000) = ((1648666053143 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_228 : RB (Real.log ((1434043860847 : ℝ) / 1000000000000)) ((360498328073 : ℝ) / 1000000000000) ((14419933123 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((1434043860847 : ℝ) / 2000000000000)) (t := ((-565956139153 : ℝ) / 3434043860847))
    (lo := ((-166324426243 : ℝ) / 500000000000)) (hi := ((-66529770497 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1434043860847 : ℝ) / 1000000000000) = Real.log ((1434043860847 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1434043860847 : ℝ) / 1000000000000) = ((1434043860847 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_229 : RB (Real.log ((1054027187499 : ℝ) / 1000000000000)) ((52618244377 : ℝ) / 1000000000000) ((26309122189 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1054027187499 : ℝ) / 1000000000000)) (t := ((54027187499 : ℝ) / 2054027187499))
    (lo := ((52618244377 : ℝ) / 1000000000000)) (hi := ((26309122189 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_230 : RB (Real.log ((421841 : ℝ) / 400000)) ((26581959339 : ℝ) / 500000000000) ((53163918679 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((421841 : ℝ) / 400000)) (t := ((21841 : ℝ) / 821841))
    (lo := ((26581959339 : ℝ) / 500000000000)) (hi := ((53163918679 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_231 : RB (Real.log ((54027187499 : ℝ) / 1000000000000)) ((-1459133943457 : ℝ) / 500000000000) ((-45597935733 : ℝ) / 15625000000) := by
  have hm := log_bounds_of_series (x := ((54027187499 : ℝ) / 62500000000)) (t := ((-8472812501 : ℝ) / 116527187499))
    (lo := ((-72839582337 : ℝ) / 500000000000)) (hi := ((-145679164673 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((54027187499 : ℝ) / 1000000000000) = Real.log ((54027187499 : ℝ) / 62500000000) - 4 * Real.log 2 := by
    rw [show ((54027187499 : ℝ) / 1000000000000) = ((54027187499 : ℝ) / 62500000000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_232 : RB (Real.log ((21841 : ℝ) / 400000)) ((-1453837804867 : ℝ) / 500000000000) ((-726918902433 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((21841 : ℝ) / 25000)) (t := ((-3159 : ℝ) / 46841))
    (lo := ((-67543443747 : ℝ) / 500000000000)) (hi := ((-135086887493 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21841 : ℝ) / 400000) = Real.log ((21841 : ℝ) / 25000) - 4 * Real.log 2 := by
    rw [show ((21841 : ℝ) / 400000) = ((21841 : ℝ) / 25000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_233 : RB (Real.log ((26964740839 : ℝ) / 40000000000)) ((-394349336387 : ℝ) / 1000000000000) ((-394349336383 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((26964740839 : ℝ) / 40000000000)) (t := ((-13035259161 : ℝ) / 66964740839))
    (lo := ((-394349336387 : ℝ) / 1000000000000)) (hi := ((-394349336383 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_234 : RB (Real.log ((134844691917 : ℝ) / 200000000000)) ((-394193680609 : ℝ) / 1000000000000) ((-78838736121 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((134844691917 : ℝ) / 200000000000)) (t := ((-65155308083 : ℝ) / 334844691917))
    (lo := ((-394193680609 : ℝ) / 1000000000000)) (hi := ((-78838736121 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_235 : RB (Real.log ((80890324729 : ℝ) / 200000000000)) ((-36208925803 : ℝ) / 40000000000) ((-905223145073 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((80890324729 : ℝ) / 100000000000)) (t := ((-19109675271 : ℝ) / 180890324729))
    (lo := ((-42415192903 : ℝ) / 200000000000)) (hi := ((-106037982257 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((80890324729 : ℝ) / 200000000000) = Real.log ((80890324729 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((80890324729 : ℝ) / 200000000000) = ((80890324729 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_236 : RB (Real.log ((411920288113 : ℝ) / 125000000000)) ((1192516117873 : ℝ) / 1000000000000) ((9540128943 : ℝ) / 8000000000) := by
  have hm := log_bounds_of_series (x := ((411920288113 : ℝ) / 500000000000)) (t := ((-88079711887 : ℝ) / 911920288113))
    (lo := ((-96889121623 : ℝ) / 500000000000)) (hi := ((-38755648649 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((411920288113 : ℝ) / 125000000000) = Real.log ((411920288113 : ℝ) / 500000000000) + 2 * Real.log 2 := by
    rw [show ((411920288113 : ℝ) / 125000000000) = ((411920288113 : ℝ) / 500000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_237 : RB (Real.log ((3295506184877 : ℝ) / 1000000000000)) ((37267493071 : ℝ) / 31250000000) ((596279889137 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3295506184877 : ℝ) / 4000000000000)) (t := ((-704493815123 : ℝ) / 7295506184877))
    (lo := ((-193734582847 : ℝ) / 1000000000000)) (hi := ((-96867291423 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3295506184877 : ℝ) / 1000000000000) = Real.log ((3295506184877 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3295506184877 : ℝ) / 1000000000000) = ((3295506184877 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_238 : RB (Real.log ((286872435333 : ℝ) / 200000000000)) ((36072027421 : ℝ) / 100000000000) ((90180068553 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((286872435333 : ℝ) / 400000000000)) (t := ((-113127564667 : ℝ) / 686872435333))
    (lo := ((-332426906349 : ℝ) / 1000000000000)) (hi := ((-83106726587 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((286872435333 : ℝ) / 200000000000) = Real.log ((286872435333 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((286872435333 : ℝ) / 200000000000) = ((286872435333 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_239 : RB (Real.log ((1054602499999 : ℝ) / 1000000000000)) ((53163918677 : ℝ) / 1000000000000) ((26581959339 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1054602499999 : ℝ) / 1000000000000)) (t := ((54602499999 : ℝ) / 2054602499999))
    (lo := ((53163918677 : ℝ) / 1000000000000)) (hi := ((26581959339 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
