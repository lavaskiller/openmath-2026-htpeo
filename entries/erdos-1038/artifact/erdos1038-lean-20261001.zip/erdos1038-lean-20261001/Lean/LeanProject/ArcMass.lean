import LeanProject.ArcLink

/-!
# EP-1038, Stage 12, Theorem 12.8 step 3: the mass term

* `conv_Kl_one`: `(K * g)(θ) = log 2 · ∫ g - (𝓛 * g)(θ)` (`K = log|1 - e^{i·}| = log 2 - 𝓛` a.e.).
* `conv_Lsin_bounds`: `0 ≤ (𝓛 * g)(θ) ≤ ∫_𝕋 𝓛` for `0 ≤ g ≤ 1`.
* `IK_Kl_one`: `I_K(f, g) = 4QR log 2 - I_𝓛(f, g)` for masses `2Q`, `2R`.
* `circle_block_K` (**Theorem 12.8, step 3**, the paper's form):
  `∬ f(θ) g(φ) K(θ - φ) ≥ 4QR 𝒜(Q, R)`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

theorem ii_mul_bdd {F G : ℝ → ℝ} {a b : ℝ} (hF : IntervalIntegrable F volume a b)
    (hG : Measurable G) (hb : ∀ x, |G x| ≤ 1) :
    IntervalIntegrable (fun x => F x * G x) volume a b :=
  ⟨hF.1.mul_bdd hG.aestronglyMeasurable
      (Eventually.of_forall fun x => by rw [Real.norm_eq_abs]; exact hb x),
    hF.2.mul_bdd hG.aestronglyMeasurable
      (Eventually.of_forall fun x => by rw [Real.norm_eq_abs]; exact hb x)⟩

section mass

variable {f g : ℝ → ℝ} (hfm : Measurable f) (hgm : Measurable g)
  (hf0 : ∀ x, 0 ≤ f x) (hf1 : ∀ x, f x ≤ 1) (hg0 : ∀ x, 0 ≤ g x) (hg1 : ∀ x, g x ≤ 1)

include hg0 hg1 in
theorem abs_g_le (x : ℝ) : |g x| ≤ 1 := abs_le.mpr ⟨by linarith [hg0 x], hg1 x⟩

include hgm hg0 hg1 in
/-- `(K * g)(θ) = log 2 · ∫ g - (𝓛 * g)(θ)`. -/
theorem conv_Kl_one (θ : ℝ) :
    Circ.conv (Kl 1) g θ = Real.log 2 * (∫ u in (-π)..π, g u) - Circ.conv Circ.Lsin g θ := by
  have hgb : Circ.Bdd g := ⟨hgm, 1, abs_g_le hg0 hg1⟩
  unfold Circ.conv
  have h : ∫ u in (-π)..π, Kl 1 (θ - u) * g u =
      ∫ u in (-π)..π, (Real.log 2 * g u - Circ.Lsin (θ - u) * g u) := by
    refine intervalIntegral.integral_congr_ae ?_
    filter_upwards [Circ.ae_sin_ne θ] with u hu _
    rw [Kl_one_eq hu]
    ring
  rw [h, intervalIntegral.integral_sub ((hgb.ii _ _).const_mul _)
    (ii_mul_bdd (Circ.Lsin_ii θ _ _) hgm (abs_g_le hg0 hg1)),
    intervalIntegral.integral_const_mul]

include hgm hg0 hg1 in
/-- `0 ≤ (𝓛 * g)(θ) ≤ ∫_𝕋 𝓛`. -/
theorem conv_Lsin_bounds (θ : ℝ) :
    0 ≤ Circ.conv Circ.Lsin g θ ∧
      Circ.conv Circ.Lsin g θ ≤ ∫ s in (-π)..π, Circ.Lsin s := by
  have hπ := Real.pi_pos
  unfold Circ.conv
  constructor
  · exact intervalIntegral.integral_nonneg (by linarith)
      (fun u _ => mul_nonneg (Circ.Lsin_nonneg _) (hg0 u))
  · rw [← Circ.int_Lsin_shift θ]
    refine intervalIntegral.integral_mono_on (by linarith)
      (ii_mul_bdd (Circ.Lsin_ii θ _ _) hgm (abs_g_le hg0 hg1)) (Circ.Lsin_ii θ _ _)
      (fun u _ => ?_)
    calc Circ.Lsin (θ - u) * g u ≤ Circ.Lsin (θ - u) * 1 :=
          mul_le_mul_of_nonneg_left (hg1 u) (Circ.Lsin_nonneg _)
      _ = Circ.Lsin (θ - u) := mul_one _

include hfm hgm hf0 hf1 hg0 hg1 in
/-- `I_K(f, g) = 4QR log 2 - I_𝓛(f, g)`. -/
theorem IK_Kl_one {Q R : ℝ} (hfmass : ∫ θ in (-π)..π, f θ = 2 * Q)
    (hgmass : ∫ θ in (-π)..π, g θ = 2 * R) :
    Circ.IK (Kl 1) f g = 4 * Q * R * Real.log 2 - Circ.IK Circ.Lsin f g := by
  have hfb : Circ.Bdd f := ⟨hfm, 1, fun x => abs_le.mpr ⟨by linarith [hf0 x], hf1 x⟩⟩
  set C := ∫ s in (-π)..π, Circ.Lsin s with hC
  have hC0 : 0 ≤ C := (conv_Lsin_bounds hgm hg0 hg1 0).1.trans (conv_Lsin_bounds hgm hg0 hg1 0).2
  have hprod : Circ.Bdd (fun θ => f θ * Circ.conv Circ.Lsin g θ) := by
    refine ⟨hfm.mul (Circ.conv_measurable Circ.Lsin_measurable hgm), C, fun θ => ?_⟩
    obtain ⟨b0, b1⟩ := conv_Lsin_bounds hgm hg0 hg1 θ
    rw [abs_of_nonneg (mul_nonneg (hf0 θ) b0)]
    calc f θ * Circ.conv Circ.Lsin g θ ≤ 1 * C := mul_le_mul (hf1 θ) b1 b0 zero_le_one
      _ = C := one_mul C
  unfold Circ.IK
  have e : ∀ θ, f θ * Circ.conv (Kl 1) g θ =
      Real.log 2 * (2 * R) * f θ - f θ * Circ.conv Circ.Lsin g θ := by
    intro θ
    rw [conv_Kl_one hgm hg0 hg1, hgmass]
    ring
  simp_rw [e]
  rw [intervalIntegral.integral_sub ((hfb.ii _ _).const_mul _) (hprod.ii _ _),
    intervalIntegral.integral_const_mul, hfmass]
  ring

end mass

/-- **Theorem 12.8, step 3** (the form used in the paper): for measurable `2π`-periodic `f, g`
with values in `[0, 1]` and masses `2Q, 2R > 0`,
`∫_𝕋 f(θ) ∫_𝕋 g(φ) log|1 - e^{i(θ-φ)}| dφ dθ ≥ 4QR 𝒜(Q, R)`. -/
theorem circle_block_K {f g : ℝ → ℝ} (hfm : Measurable f) (hgm : Measurable g)
    (hfp : Function.Periodic f (2 * π)) (hgp : Function.Periodic g (2 * π))
    (hf0 : ∀ x, 0 ≤ f x) (hf1 : ∀ x, f x ≤ 1) (hg0 : ∀ x, 0 ≤ g x) (hg1 : ∀ x, g x ≤ 1)
    {Q R : ℝ} (hQ : 0 < Q) (hR : 0 < R)
    (hfmass : ∫ θ in (-π)..π, f θ = 2 * Q) (hgmass : ∫ θ in (-π)..π, g θ = 2 * R) :
    4 * Q * R * AE Q R ≤ Circ.IK (Kl 1) f g := by
  have h1 := circle_block_log hfm hgm hfp hgp hf0 hf1 hg0 hg1 hQ hR hfmass hgmass
  rw [IK_Kl_one hfm hgm hf0 hf1 hg0 hg1 hfmass hgmass]
  nlinarith [h1]

end EP1038.Arc
