import LeanProject.DLowerArithmetic
import LeanProject.DLowerLog10
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_780 : RB (Real.log ((3593807 : ℝ) / 3200000)) ((116061276501 : ℝ) / 1000000000000) ((58030638251 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((3593807 : ℝ) / 3200000)) (t := ((393807 : ℝ) / 6793807))
    (lo := ((116061276501 : ℝ) / 1000000000000)) (hi := ((58030638251 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_781 : RB (Real.log ((61460429687 : ℝ) / 500000000000)) ((-2096214550417 : ℝ) / 1000000000000) ((-419242910083 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((61460429687 : ℝ) / 62500000000)) (t := ((-1039570313 : ℝ) / 123960429687))
    (lo := ((-16773008737 : ℝ) / 1000000000000)) (hi := ((-524156523 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((61460429687 : ℝ) / 500000000000) = Real.log ((61460429687 : ℝ) / 62500000000) - 3 * Real.log 2 := by
    rw [show ((61460429687 : ℝ) / 500000000000) = ((61460429687 : ℝ) / 62500000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_782 : RB (Real.log ((393807 : ℝ) / 3200000)) ((-2095045147221 : ℝ) / 1000000000000) ((-2095045147219 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((393807 : ℝ) / 400000)) (t := ((-6193 : ℝ) / 793807))
    (lo := ((-15603605541 : ℝ) / 1000000000000)) (hi := ((-780180277 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((393807 : ℝ) / 3200000) = Real.log ((393807 : ℝ) / 400000) - 3 * Real.log 2 := by
    rw [show ((393807 : ℝ) / 3200000) = ((393807 : ℝ) / 400000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_783 : RB (Real.log ((281143723153 : ℝ) / 1000000000000)) ((-126888927011 : ℝ) / 100000000000) ((-317222317527 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((281143723153 : ℝ) / 250000000000)) (t := ((31143723153 : ℝ) / 531143723153))
    (lo := ((11740509101 : ℝ) / 100000000000)) (hi := ((117405091011 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((281143723153 : ℝ) / 1000000000000) = Real.log ((281143723153 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((281143723153 : ℝ) / 1000000000000) = ((281143723153 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_784 : RB (Real.log ((14059487329 : ℝ) / 50000000000)) ((-634362791399 : ℝ) / 500000000000) ((-317181395699 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((14059487329 : ℝ) / 12500000000)) (t := ((1559487329 : ℝ) / 26559487329))
    (lo := ((58784389161 : ℝ) / 500000000000)) (hi := ((117568778323 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((14059487329 : ℝ) / 50000000000) = Real.log ((14059487329 : ℝ) / 12500000000) - 2 * Real.log 2 := by
    rw [show ((14059487329 : ℝ) / 50000000000) = ((14059487329 : ℝ) / 12500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_785 : RB (Real.log ((57817213461 : ℝ) / 250000000000)) ((-1464174375777 : ℝ) / 1000000000000) ((-58566975031 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((57817213461 : ℝ) / 62500000000)) (t := ((-4682786539 : ℝ) / 120317213461))
    (lo := ((-77880014657 : ℝ) / 1000000000000)) (hi := ((-1216875229 : ℝ) / 15625000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((57817213461 : ℝ) / 250000000000) = Real.log ((57817213461 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((57817213461 : ℝ) / 250000000000) = ((57817213461 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_786 : RB (Real.log ((3013285564133 : ℝ) / 1000000000000)) ((551515516499 : ℝ) / 500000000000) ((1103031033 : ℝ) / 1000000000) := by
  have hm := log_bounds_of_series (x := ((3013285564133 : ℝ) / 4000000000000)) (t := ((-986714435867 : ℝ) / 7013285564133))
    (lo := ((-283263328121 : ℝ) / 1000000000000)) (hi := ((-7081583203 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3013285564133 : ℝ) / 1000000000000) = Real.log ((3013285564133 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3013285564133 : ℝ) / 1000000000000) = ((3013285564133 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_787 : RB (Real.log ((1506678944403 : ℝ) / 500000000000)) ((1103055034641 : ℝ) / 1000000000000) ((1103055034643 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1506678944403 : ℝ) / 2000000000000)) (t := ((-493321055597 : ℝ) / 3506678944403))
    (lo := ((-141619663239 : ℝ) / 500000000000)) (hi := ((-283239326477 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1506678944403 : ℝ) / 500000000000) = Real.log ((1506678944403 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1506678944403 : ℝ) / 500000000000) = ((1506678944403 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_788 : RB (Real.log ((297835607649 : ℝ) / 200000000000)) ((79644863111 : ℝ) / 200000000000) ((398224315557 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((297835607649 : ℝ) / 400000000000)) (t := ((-102164392351 : ℝ) / 697835607649))
    (lo := ((-73730716251 : ℝ) / 250000000000)) (hi := ((-294922865003 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((297835607649 : ℝ) / 200000000000) = Real.log ((297835607649 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((297835607649 : ℝ) / 200000000000) = ((297835607649 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_789 : RB (Real.log ((1123064687499 : ℝ) / 1000000000000)) ((232122553 : ℝ) / 2000000000) ((116061276501 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1123064687499 : ℝ) / 1000000000000)) (t := ((123064687499 : ℝ) / 2123064687499))
    (lo := ((232122553 : ℝ) / 2000000000)) (hi := ((116061276501 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_790 : RB (Real.log ((14377069 : ℝ) / 12800000)) ((23237867167 : ℝ) / 200000000000) ((29047333959 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((14377069 : ℝ) / 12800000)) (t := ((1577069 : ℝ) / 27177069))
    (lo := ((23237867167 : ℝ) / 200000000000)) (hi := ((29047333959 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_791 : RB (Real.log ((123064687499 : ℝ) / 1000000000000)) ((-2095045147229 : ℝ) / 1000000000000) ((-2095045147227 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123064687499 : ℝ) / 125000000000)) (t := ((-1935312501 : ℝ) / 248064687499))
    (lo := ((-15603605549 : ℝ) / 1000000000000)) (hi := ((-3900901387 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123064687499 : ℝ) / 1000000000000) = Real.log ((123064687499 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123064687499 : ℝ) / 1000000000000) = ((123064687499 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_792 : RB (Real.log ((1577069 : ℝ) / 12800000)) ((-2093877109939 : ℝ) / 1000000000000) ((-2093877109937 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1577069 : ℝ) / 1600000)) (t := ((-22931 : ℝ) / 3177069))
    (lo := ((-14435568259 : ℝ) / 1000000000000)) (hi := ((-7217784129 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1577069 : ℝ) / 12800000) = Real.log ((1577069 : ℝ) / 1600000) - 3 * Real.log 2 := by
    rw [show ((1577069 : ℝ) / 12800000) = ((1577069 : ℝ) / 1600000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_793 : RB (Real.log ((40767633281 : ℝ) / 125000000000)) ((-56021263633 : ℝ) / 50000000000) ((-560212636329 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((40767633281 : ℝ) / 31250000000)) (t := ((9517633281 : ℝ) / 72017633281))
    (lo := ((13293454423 : ℝ) / 50000000000)) (hi := ((265869088461 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40767633281 : ℝ) / 125000000000) = Real.log ((40767633281 : ℝ) / 31250000000) - 2 * Real.log 2 := by
    rw [show ((40767633281 : ℝ) / 125000000000) = ((40767633281 : ℝ) / 31250000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_794 : RB (Real.log ((326188763571 : ℝ) / 1000000000000)) ((-112027903583 : ℝ) / 100000000000) ((-280069758957 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((326188763571 : ℝ) / 250000000000)) (t := ((76188763571 : ℝ) / 576188763571))
    (lo := ((26601532529 : ℝ) / 100000000000)) (hi := ((266015325291 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((326188763571 : ℝ) / 1000000000000) = Real.log ((326188763571 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((326188763571 : ℝ) / 1000000000000) = ((326188763571 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_795 : RB (Real.log ((3217242619 : ℝ) / 12500000000)) ((-271440796223 : ℝ) / 200000000000) ((-1357203981113 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3217242619 : ℝ) / 3125000000)) (t := ((92242619 : ℝ) / 6342242619))
    (lo := ((5818076001 : ℝ) / 200000000000)) (hi := ((14545190003 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3217242619 : ℝ) / 12500000000) = Real.log ((3217242619 : ℝ) / 3125000000) - 2 * Real.log 2 := by
    rw [show ((3217242619 : ℝ) / 12500000000) = ((3217242619 : ℝ) / 3125000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_796 : RB (Real.log ((3012651777777 : ℝ) / 1000000000000)) ((1102820680211 : ℝ) / 1000000000000) ((1102820680213 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3012651777777 : ℝ) / 4000000000000)) (t := ((-987348222223 : ℝ) / 7012651777777))
    (lo := ((-70868420227 : ℝ) / 250000000000)) (hi := ((-283473680907 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3012651777777 : ℝ) / 1000000000000) = Real.log ((3012651777777 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3012651777777 : ℝ) / 1000000000000) = ((3012651777777 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_797 : RB (Real.log ((602544833367 : ℝ) / 200000000000)) ((551422354137 : ℝ) / 500000000000) ((275711177069 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((602544833367 : ℝ) / 800000000000)) (t := ((-197455166633 : ℝ) / 1402544833367))
    (lo := ((-56689930569 : ℝ) / 200000000000)) (hi := ((-70862413211 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((602544833367 : ℝ) / 200000000000) = Real.log ((602544833367 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((602544833367 : ℝ) / 200000000000) = ((602544833367 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_798 : RB (Real.log ((297862896359 : ℝ) / 200000000000)) ((79663186951 : ℝ) / 200000000000) ((398315934757 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((297862896359 : ℝ) / 400000000000)) (t := ((-102137103641 : ℝ) / 697862896359))
    (lo := ((-73707811451 : ℝ) / 250000000000)) (hi := ((-294831245803 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((297862896359 : ℝ) / 200000000000) = Real.log ((297862896359 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((297862896359 : ℝ) / 200000000000) = ((297862896359 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_799 : RB (Real.log ((140401064453 : ℝ) / 125000000000)) ((58094667917 : ℝ) / 500000000000) ((23237867167 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((140401064453 : ℝ) / 125000000000)) (t := ((15401064453 : ℝ) / 265401064453))
    (lo := ((58094667917 : ℝ) / 500000000000)) (hi := ((23237867167 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_800 : RB (Real.log ((140410053711 : ℝ) / 125000000000)) ((116253359353 : ℝ) / 1000000000000) ((58126679677 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((140410053711 : ℝ) / 125000000000)) (t := ((15410053711 : ℝ) / 265410053711))
    (lo := ((116253359353 : ℝ) / 1000000000000)) (hi := ((58126679677 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_801 : RB (Real.log ((15401064453 : ℝ) / 125000000000)) ((-2093877109947 : ℝ) / 1000000000000) ((-418775421989 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((15401064453 : ℝ) / 15625000000)) (t := ((-223935547 : ℝ) / 31026064453))
    (lo := ((-14435568267 : ℝ) / 1000000000000)) (hi := ((-7217784133 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15401064453 : ℝ) / 125000000000) = Real.log ((15401064453 : ℝ) / 15625000000) - 3 * Real.log 2 := by
    rw [show ((15401064453 : ℝ) / 125000000000) = ((15401064453 : ℝ) / 15625000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_802 : RB (Real.log ((15410053711 : ℝ) / 125000000000)) ((-2093293602513 : ℝ) / 1000000000000) ((-2093293602511 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((15410053711 : ℝ) / 15625000000)) (t := ((-214946289 : ℝ) / 31035053711))
    (lo := ((-13852060833 : ℝ) / 1000000000000)) (hi := ((-432876901 : ℝ) / 31250000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15410053711 : ℝ) / 125000000000) = Real.log ((15410053711 : ℝ) / 15625000000) - 3 * Real.log 2 := by
    rw [show ((15410053711 : ℝ) / 125000000000) = ((15410053711 : ℝ) / 15625000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_803 : RB (Real.log ((122605491337 : ℝ) / 500000000000)) ((-1405636285247 : ℝ) / 1000000000000) ((-281127257049 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((122605491337 : ℝ) / 125000000000)) (t := ((-2394508663 : ℝ) / 247605491337))
    (lo := ((-19341924127 : ℝ) / 1000000000000)) (hi := ((-9670962063 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((122605491337 : ℝ) / 500000000000) = Real.log ((122605491337 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((122605491337 : ℝ) / 500000000000) = ((122605491337 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_804 : RB (Real.log ((15327087247 : ℝ) / 62500000000)) ((-1405544885369 : ℝ) / 1000000000000) ((-1405544885367 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((15327087247 : ℝ) / 15625000000)) (t := ((-297912753 : ℝ) / 30952087247))
    (lo := ((-19250524249 : ℝ) / 1000000000000)) (hi := ((-2406315531 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((15327087247 : ℝ) / 62500000000) = Real.log ((15327087247 : ℝ) / 15625000000) - 2 * Real.log 2 := by
    rw [show ((15327087247 : ℝ) / 62500000000) = ((15327087247 : ℝ) / 15625000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_805 : RB (Real.log ((41825690689 : ℝ) / 200000000000)) ((-391201651507 : ℝ) / 250000000000) ((-782403303013 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((41825690689 : ℝ) / 50000000000)) (t := ((-8174309311 : ℝ) / 91825690689))
    (lo := ((-44628061227 : ℝ) / 250000000000)) (hi := ((-178512244907 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41825690689 : ℝ) / 200000000000) = Real.log ((41825690689 : ℝ) / 50000000000) - 2 * Real.log 2 := by
    rw [show ((41825690689 : ℝ) / 200000000000) = ((41825690689 : ℝ) / 50000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_806 : RB (Real.log ((602217139971 : ℝ) / 200000000000)) ((22046014227 : ℝ) / 20000000000) ((137787588919 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((602217139971 : ℝ) / 800000000000)) (t := ((-197782860029 : ℝ) / 1402217139971))
    (lo := ((-283993649769 : ℝ) / 1000000000000)) (hi := ((-35499206221 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((602217139971 : ℝ) / 200000000000) = Real.log ((602217139971 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((602217139971 : ℝ) / 200000000000) = ((602217139971 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_807 : RB (Real.log ((1505560949279 : ℝ) / 500000000000)) ((1102312733089 : ℝ) / 1000000000000) ((1102312733091 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1505560949279 : ℝ) / 2000000000000)) (t := ((-494439050721 : ℝ) / 3505560949279))
    (lo := ((-28398162803 : ℝ) / 100000000000)) (hi := ((-283981628029 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1505560949279 : ℝ) / 500000000000) = Real.log ((1505560949279 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1505560949279 : ℝ) / 500000000000) = ((1505560949279 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_808 : RB (Real.log ((744843353947 : ℝ) / 500000000000)) ((398565834689 : ℝ) / 1000000000000) ((398565834691 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((744843353947 : ℝ) / 1000000000000)) (t := ((-255156646053 : ℝ) / 1744843353947))
    (lo := ((-29458134587 : ℝ) / 100000000000)) (hi := ((-294581345869 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((744843353947 : ℝ) / 500000000000) = Real.log ((744843353947 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((744843353947 : ℝ) / 500000000000) = ((744843353947 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_809 : RB (Real.log ((1123280429687 : ℝ) / 1000000000000)) ((116253359353 : ℝ) / 1000000000000) ((58126679677 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1123280429687 : ℝ) / 1000000000000)) (t := ((123280429687 : ℝ) / 2123280429687))
    (lo := ((116253359353 : ℝ) / 1000000000000)) (hi := ((58126679677 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_810 : RB (Real.log ((1437891 : ℝ) / 1280000)) ((29079344693 : ℝ) / 250000000000) ((116317378773 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1437891 : ℝ) / 1280000)) (t := ((157891 : ℝ) / 2717891))
    (lo := ((29079344693 : ℝ) / 250000000000)) (hi := ((116317378773 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_811 : RB (Real.log ((123280429687 : ℝ) / 1000000000000)) ((-2093293602521 : ℝ) / 1000000000000) ((-2093293602519 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123280429687 : ℝ) / 125000000000)) (t := ((-1719570313 : ℝ) / 248280429687))
    (lo := ((-13852060841 : ℝ) / 1000000000000)) (hi := ((-346301521 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123280429687 : ℝ) / 1000000000000) = Real.log ((123280429687 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123280429687 : ℝ) / 1000000000000) = ((123280429687 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_812 : RB (Real.log ((157891 : ℝ) / 1280000)) ((-2092710435377 : ℝ) / 1000000000000) ((-16741683483 : ℝ) / 8000000000) := by
  have hm := log_bounds_of_series (x := ((157891 : ℝ) / 160000)) (t := ((-2109 : ℝ) / 317891))
    (lo := ((-13268893697 : ℝ) / 1000000000000)) (hi := ((-3239476 : ℝ) / 244140625)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((157891 : ℝ) / 1280000) = Real.log ((157891 : ℝ) / 160000) - 3 * Real.log 2 := by
    rw [show ((157891 : ℝ) / 1280000) = ((157891 : ℝ) / 160000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_813 : RB (Real.log ((67708427297 : ℝ) / 250000000000)) ((-1306250265677 : ℝ) / 1000000000000) ((-52250010627 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((67708427297 : ℝ) / 62500000000)) (t := ((5208427297 : ℝ) / 130208427297))
    (lo := ((80044095443 : ℝ) / 1000000000000)) (hi := ((20011023861 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((67708427297 : ℝ) / 250000000000) = Real.log ((67708427297 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((67708427297 : ℝ) / 250000000000) = ((67708427297 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_814 : RB (Real.log ((16928537339 : ℝ) / 62500000000)) ((-261233151791 : ℝ) / 200000000000) ((-1306165758953 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((16928537339 : ℝ) / 15625000000)) (t := ((1303537339 : ℝ) / 32553537339))
    (lo := ((16025720433 : ℝ) / 200000000000)) (hi := ((40064301083 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((16928537339 : ℝ) / 62500000000) = Real.log ((16928537339 : ℝ) / 15625000000) - 2 * Real.log 2 := by
    rw [show ((16928537339 : ℝ) / 62500000000) = ((16928537339 : ℝ) / 15625000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_815 : RB (Real.log ((45017614473 : ℝ) / 200000000000)) ((-298252704127 : ℝ) / 200000000000) ((-1491263520633 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((45017614473 : ℝ) / 50000000000)) (t := ((-4982385527 : ℝ) / 95017614473))
    (lo := ((-20993831903 : ℝ) / 200000000000)) (hi := ((-52484579757 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((45017614473 : ℝ) / 200000000000) = Real.log ((45017614473 : ℝ) / 50000000000) - 2 * Real.log 2 := by
    rw [show ((45017614473 : ℝ) / 200000000000) = ((45017614473 : ℝ) / 50000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_816 : RB (Real.log ((12043075919 : ℝ) / 4000000000)) ((1102195521131 : ℝ) / 1000000000000) ((1102195521133 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((12043075919 : ℝ) / 16000000000)) (t := ((-3956924081 : ℝ) / 28043075919))
    (lo := ((-71024709997 : ℝ) / 250000000000)) (hi := ((-284098839987 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((12043075919 : ℝ) / 4000000000) = Real.log ((12043075919 : ℝ) / 16000000000) + 2 * Real.log 2 := by
    rw [show ((12043075919 : ℝ) / 4000000000) = ((12043075919 : ℝ) / 16000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_817 : RB (Real.log ((1505402597261 : ℝ) / 500000000000)) ((34443985921 : ℝ) / 31250000000) ((551103774737 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1505402597261 : ℝ) / 2000000000000)) (t := ((-494597402739 : ℝ) / 3505402597261))
    (lo := ((-284086811647 : ℝ) / 1000000000000)) (hi := ((-142043405823 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1505402597261 : ℝ) / 500000000000) = Real.log ((1505402597261 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1505402597261 : ℝ) / 500000000000) = ((1505402597261 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_818 : RB (Real.log ((744877509353 : ℝ) / 500000000000)) ((199305844731 : ℝ) / 500000000000) ((49826461183 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((744877509353 : ℝ) / 1000000000000)) (t := ((-255122490647 : ℝ) / 1744877509353))
    (lo := ((-294535491097 : ℝ) / 1000000000000)) (hi := ((-36816936387 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((744877509353 : ℝ) / 500000000000) = Real.log ((744877509353 : ℝ) / 1000000000000) + 1 * Real.log 2 := by
    rw [show ((744877509353 : ℝ) / 500000000000) = ((744877509353 : ℝ) / 1000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_819 : RB (Real.log ((1123352343749 : ℝ) / 1000000000000)) ((116317378771 : ℝ) / 1000000000000) ((29079344693 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((1123352343749 : ℝ) / 1000000000000)) (t := ((123352343749 : ℝ) / 2123352343749))
    (lo := ((116317378771 : ℝ) / 1000000000000)) (hi := ((29079344693 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_820 : RB (Real.log ((1123424257813 : ℝ) / 1000000000000)) ((116381394093 : ℝ) / 1000000000000) ((58190697047 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1123424257813 : ℝ) / 1000000000000)) (t := ((123424257813 : ℝ) / 2123424257813))
    (lo := ((116381394093 : ℝ) / 1000000000000)) (hi := ((58190697047 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_821 : RB (Real.log ((123352343749 : ℝ) / 1000000000000)) ((-418542087077 : ℝ) / 200000000000) ((-2092710435383 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123352343749 : ℝ) / 125000000000)) (t := ((-1647656251 : ℝ) / 248352343749))
    (lo := ((-2653778741 : ℝ) / 200000000000)) (hi := ((-1658611713 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123352343749 : ℝ) / 1000000000000) = Real.log ((123352343749 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123352343749 : ℝ) / 1000000000000) = ((123352343749 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_822 : RB (Real.log ((123424257813 : ℝ) / 1000000000000)) ((-2092127608119 : ℝ) / 1000000000000) ((-2092127608117 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((123424257813 : ℝ) / 125000000000)) (t := ((-1575742187 : ℝ) / 248424257813))
    (lo := ((-12686066439 : ℝ) / 1000000000000)) (hi := ((-6343033219 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123424257813 : ℝ) / 1000000000000) = Real.log ((123424257813 : ℝ) / 125000000000) - 3 * Real.log 2 := by
    rw [show ((123424257813 : ℝ) / 1000000000000) = ((123424257813 : ℝ) / 125000000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_823 : RB (Real.log ((159092706047 : ℝ) / 500000000000)) ((-229024201843 : ℝ) / 200000000000) ((-1145121009213 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((159092706047 : ℝ) / 125000000000)) (t := ((34092706047 : ℝ) / 284092706047))
    (lo := ((48234670381 : ℝ) / 200000000000)) (hi := ((120586675953 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((159092706047 : ℝ) / 500000000000) = Real.log ((159092706047 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((159092706047 : ℝ) / 500000000000) = ((159092706047 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_824 : RB (Real.log ((159104583713 : ℝ) / 500000000000)) ((-114504635323 : ℝ) / 100000000000) ((-286261588307 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((159104583713 : ℝ) / 125000000000)) (t := ((34104583713 : ℝ) / 284104583713))
    (lo := ((24124800789 : ℝ) / 100000000000)) (hi := ((241248007891 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((159104583713 : ℝ) / 500000000000) = Real.log ((159104583713 : ℝ) / 125000000000) - 2 * Real.log 2 := by
    rw [show ((159104583713 : ℝ) / 500000000000) = ((159104583713 : ℝ) / 125000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_825 : RB (Real.log ((50587566279 : ℝ) / 200000000000)) ((-687305773081 : ℝ) / 500000000000) ((-17182644327 : ℝ) / 12500000000) := by
  have hm := log_bounds_of_series (x := ((50587566279 : ℝ) / 50000000000)) (t := ((587566279 : ℝ) / 100587566279))
    (lo := ((5841407479 : ℝ) / 500000000000)) (hi := ((11682814959 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((50587566279 : ℝ) / 200000000000) = Real.log ((50587566279 : ℝ) / 50000000000) - 2 * Real.log 2 := by
    rw [show ((50587566279 : ℝ) / 200000000000) = ((50587566279 : ℝ) / 50000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_826 : RB (Real.log ((3010452237607 : ℝ) / 1000000000000)) ((551045156263 : ℝ) / 500000000000) ((68880644533 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((3010452237607 : ℝ) / 4000000000000)) (t := ((-989547762393 : ℝ) / 7010452237607))
    (lo := ((-284204048593 : ℝ) / 1000000000000)) (hi := ((-17762753037 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3010452237607 : ℝ) / 1000000000000) = Real.log ((3010452237607 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3010452237607 : ℝ) / 1000000000000) = ((3010452237607 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_827 : RB (Real.log ((3010488468443 : ℝ) / 1000000000000)) ((275525586867 : ℝ) / 250000000000) ((110210234747 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((3010488468443 : ℝ) / 4000000000000)) (t := ((-989511531557 : ℝ) / 7010488468443))
    (lo := ((-284192013651 : ℝ) / 1000000000000)) (hi := ((-5683840273 : ℝ) / 20000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3010488468443 : ℝ) / 1000000000000) = Real.log ((3010488468443 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3010488468443 : ℝ) / 1000000000000) = ((3010488468443 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_828 : RB (Real.log ((297964670253 : ℝ) / 200000000000)) ((39865755673 : ℝ) / 100000000000) ((99664389183 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((297964670253 : ℝ) / 400000000000)) (t := ((-102035329747 : ℝ) / 697964670253))
    (lo := ((-294489623829 : ℝ) / 1000000000000)) (hi := ((-73622405957 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((297964670253 : ℝ) / 200000000000) = Real.log ((297964670253 : ℝ) / 400000000000) + 1 * Real.log 2 := by
    rw [show ((297964670253 : ℝ) / 200000000000) = ((297964670253 : ℝ) / 400000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_829 : RB (Real.log ((280856064453 : ℝ) / 250000000000)) ((29095348523 : ℝ) / 250000000000) ((116381394093 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((280856064453 : ℝ) / 250000000000)) (t := ((30856064453 : ℝ) / 530856064453))
    (lo := ((29095348523 : ℝ) / 250000000000)) (hi := ((116381394093 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_830 : RB (Real.log ((280865053711 : ℝ) / 250000000000)) ((116413400217 : ℝ) / 1000000000000) ((58206700109 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((280865053711 : ℝ) / 250000000000)) (t := ((30865053711 : ℝ) / 530865053711))
    (lo := ((116413400217 : ℝ) / 1000000000000)) (hi := ((58206700109 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_831 : RB (Real.log ((30856064453 : ℝ) / 250000000000)) ((-2092127608127 : ℝ) / 1000000000000) ((-3347404173 : ℝ) / 1600000000) := by
  have hm := log_bounds_of_series (x := ((30856064453 : ℝ) / 31250000000)) (t := ((-393935547 : ℝ) / 62106064453))
    (lo := ((-12686066447 : ℝ) / 1000000000000)) (hi := ((-6343033223 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((30856064453 : ℝ) / 250000000000) = Real.log ((30856064453 : ℝ) / 31250000000) - 3 * Real.log 2 := by
    rw [show ((30856064453 : ℝ) / 250000000000) = ((30856064453 : ℝ) / 31250000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_832 : RB (Real.log ((30865053711 : ℝ) / 250000000000)) ((-2091836321827 : ℝ) / 1000000000000) ((-83673452873 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((30865053711 : ℝ) / 31250000000)) (t := ((-384946289 : ℝ) / 62115053711))
    (lo := ((-12394780147 : ℝ) / 1000000000000)) (hi := ((-6197390073 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((30865053711 : ℝ) / 250000000000) = Real.log ((30865053711 : ℝ) / 31250000000) - 3 * Real.log 2 := by
    rw [show ((30865053711 : ℝ) / 250000000000) = ((30865053711 : ℝ) / 31250000000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_833 : RB (Real.log ((239086180097 : ℝ) / 1000000000000)) ((-1430931205867 : ℝ) / 1000000000000) ((-286186241173 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((239086180097 : ℝ) / 250000000000)) (t := ((-10913819903 : ℝ) / 489086180097))
    (lo := ((-44636844747 : ℝ) / 1000000000000)) (hi := ((-22318422373 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((239086180097 : ℝ) / 1000000000000) = Real.log ((239086180097 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((239086180097 : ℝ) / 1000000000000) = ((239086180097 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_834 : RB (Real.log ((239097350013 : ℝ) / 1000000000000)) ((-715442243877 : ℝ) / 500000000000) ((-178860560969 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((239097350013 : ℝ) / 250000000000)) (t := ((-10902649987 : ℝ) / 489097350013))
    (lo := ((-22295063317 : ℝ) / 500000000000)) (hi := ((-44590126633 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((239097350013 : ℝ) / 1000000000000) = Real.log ((239097350013 : ℝ) / 250000000000) - 2 * Real.log 2 := by
    rw [show ((239097350013 : ℝ) / 1000000000000) = ((239097350013 : ℝ) / 250000000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_835 : RB (Real.log ((51313744119 : ℝ) / 250000000000)) ((-79175114251 : ℝ) / 50000000000) ((-791751142509 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((51313744119 : ℝ) / 62500000000)) (t := ((-11186255881 : ℝ) / 113813744119))
    (lo := ((-1972079239 : ℝ) / 10000000000)) (hi := ((-197207923899 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51313744119 : ℝ) / 250000000000) = Real.log ((51313744119 : ℝ) / 62500000000) - 2 * Real.log 2 := by
    rw [show ((51313744119 : ℝ) / 250000000000) = ((51313744119 : ℝ) / 62500000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_836 : RB (Real.log ((601934032227 : ℝ) / 200000000000)) ((1101830491737 : ℝ) / 1000000000000) ((1101830491739 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((601934032227 : ℝ) / 800000000000)) (t := ((-198065967773 : ℝ) / 1401934032227))
    (lo := ((-142231934691 : ℝ) / 500000000000)) (hi := ((-284463869381 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((601934032227 : ℝ) / 200000000000) = Real.log ((601934032227 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((601934032227 : ℝ) / 200000000000) = ((601934032227 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_837 : RB (Real.log ((3009688277587 : ℝ) / 1000000000000)) ((1101836511133 : ℝ) / 1000000000000) ((220367302227 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((3009688277587 : ℝ) / 4000000000000)) (t := ((-990311722413 : ℝ) / 7009688277587))
    (lo := ((-142228924993 : ℝ) / 500000000000)) (hi := ((-56891569997 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3009688277587 : ℝ) / 1000000000000) = Real.log ((3009688277587 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3009688277587 : ℝ) / 1000000000000) = ((3009688277587 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_838 : RB (Real.log ((372502388003 : ℝ) / 250000000000)) ((199391265341 : ℝ) / 500000000000) ((99695632671 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((372502388003 : ℝ) / 500000000000)) (t := ((-127497611997 : ℝ) / 872502388003))
    (lo := ((-294364649877 : ℝ) / 1000000000000)) (hi := ((-73591162469 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((372502388003 : ℝ) / 250000000000) = Real.log ((372502388003 : ℝ) / 500000000000) + 1 * Real.log 2 := by
    rw [show ((372502388003 : ℝ) / 250000000000) = ((372502388003 : ℝ) / 500000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_839 : RB (Real.log ((1123460214843 : ℝ) / 1000000000000)) ((14551675027 : ℝ) / 125000000000) ((116413400217 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1123460214843 : ℝ) / 1000000000000)) (t := ((123460214843 : ℝ) / 2123460214843))
    (lo := ((14551675027 : ℝ) / 125000000000)) (hi := ((116413400217 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

end EP1038.DLowerCert
