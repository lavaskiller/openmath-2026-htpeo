import LeanProject.ArcEnergyC

/-!
# EP-1038, Stage 10, Lemma 10.1 (Poisson–logarithm lemma)

`P_q(θ) = (1 - q²)/(1 - 2q cos θ + q²) = 1 + 2 ∑_{m ≥ 1} q^m cos(mθ)` for `0 ≤ q < 1`.

* `Pq_hasSum`: the cosine series of `P_q`.
* `int_cos_affine`, `orth`, `orth0`: orthogonality of cosines on `[-π, π]`.
* `int_Kl_cos`, `int_Kl_shift`: for `0 ≤ ρ < 1`,
  `∫ log|1 - ρe^{i(θ+φ)}| cos(mθ) dθ = -(ρ^m/m) π cos(mφ)` and `∫ log|1 - ρe^{i(θ+φ)}| dθ = 0`.
* `int_Kl_Pq`: for `0 ≤ ρ < 1`, `∫ log|1 - ρe^{i(θ+φ)}| P_q(θ) dθ = 2π log|1 - ρq e^{iφ}|`.
* `poisson_log` (**Lemma 10.1(i)**, with the factor `2π` moved to the right):
  `∫_{-π}^{π} log|1 - e^{i(θ+φ)}| P_q(θ) dθ = 2π log|1 - q e^{iφ}|`.
* `poisson_log_integrable`: the integrand of (i) is integrable (the side claim of Lemma 10.1).
* `poisson_log_ii` (**Lemma 10.1(ii)**): `∫_{-π}^{π} log|1 - q e^{iθ}| dθ = 0`.
-/

open Real MeasureTheory Set Filter Topology

namespace EP1038.Arc

/-- The Poisson kernel `P_q(θ) = (1 - q²)/(1 - 2q cos θ + q²)`. -/
noncomputable def Pq (q θ : ℝ) : ℝ := (1 - q ^ 2) / (1 - 2 * q * Real.cos θ + q ^ 2)

theorem Pq_den_pos {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (θ : ℝ) :
    0 < 1 - 2 * q * Real.cos θ + q ^ 2 := by
  have hc := Real.cos_le_one θ
  nlinarith [mul_nonneg hq0 (sub_nonneg.mpr hc), pow_pos (sub_pos.mpr hq1) 2]

theorem Pq_cont {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) : Continuous (Pq q) := by
  unfold Pq
  exact continuous_const.div (by fun_prop) (fun θ => (Pq_den_pos hq0 hq1 θ).ne')

theorem Pq_nonneg {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (θ : ℝ) : 0 ≤ Pq q θ :=
  div_nonneg (by nlinarith) (Pq_den_pos hq0 hq1 θ).le

theorem Pq_le {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (θ : ℝ) : Pq q θ ≤ (1 + q) / (1 - q) := by
  unfold Pq
  have hD := Pq_den_pos hq0 hq1 θ
  have h1 : 0 < 1 - q := by linarith
  rw [div_le_div_iff₀ hD h1]
  have hc := Real.cos_le_one θ
  nlinarith [mul_nonneg hq0 (sub_nonneg.mpr hc), mul_nonneg (mul_nonneg hq0 hq0) (sub_nonneg.mpr hc)]

/-- `P_q(θ) - 1 = 2 ∑_{m ≥ 1} q^m cos(mθ)`. -/
theorem Pq_hasSum {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (θ : ℝ) :
    HasSum (fun m : ℕ => 2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ))) (Pq q θ - 1) := by
  set z : ℂ := (q : ℂ) * Complex.exp ((θ : ℂ) * Complex.I) with hz
  have hzn : ‖z‖ < 1 := by rw [hz, norm_l_exp q θ hq0]; exact hq1
  have hg := (hasSum_geometric_of_norm_lt_one hzn).mul_left z
  have hre := Complex.reCLM.hasSum hg
  have e1 : ∀ n : ℕ, Complex.reCLM (z * z ^ n) = q ^ (n + 1) * Real.cos ((n + 1) * θ) := by
    intro n
    have hpow : z * z ^ n =
        ((q ^ (n + 1) : ℝ) : ℂ) * Complex.exp ((((n + 1) * θ : ℝ) : ℂ) * Complex.I) := by
      rw [← pow_succ', hz, mul_pow, ← Complex.exp_nat_mul]
      push_cast
      ring_nf
    rw [Complex.reCLM_apply, hpow, Complex.re_ofReal_mul, Complex.exp_ofReal_mul_I_re]
  have hzr : z.re = q * Real.cos θ := by
    rw [hz, Complex.re_ofReal_mul, Complex.exp_ofReal_mul_I_re]
  have hzi : z.im = q * Real.sin θ := by
    rw [hz, Complex.im_ofReal_mul, Complex.exp_ofReal_mul_I_im]
  have hD := Pq_den_pos hq0 hq1 θ
  have hN : Complex.normSq (1 - z) = 1 - 2 * q * Real.cos θ + q ^ 2 := by
    rw [Complex.normSq_apply, Complex.sub_re, Complex.sub_im, Complex.one_re, Complex.one_im,
      hzr, hzi]
    linear_combination q ^ 2 * Real.sin_sq_add_cos_sq θ
  have e2 : Complex.reCLM (z * (1 - z)⁻¹) = (q * Real.cos θ - q ^ 2) /
      (1 - 2 * q * Real.cos θ + q ^ 2) := by
    rw [Complex.reCLM_apply, ← div_eq_mul_inv, Complex.div_re, hN, Complex.sub_re,
      Complex.sub_im, Complex.one_re, Complex.one_im, hzr, hzi, ← add_div]
    congr 1
    linear_combination (-q ^ 2) * Real.sin_sq_add_cos_sq θ
  rw [e2] at hre
  have e3 : (fun n : ℕ => Complex.reCLM (z * z ^ n)) =
      fun n : ℕ => q ^ (n + 1) * Real.cos ((n + 1) * θ) := funext e1
  rw [e3] at hre
  have e4 : Pq q θ - 1 = 2 * ((q * Real.cos θ - q ^ 2) / (1 - 2 * q * Real.cos θ + q ^ 2)) := by
    have hD' : 1 - 2 * q * Real.cos θ + q ^ 2 ≠ 0 := hD.ne'
    unfold Pq
    rw [div_sub_one hD', mul_div_assoc', div_left_inj' hD']
    ring
  rw [e4]
  exact hre.mul_left 2

/-! ### Orthogonality -/

theorem int_cos_affine {k : ℝ} (hk : k ≠ 0) (hs : Real.sin (k * π) = 0) (c : ℝ) :
    ∫ θ in (-π)..π, Real.cos (k * θ + c) = 0 := by
  rw [intervalIntegral.integral_comp_mul_add (fun x => Real.cos x) hk c, integral_cos,
    smul_eq_mul, show k * π + c = c + k * π by ring, show k * -π + c = c - k * π by ring,
    Real.sin_add, Real.sin_sub, hs]
  ring

theorem orth0 (n : ℕ) (φ : ℝ) : ∫ θ in (-π)..π, Real.cos ((n + 1) * (θ + φ)) = 0 := by
  have hk : ((n : ℝ) + 1) ≠ 0 := by positivity
  have hs : Real.sin (((n : ℝ) + 1) * π) = 0 := by
    rw [show ((n : ℝ) + 1) = ((n + 1 : ℕ) : ℝ) by norm_num]
    exact Real.sin_nat_mul_pi _
  have e : (fun θ : ℝ => Real.cos ((n + 1) * (θ + φ))) =
      fun θ => Real.cos (((n : ℝ) + 1) * θ + (n + 1) * φ) := by
    funext θ; ring_nf
  rw [e]
  exact int_cos_affine hk hs _

theorem orth (n m : ℕ) (φ : ℝ) :
    ∫ θ in (-π)..π, Real.cos ((n + 1) * (θ + φ)) * Real.cos ((m + 1) * θ) =
      if n = m then π * Real.cos ((m + 1) * φ) else 0 := by
  have e : ∀ θ : ℝ, Real.cos ((n + 1) * (θ + φ)) * Real.cos ((m + 1) * θ) =
      (Real.cos (((n : ℝ) - m) * θ + (n + 1) * φ) +
        Real.cos (((n : ℝ) + m + 2) * θ + (n + 1) * φ)) / 2 := by
    intro θ
    have h1 : ((n : ℝ) - m) * θ + (n + 1) * φ = (n + 1) * (θ + φ) - (m + 1) * θ := by ring
    have h2 : ((n : ℝ) + m + 2) * θ + (n + 1) * φ = (n + 1) * (θ + φ) + (m + 1) * θ := by ring
    rw [h1, h2, Real.cos_sub, Real.cos_add]
    ring
  have hc1 : Continuous (fun θ : ℝ => Real.cos (((n : ℝ) - m) * θ + (n + 1) * φ)) := by fun_prop
  have hc2 : Continuous (fun θ : ℝ => Real.cos (((n : ℝ) + m + 2) * θ + (n + 1) * φ)) := by fun_prop
  rw [intervalIntegral.integral_congr (fun θ _ => e θ), intervalIntegral.integral_div,
    intervalIntegral.integral_add (hc1.intervalIntegrable _ _) (hc2.intervalIntegrable _ _)]
  have hk2 : ((n : ℝ) + m + 2) ≠ 0 := by positivity
  have hs2 : Real.sin (((n : ℝ) + m + 2) * π) = 0 := by
    rw [show ((n : ℝ) + m + 2) = ((n + m + 2 : ℕ) : ℝ) by norm_num]
    exact Real.sin_nat_mul_pi _
  rw [int_cos_affine hk2 hs2]
  split_ifs with h
  · subst h
    simp only [sub_self, zero_mul, zero_add, intervalIntegral.integral_const, smul_eq_mul]
    ring
  · have hk1 : ((n : ℝ) - m) ≠ 0 := by
      intro h'
      apply h
      exact_mod_cast sub_eq_zero.mp h'
    have hs1 : Real.sin (((n : ℝ) - m) * π) = 0 := by
      rw [show ((n : ℝ) - m) = (((n : ℤ) - m : ℤ) : ℝ) by push_cast; ring]
      exact Real.sin_int_mul_pi _
    rw [int_cos_affine hk1 hs1]
    ring

/-! ### Termwise integration for `ρ < 1` -/

theorem aux_bound4 {p c d m : ℝ} (hp : 0 ≤ p) (hm : 1 ≤ m) (hc : |c| ≤ 1) (hd : |d| ≤ 1) :
    |p * c / m * d| ≤ p := by
  rw [abs_mul]
  calc |p * c / m| * |d| ≤ p * 1 :=
        mul_le_mul (aux_bound1 hp hm hc) hd (abs_nonneg _) hp
    _ = p := mul_one p

/-- `∫ log|1 - ρe^{i(θ+φ)}| cos((m+1)θ) dθ = -(ρ^{m+1}/(m+1)) π cos((m+1)φ)`. -/
theorem int_Kl_cos {ρ : ℝ} (h0 : 0 ≤ ρ) (h1 : ρ < 1) (m : ℕ) (φ : ℝ) :
    ∫ θ in (-π)..π, Kl ρ (θ + φ) * Real.cos ((m + 1) * θ) =
      -(ρ ^ (m + 1) / (m + 1) * (π * Real.cos ((m + 1) * φ))) := by
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence (μ := volume)
    (a := -π) (b := π)
    (F := fun (n : ℕ) (θ : ℝ) =>
      ρ ^ (n + 1) * Real.cos ((n + 1) * (θ + φ)) / (n + 1) * Real.cos ((m + 1) * θ))
    (f := fun θ => -Kl ρ (θ + φ) * Real.cos ((m + 1) * θ)) (fun n _ => ρ ^ (n + 1))
    (fun n => (Continuous.aestronglyMeasurable (by fun_prop)))
    (fun n => Filter.Eventually.of_forall fun θ _ => by
      rw [Real.norm_eq_abs]
      exact aux_bound4 (pow_nonneg h0 _) (one_le_succ n) (Real.abs_cos_le_one _)
        (Real.abs_cos_le_one _))
    (Filter.Eventually.of_forall fun θ _ => summable_pow_succ h0 h1)
    intervalIntegrable_const
    (Filter.Eventually.of_forall fun θ _ => (Kl_hasSum h0 h1 (θ + φ)).mul_right _)
  have hterm : ∀ n : ℕ, (∫ θ in (-π)..π,
      ρ ^ (n + 1) * Real.cos ((n + 1) * (θ + φ)) / (n + 1) * Real.cos ((m + 1) * θ)) =
      if n = m then ρ ^ (m + 1) / (m + 1) * (π * Real.cos ((m + 1) * φ)) else 0 := by
    intro n
    have e : (fun θ : ℝ =>
        ρ ^ (n + 1) * Real.cos ((n + 1) * (θ + φ)) / (n + 1) * Real.cos ((m + 1) * θ)) =
        fun θ => ρ ^ (n + 1) / (n + 1) *
          (Real.cos ((n + 1) * (θ + φ)) * Real.cos ((m + 1) * θ)) := by
      funext θ; ring
    rw [e, intervalIntegral.integral_const_mul, orth]
    split_ifs with hnm
    · subst hnm; rfl
    · ring
  rw [show (fun n : ℕ => ∫ θ in (-π)..π,
      ρ ^ (n + 1) * Real.cos ((n + 1) * (θ + φ)) / (n + 1) * Real.cos ((m + 1) * θ)) =
      _ from funext hterm] at h
  have h' := h.unique (hasSum_ite_eq m (ρ ^ (m + 1) / (m + 1) * (π * Real.cos ((m + 1) * φ))))
  rw [← h']
  rw [← intervalIntegral.integral_neg]
  refine intervalIntegral.integral_congr (fun θ _ => ?_)
  ring

/-- `∫ log|1 - ρe^{i(θ+φ)}| dθ = 0`. -/
theorem int_Kl_shift {ρ : ℝ} (h0 : 0 ≤ ρ) (h1 : ρ < 1) (φ : ℝ) :
    ∫ θ in (-π)..π, Kl ρ (θ + φ) = 0 := by
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence (μ := volume)
    (a := -π) (b := π)
    (F := fun (n : ℕ) (θ : ℝ) => ρ ^ (n + 1) * Real.cos ((n + 1) * (θ + φ)) / (n + 1))
    (f := fun θ => -Kl ρ (θ + φ)) (fun n _ => ρ ^ (n + 1))
    (fun n => (Continuous.aestronglyMeasurable (by fun_prop)))
    (fun n => Filter.Eventually.of_forall fun θ _ => by
      rw [Real.norm_eq_abs]
      exact aux_bound1 (pow_nonneg h0 _) (one_le_succ n) (Real.abs_cos_le_one _))
    (Filter.Eventually.of_forall fun θ _ => summable_pow_succ h0 h1)
    intervalIntegrable_const
    (Filter.Eventually.of_forall fun θ _ => Kl_hasSum h0 h1 (θ + φ))
  have hterm : ∀ n : ℕ, (∫ θ in (-π)..π, ρ ^ (n + 1) * Real.cos ((n + 1) * (θ + φ)) / (n + 1)) =
      0 := by
    intro n
    have e : (fun θ : ℝ => ρ ^ (n + 1) * Real.cos ((n + 1) * (θ + φ)) / (n + 1)) =
        fun θ => ρ ^ (n + 1) / (n + 1) * Real.cos ((n + 1) * (θ + φ)) := by
      funext θ; ring
    rw [e, intervalIntegral.integral_const_mul, orth0, mul_zero]
  rw [show (fun n : ℕ => ∫ θ in (-π)..π, ρ ^ (n + 1) * Real.cos ((n + 1) * (θ + φ)) / (n + 1)) =
      fun _ => (0 : ℝ) from funext hterm] at h
  have h' := h.unique hasSum_zero
  rw [intervalIntegral.integral_neg] at h'
  linarith

/-- For `0 ≤ ρ < 1`: `∫ log|1 - ρe^{i(θ+φ)}| P_q(θ) dθ = 2π log|1 - ρq e^{iφ}|`. -/
theorem int_Kl_Pq {ρ q : ℝ} (h0 : 0 ≤ ρ) (h1 : ρ < 1) (hq0 : 0 ≤ q) (hq1 : q < 1) (φ : ℝ) :
    ∫ θ in (-π)..π, Kl ρ (θ + φ) * Pq q θ = 2 * π * Kl (ρ * q) φ := by
  have hFc : Continuous (fun θ => Kl ρ (θ + φ)) :=
    (Kl_continuous h0 h1).comp (continuous_id.add continuous_const)
  obtain ⟨C, hC⟩ := (isCompact_Icc (a := -π) (b := π)).exists_bound_of_continuousOn
    hFc.continuousOn
  have hC0 : 0 ≤ C := (norm_nonneg _).trans (hC 0 ⟨by linarith [Real.pi_pos], Real.pi_pos.le⟩)
  have h := intervalIntegral.hasSum_integral_of_dominated_convergence (μ := volume)
    (a := -π) (b := π)
    (F := fun (m : ℕ) (θ : ℝ) => Kl ρ (θ + φ) * (2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ))))
    (f := fun θ => Kl ρ (θ + φ) * (Pq q θ - 1)) (fun m _ => C * (2 * q ^ (m + 1)))
    (fun m => (hFc.mul (by fun_prop)).aestronglyMeasurable)
    (fun m => by
      refine Filter.Eventually.of_forall fun θ hθ => ?_
      have hθ' : θ ∈ Icc (-π) π := by
        rw [uIoc_of_le (by linarith [Real.pi_pos])] at hθ
        exact ⟨hθ.1.le, hθ.2⟩
      rw [norm_mul]
      refine mul_le_mul (hC θ hθ') ?_ (norm_nonneg _) hC0
      rw [Real.norm_eq_abs, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2), abs_mul,
        abs_of_nonneg (pow_nonneg hq0 _)]
      have := Real.abs_cos_le_one ((m + 1) * θ)
      have := pow_nonneg hq0 (m + 1)
      nlinarith)
    (Filter.Eventually.of_forall fun θ _ =>
      ((summable_pow_succ hq0 hq1).mul_left 2).mul_left C)
    intervalIntegrable_const
    (Filter.Eventually.of_forall fun θ _ => (Pq_hasSum hq0 hq1 θ).mul_left _)
  have hterm : ∀ m : ℕ, (∫ θ in (-π)..π,
      Kl ρ (θ + φ) * (2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ)))) =
      -(2 * π) * ((ρ * q) ^ (m + 1) * Real.cos ((m + 1) * φ) / (m + 1)) := by
    intro m
    have e : (fun θ : ℝ => Kl ρ (θ + φ) * (2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ)))) =
        fun θ => (2 * q ^ (m + 1)) * (Kl ρ (θ + φ) * Real.cos ((m + 1) * θ)) := by
      funext θ; ring
    rw [e, intervalIntegral.integral_const_mul, int_Kl_cos h0 h1, mul_pow]
    ring
  rw [show (fun m : ℕ => ∫ θ in (-π)..π,
      Kl ρ (θ + φ) * (2 * (q ^ (m + 1) * Real.cos ((m + 1) * θ)))) = _ from funext hterm] at h
  have hs := (Kl_hasSum (mul_nonneg h0 hq0) (by nlinarith) φ).mul_left (-(2 * π))
  have hval := h.unique hs
  -- `∫ K P = ∫ K (P - 1) + ∫ K`
  have hPc := Pq_cont hq0 hq1
  have e2 : ∫ θ in (-π)..π, Kl ρ (θ + φ) * Pq q θ =
      (∫ θ in (-π)..π, Kl ρ (θ + φ) * (Pq q θ - 1)) + ∫ θ in (-π)..π, Kl ρ (θ + φ) := by
    have hi1 : IntervalIntegrable (fun θ => Kl ρ (θ + φ) * (Pq q θ - 1)) volume (-π) π :=
      (hFc.mul (hPc.sub continuous_const)).intervalIntegrable _ _
    have hi2 : IntervalIntegrable (fun θ => Kl ρ (θ + φ)) volume (-π) π :=
      hFc.intervalIntegrable _ _
    rw [← intervalIntegral.integral_add hi1 hi2]
    refine intervalIntegral.integral_congr (fun θ _ => ?_)
    show Kl ρ (θ + φ) * Pq q θ = Kl ρ (θ + φ) * (Pq q θ - 1) + Kl ρ (θ + φ)
    ring
  rw [e2, hval, int_Kl_shift h0 h1]
  ring

/-! ### The limit `ρ → 1` -/

theorem Bd_shift_ii (φ a b : ℝ) : IntervalIntegrable (fun θ => Bd (θ + φ)) volume a b := by
  have e : (fun θ => Bd (θ + φ)) = fun θ => Bd (-φ - θ) := by
    funext θ
    unfold Bd
    rw [show -φ - θ = -(θ + φ) by ring, Real.sin_neg, abs_neg]
  rw [e]
  exact Bd_ii (-φ) a b

theorem Kl_tendsto_mul {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (φ : ℝ) :
    Tendsto (fun k : ℕ => Kl (lk k * q) φ) atTop (𝓝 (Kl q φ)) := by
  have hne : ‖(1 : ℂ) - (q : ℂ) * Complex.exp ((φ : ℂ) * Complex.I)‖ ≠ 0 := by
    have h := norm_sub_norm_le (1 : ℂ) ((q : ℂ) * Complex.exp ((φ : ℂ) * Complex.I))
    rw [norm_l_exp q φ hq0, norm_one] at h
    exact (lt_of_lt_of_le (by linarith) h).ne'
  unfold Kl
  refine Tendsto.log ?_ hne
  refine (continuous_norm.tendsto _).comp ?_
  have hc : Continuous (fun l : ℝ => (1 : ℂ) - (l : ℂ) * Complex.exp ((φ : ℂ) * Complex.I)) := by
    fun_prop
  have hl : Tendsto (fun k : ℕ => lk k * q) atTop (𝓝 q) := by
    have := lk_tendsto.mul_const q
    rwa [one_mul] at this
  exact (hc.tendsto q).comp hl

/-- **Lemma 10.1(i)**: `∫_{-π}^{π} log|1 - e^{i(θ+φ)}| P_q(θ) dθ = 2π log|1 - q e^{iφ}|`. -/
theorem poisson_log {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (φ : ℝ) :
    ∫ θ in (-π)..π, Kl 1 (θ + φ) * Pq q θ = 2 * π * Kl q φ := by
  have hPc := Pq_cont hq0 hq1
  set B := (1 + q) / (1 - q) with hB
  have t1 : Tendsto (fun k : ℕ => ∫ θ in (-π)..π, Kl (lk k) (θ + φ) * Pq q θ) atTop
      (𝓝 (∫ θ in (-π)..π, Kl 1 (θ + φ) * Pq q θ)) := by
    refine intervalIntegral.tendsto_integral_filter_of_dominated_convergence
      (fun θ => Bd (θ + φ) * B) (Eventually.of_forall fun k =>
        (((Kl_continuous (by linarith [(lk_mem k).1]) (lk_mem k).2).comp
          (continuous_id.add continuous_const)).mul hPc).aestronglyMeasurable) ?_
      ((Bd_shift_ii φ _ _).mul_const B) ?_
    · refine Eventually.of_forall fun k => ?_
      filter_upwards [ae_sin_ne' (-φ)] with θ hθ _
      have hs : Real.sin (θ + φ) ≠ 0 := by
        rwa [show -φ - θ = -(θ + φ) by ring, Real.sin_neg, neg_ne_zero] at hθ
      rw [norm_mul, Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg (Pq_nonneg hq0 hq1 θ)]
      exact mul_le_mul (Kl_bound (lk_mem k).1 (lk_mem k).2.le hs) (Pq_le hq0 hq1 θ)
        (Pq_nonneg hq0 hq1 θ) (by unfold Bd; positivity)
    · filter_upwards [ae_sin_ne' (-φ)] with θ hθ _
      have hs : Real.sin (θ + φ) ≠ 0 := by
        rwa [show -φ - θ = -(θ + φ) by ring, Real.sin_neg, neg_ne_zero] at hθ
      exact (Kl_tendsto hs).mul_const _
  have e : ∀ k : ℕ, ∫ θ in (-π)..π, Kl (lk k) (θ + φ) * Pq q θ = 2 * π * Kl (lk k * q) φ :=
    fun k => int_Kl_Pq (by linarith [(lk_mem k).1]) (lk_mem k).2 hq0 hq1 φ
  have t2 := (Kl_tendsto_mul hq0 hq1 φ).const_mul (2 * π)
  exact tendsto_nhds_unique t1 (t2.congr (fun k => (e k).symm))

/-- The integrand of Lemma 10.1(i) is (absolutely) integrable on `[-π, π]`. -/
theorem poisson_log_integrable {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) (φ : ℝ) :
    IntervalIntegrable (fun θ => Kl 1 (θ + φ) * Pq q θ) volume (-π) π := by
  have h := (Kl1_ii (-π + φ) (π + φ)).comp_add_right φ
  simp only [add_sub_cancel_right] at h
  exact h.mul_continuousOn (Pq_cont hq0 hq1).continuousOn

/-- **Lemma 10.1(ii)**: `∫_{-π}^{π} log|1 - q e^{iθ}| dθ = 0` for `0 ≤ q < 1`. -/
theorem poisson_log_ii {q : ℝ} (hq0 : 0 ≤ q) (hq1 : q < 1) :
    ∫ θ in (-π)..π, Kl q θ = 0 := by
  have := int_Kl_shift hq0 hq1 0
  simpa using this

end EP1038.Arc
