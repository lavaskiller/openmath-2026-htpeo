import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk06
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_50 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((27 : ℝ) / 43) ((5433 : ℝ) / 8633))
    (hq : RB (qa a) ((74599 : ℝ) / 5000000) ((763103 : ℝ) / 50000000))
    (hd : RB (D0a a) ((38806429 : ℝ) / 20000000) ((194163031 : ℝ) / 100000000))
    : certE k a ((41031769 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((41840653 : ℝ) / 100000000) ∧ 0 < certE k a ((12966359 : ℝ) / 10000000) ∧ certE k a ((13000971 : ℝ) / 10000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((1113 : ℝ) / 5000000) ((11647 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((41031769 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((1640339 : ℝ) / 4000000) ((41009509 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((41031769 : ℝ) / 100000000) ((41031769 : ℝ) / 100000000) ((41031769 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((58968231 : ℝ) / 100000000))
  have h3 : RB z3 ((13908667 : ℝ) / 20000000) ((6954509 : ℝ) / 10000000) := rb_div_signed h2 (show RB ((58968231 : ℝ) / 100000000) ((58968231 : ℝ) / 100000000) ((58968231 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-36322011 : ℝ) / 100000000) ((-18159743 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_900.1 cov_log_901.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-22858507 : ℝ) / 100000000) ((-11402629 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((41031769 : ℝ) / 100000000))
  have h6 : RB z6 ((-44541179 : ℝ) / 50000000) ((-22270589 : ℝ) / 25000000) := rb_log (show RB ((41031769 : ℝ) / 100000000) ((41031769 : ℝ) / 100000000) ((41031769 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_902.1 cov_log_902.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66223849 : ℝ) / 100000000) ((662771 : ℝ) / 1000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((13257073 : ℝ) / 20000000) ((82941 : ℝ) / 125000) := rb_log hd (by norm_num) cov_log_903.1 cov_log_904.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-128951 : ℝ) / 100000000) ((-1653 : ℝ) / 20000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((1113 : ℝ) / 5000000) ((11647 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((41840653 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((41817359 : ℝ) / 100000000) ((41818393 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((41840653 : ℝ) / 100000000) ((41840653 : ℝ) / 100000000) ((41840653 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((58159347 : ℝ) / 100000000))
  have h12 : RB z12 ((14380271 : ℝ) / 20000000) ((35951567 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((58159347 : ℝ) / 100000000) ((58159347 : ℝ) / 100000000) ((58159347 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-8246877 : ℝ) / 25000000) ((-32985033 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_905.1 cov_log_906.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-10380003 : ℝ) / 50000000) ((-5177883 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((41840653 : ℝ) / 100000000))
  have h15 : RB z15 ((-87130177 : ℝ) / 100000000) ((-3485207 : ℝ) / 4000000) := rb_log (show RB ((41840653 : ℝ) / 100000000) ((41840653 : ℝ) / 100000000) ((41840653 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_907.1 cov_log_907.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66370169 : ℝ) / 100000000) ((13283729 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((13257073 : ℝ) / 20000000) ((82941 : ℝ) / 125000) := rb_log hd (by norm_num) cov_log_903.1 cov_log_904.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((17369 : ℝ) / 100000000) ((833 : ℝ) / 625000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((1113 : ℝ) / 5000000) ((11647 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((12966359 : ℝ) / 10000000)) - (z19)
  have h20 : RB z20 ((16205037 : ℝ) / 12500000) ((12964133 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((12966359 : ℝ) / 10000000) ((12966359 : ℝ) / 10000000) ((12966359 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((2966359 : ℝ) / 10000000))
  have h21 : RB z21 ((87407017 : ℝ) / 20000000) ((109259643 : ℝ) / 25000000) := rb_div_signed h20 (show RB ((2966359 : ℝ) / 10000000) ((2966359 : ℝ) / 10000000) ((2966359 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((147484329 : ℝ) / 100000000) ((147485129 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_908.1 cov_log_909.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92606439 : ℝ) / 100000000) ((23204179 : ℝ) / 25000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((12966359 : ℝ) / 10000000))
  have h24 : RB z24 ((12988657 : ℝ) / 50000000) ((5195463 : ℝ) / 20000000) := rb_log (show RB ((12966359 : ℝ) / 10000000) ((12966359 : ℝ) / 10000000) ((12966359 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_910.1 cov_log_910.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16657281 : ℝ) / 25000000) ((33419701 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((13257073 : ℝ) / 20000000) ((82941 : ℝ) / 125000) := rb_log hd (by norm_num) cov_log_903.1 cov_log_904.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((69081 : ℝ) / 25000000) ((554037 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((1113 : ℝ) / 5000000) ((11647 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((13000971 : ℝ) / 10000000)) - (z28)
  have h29 : RB z29 ((8124151 : ℝ) / 6250000) ((2599749 : ℝ) / 2000000) := rb_widen (rb_sub (show RB ((13000971 : ℝ) / 10000000) ((13000971 : ℝ) / 10000000) ((13000971 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((3000971 : ℝ) / 10000000))
  have h30 : RB z30 ((433147857 : ℝ) / 100000000) ((54143913 : ℝ) / 12500000) := rb_div_signed h29 (show RB ((3000971 : ℝ) / 10000000) ((3000971 : ℝ) / 10000000) ((3000971 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((29318179 : ℝ) / 20000000) ((73295847 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_911.1 cov_log_912.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18409089 : ℝ) / 20000000) ((92254451 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((13000971 : ℝ) / 10000000))
  have h33 : RB z33 ((5248779 : ℝ) / 20000000) ((3280487 : ℝ) / 12500000) := rb_log (show RB ((13000971 : ℝ) / 10000000) ((13000971 : ℝ) / 10000000) ((13000971 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_913.1 cov_log_913.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((65801549 : ℝ) / 100000000) ((16502639 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((13257073 : ℝ) / 20000000) ((82941 : ℝ) / 125000) := rb_log hd (by norm_num) cov_log_903.1 cov_log_904.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-551251 : ℝ) / 100000000) ((-274809 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((41031769 : ℝ) / 100000000)) ((-128951 : ℝ) / 100000000) ((-1653 : ℝ) / 20000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((41840653 : ℝ) / 100000000)) ((17369 : ℝ) / 100000000) ((833 : ℝ) / 625000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((12966359 : ℝ) / 10000000)) ((69081 : ℝ) / 25000000) ((554037 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((13000971 : ℝ) / 10000000)) ((-551251 : ℝ) / 100000000) ((-274809 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_50 {k A q d vp vm : ℝ}
    (hk : RB k ((27 : ℝ) / 16) ((5433 : ℝ) / 3200))
    (hA : RB A ((27 : ℝ) / 43) ((5433 : ℝ) / 8633))
    (hq : RB q ((74599 : ℝ) / 5000000) ((763103 : ℝ) / 50000000))
    (hd : RB d ((38806429 : ℝ) / 20000000) ((194163031 : ℝ) / 100000000))
    (hp : RB vp ((41031769 : ℝ) / 100000000) ((41840653 : ℝ) / 100000000))
    (hm : RB vm ((12966359 : ℝ) / 10000000) ((13000971 : ℝ) / 10000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((1113 : ℝ) / 5000000) ((11647 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49988353 : ℝ) / 50000000) ((4998887 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((62776071 : ℝ) / 100000000) ((62918923 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((53201 : ℝ) / 100000000) ((56771 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99943229 : ℝ) / 100000000) ((99946799 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((58159347 : ℝ) / 100000000) ((58968231 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58126329 : ℝ) / 100000000) ((2946843 : ℝ) / 5000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((26628527 : ℝ) / 25000000) ((21649027 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((1628527 : ℝ) / 25000000) ((1649027 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49988353 : ℝ) / 50000000) ((4998887 : ℝ) / 5000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((62776071 : ℝ) / 100000000) ((62918923 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((17121 : ℝ) / 100000000) ((3593 : ℝ) / 20000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((19996407 : ℝ) / 20000000) ((99982879 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((2966359 : ℝ) / 10000000) ((3000971 : ℝ) / 10000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((1482913 : ℝ) / 5000000) ((30004573 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((209221677 : ℝ) / 100000000) ((106073187 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((309221677 : ℝ) / 100000000) ((156073187 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((606418209 : ℝ) / 50000000) ((1535129599 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((8009063 : ℝ) / 25000000) ((1616963 : ℝ) / 5000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((27 : ℝ) / 8) ((5433 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((629429 : ℝ) / 12500000) ((647803 : ℝ) / 12500000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((5074599 : ℝ) / 5000000) ((50763103 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((619967 : ℝ) / 12500000) ((15957 : ℝ) / 312500) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((13119967 : ℝ) / 12500000) ((328457 : ℝ) / 312500) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((87822937 : ℝ) / 100000000) ((88977941 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((21300591 : ℝ) / 12500000) ((43190567 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((831301 : ℝ) / 1562500) ((3399807 : ℝ) / 6250000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((40921 : ℝ) / 100000000) ((5473 : ℝ) / 12500000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((12494527 : ℝ) / 12500000) ((99959079 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((170330117 : ℝ) / 100000000) ((43172893 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((38806429 : ℝ) / 10000000) ((194163031 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((5789841 : ℝ) / 100000000) ((23151 : ℝ) / 390625) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((43 : ℝ) / 16) ((8633 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((536531 : ℝ) / 25000000) ((551317 : ℝ) / 25000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1782931 : ℝ) / 50000000) ((929893 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((51782931 : ℝ) / 50000000) ((25929893 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((125608449 : ℝ) / 10000000) ((31844597 : ℝ) / 2000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1147591 : ℝ) / 100000000) ((1177051 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101147591 : ℝ) / 100000000) ((101177051 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32403897 : ℝ) / 100000000) ((3271991 : ℝ) / 10000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1288488387 : ℝ) / 100000000) ((1269492 : ℝ) / 78125) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((13826279 : ℝ) / 50000000) ((17917249 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((43 : ℝ) / 16) ((8633 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((13119967 : ℝ) / 6250000) ((328457 : ℝ) / 156250) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((124487267 : ℝ) / 10000000) ((1567468859 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((522646027 : ℝ) / 20000000) ((1647507581 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8156259 : ℝ) / 100000000) ((1032367 : ℝ) / 10000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-125319231 : ℝ) / 50000000) ((-113536543 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_914.1 cov_log_915.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((72373 : ℝ) / 2500000) ((23151 : ℝ) / 781250) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-88555319 : ℝ) / 25000000) ((-175942861 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_916.1 cov_log_917.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((13257073 : ℝ) / 20000000) ((82941 : ℝ) / 125000) := rb_log hd (by norm_num) cov_log_903.1 cov_log_904.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((111856553 : ℝ) / 100000000) ((56327307 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-242364723 : ℝ) / 100000000) ((-59807777 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((430059 : ℝ) / 4000000) ((13112931 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((30003141 : ℝ) / 100000000) ((47420319 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-106180791 : ℝ) / 50000000) ((-191810789 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((13119967 : ℝ) / 12500000) ((328457 : ℝ) / 312500) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-125319231 : ℝ) / 50000000) ((-113536543 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-106180791 : ℝ) / 50000000) ((-191810789 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ (3 : ℝ) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1782931 : ℝ) / 50000000) ((929893 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((163 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((25929893 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : (3 : ℝ) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((163 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-44123933 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun (3 : ℝ) + hfun ((163 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_14, cov_h_10]
  have hP : ((573299543 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((191810789 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((191810789 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((61242007 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((163 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((237 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2593 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2593 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2633 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2633 : ℝ) / 1000)) (lo := ((2593 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2673 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2673 : ℝ) / 1000)) (lo := ((2633 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2713 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2713 : ℝ) / 1000)) (lo := ((2673 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2753 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2753 : ℝ) / 1000)) (lo := ((2713 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2793 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2793 : ℝ) / 1000)) (lo := ((2753 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2833 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2833 : ℝ) / 1000)) (lo := ((2793 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2873 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2873 : ℝ) / 1000)) (lo := ((2833 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2913 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2913 : ℝ) / 1000)) (lo := ((2873 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2953 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2953 : ℝ) / 1000)) (lo := ((2913 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2993 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2993 : ℝ) / 1000)) (lo := ((2953 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := (3 : ℝ)) (lo := ((2993 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_50 {k : ℝ} (hk : RB k ((27 : ℝ) / 16) ((5433 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((27 : ℝ) / 43) ((5433 : ℝ) / 8633) ∧
    RB (qa (r1A k)) ((74599 : ℝ) / 5000000) ((763103 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((38806429 : ℝ) / 20000000) ((194163031 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((27 : ℝ) / 64) ((42445313 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((188154687 : ℝ) / 100000000) ((15073 : ℝ) / 8000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((8573093 : ℝ) / 6250000) ((137263433 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((69647711 : ℝ) / 25000000) ((27868479 : ℝ) / 10000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69647711 : ℝ) / 50000000) ((27868479 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((38806429 : ℝ) / 20000000) ((194163031 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((927 : ℝ) / 8000) ((11845313 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((927 : ℝ) / 32000) ((2961329 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((74599 : ℝ) / 5000000) ((763103 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((38806429 : ℝ) / 20000000) ((194163031 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((74599 : ℝ) / 5000000) ((763103 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((27 : ℝ) / 43) ((5433 : ℝ) / 8633) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_50 {k : ℝ} (hk : RB k ((27 : ℝ) / 16) ((5433 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_50 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_50 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((41031769 : ℝ) / 100000000)) (ph := ((41840653 : ℝ) / 100000000)) (ml := ((12966359 : ℝ) / 10000000)) (mh := ((13000971 : ℝ) / 10000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_50 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_51 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5433 : ℝ) / 8633) ((2733 : ℝ) / 4333))
    (hq : RB (qa a) ((381551 : ℝ) / 25000000) ((1560477 : ℝ) / 100000000))
    (hd : RB (D0a a) ((193901219 : ℝ) / 100000000) ((24254019 : ℝ) / 12500000))
    : certE k a ((40947911 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((20870061 : ℝ) / 50000000) ∧ 0 < certE k a ((64889777 : ℝ) / 50000000) ∧ certE k a ((1301239 : ℝ) / 1000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((5823 : ℝ) / 25000000) ((24351 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40947911 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((1023089 : ℝ) / 2500000) ((40924619 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((40947911 : ℝ) / 100000000) ((40947911 : ℝ) / 100000000) ((40947911 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59052089 : ℝ) / 100000000))
  have h3 : RB z3 ((34650391 : ℝ) / 50000000) ((69302577 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((59052089 : ℝ) / 100000000) ((59052089 : ℝ) / 100000000) ((59052089 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-183357 : ℝ) / 500000) ((-36668809 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_918.1 cov_log_919.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-462603 : ℝ) / 2000000) ((-5769189 : ℝ) / 25000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40947911 : ℝ) / 100000000))
  have h6 : RB z6 ((-4464347 : ℝ) / 5000000) ((-44643469 : ℝ) / 50000000) := rb_log (show RB ((40947911 : ℝ) / 100000000) ((40947911 : ℝ) / 100000000) ((40947911 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_920.1 cov_log_920.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((16539197 : ℝ) / 25000000) ((8276273 : ℝ) / 12500000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((33108933 : ℝ) / 50000000) ((66285371 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_921.1 cov_log_922.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-128583 : ℝ) / 100000000) ((-3841 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((5823 : ℝ) / 25000000) ((24351 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((20870061 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((41715771 : ℝ) / 100000000) ((4171683 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((20870061 : ℝ) / 50000000) ((20870061 : ℝ) / 50000000) ((20870061 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((29129939 : ℝ) / 50000000))
  have h12 : RB z12 ((14320583 : ℝ) / 20000000) ((71604733 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((29129939 : ℝ) / 50000000) ((29129939 : ℝ) / 50000000) ((29129939 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-33403441 : ℝ) / 100000000) ((-33400901 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_923.1 cov_log_924.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-10534457 : ℝ) / 50000000) ((-10510083 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((20870061 : ℝ) / 50000000))
  have h15 : RB z15 ((-43685369 : ℝ) / 50000000) ((-5460671 : ℝ) / 6250000) := rb_log (show RB ((20870061 : ℝ) / 50000000) ((20870061 : ℝ) / 50000000) ((20870061 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_925.1 cov_log_925.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((33150911 : ℝ) / 50000000) ((16587643 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((33108933 : ℝ) / 50000000) ((66285371 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_921.1 cov_log_922.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((16451 : ℝ) / 100000000) ((66353 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((5823 : ℝ) / 25000000) ((24351 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((64889777 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((129755203 : ℝ) / 100000000) ((64878131 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((64889777 : ℝ) / 50000000) ((64889777 : ℝ) / 50000000) ((64889777 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((14889777 : ℝ) / 50000000))
  have h21 : RB z21 ((217859547 : ℝ) / 50000000) ((435722651 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((14889777 : ℝ) / 50000000) ((14889777 : ℝ) / 50000000) ((14889777 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((36795689 : ℝ) / 25000000) ((18397947 : ℝ) / 12500000) := rb_log h21 (by norm_num) cov_log_926.1 cov_log_927.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92626423 : ℝ) / 100000000) ((92834691 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((64889777 : ℝ) / 50000000))
  have h24 : RB z24 ((6516677 : ℝ) / 25000000) ((26066709 : ℝ) / 100000000) := rb_log (show RB ((64889777 : ℝ) / 50000000) ((64889777 : ℝ) / 50000000) ((64889777 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_928.1 cov_log_928.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33279857 : ℝ) / 50000000) ((66767983 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((33108933 : ℝ) / 50000000) ((66285371 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_921.1 cov_log_922.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((274343 : ℝ) / 100000000) ((550117 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((5823 : ℝ) / 25000000) ((24351 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((1301239 : ℝ) / 1000000)) - (z28)
  have h29 : RB z29 ((130099549 : ℝ) / 100000000) ((1016411 : ℝ) / 781250) := rb_widen (rb_sub (show RB ((1301239 : ℝ) / 1000000) ((1301239 : ℝ) / 1000000) ((1301239 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((301239 : ℝ) / 1000000))
  have h30 : RB z30 ((107970373 : ℝ) / 25000000) ((431885009 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((301239 : ℝ) / 1000000) ((301239 : ℝ) / 1000000) ((301239 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((146298103 : ℝ) / 100000000) ((146298921 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_929.1 cov_log_930.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18413937 : ℝ) / 20000000) ((92276703 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((1301239 : ℝ) / 1000000))
  have h33 : RB z33 ((3291461 : ℝ) / 12500000) ((26331689 : ℝ) / 100000000) := rb_log (show RB ((1301239 : ℝ) / 1000000) ((1301239 : ℝ) / 1000000) ((1301239 : ℝ) / 1000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_931.1 cov_log_931.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((16434499 : ℝ) / 25000000) ((13189003 : ℝ) / 20000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((33108933 : ℝ) / 50000000) ((66285371 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_921.1 cov_log_922.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-4379 : ℝ) / 800000) ((-272851 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40947911 : ℝ) / 100000000)) ((-128583 : ℝ) / 100000000) ((-3841 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((20870061 : ℝ) / 50000000)) ((16451 : ℝ) / 100000000) ((66353 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((64889777 : ℝ) / 50000000)) ((274343 : ℝ) / 100000000) ((550117 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((1301239 : ℝ) / 1000000)) ((-4379 : ℝ) / 800000) ((-272851 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_51 {k A q d vp vm : ℝ}
    (hk : RB k ((5433 : ℝ) / 3200) ((2733 : ℝ) / 1600))
    (hA : RB A ((5433 : ℝ) / 8633) ((2733 : ℝ) / 4333))
    (hq : RB q ((381551 : ℝ) / 25000000) ((1560477 : ℝ) / 100000000))
    (hd : RB d ((193901219 : ℝ) / 100000000) ((24254019 : ℝ) / 12500000))
    (hp : RB vp ((40947911 : ℝ) / 100000000) ((20870061 : ℝ) / 50000000))
    (hm : RB vm ((64889777 : ℝ) / 50000000) ((1301239 : ℝ) / 1000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((5823 : ℝ) / 25000000) ((24351 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99975649 : ℝ) / 100000000) ((24994177 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((31458803 : ℝ) / 50000000) ((985303 : ℝ) / 1562500) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((27901 : ℝ) / 50000000) ((59469 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99940531 : ℝ) / 100000000) ((49972099 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((29129939 : ℝ) / 50000000) ((59052089 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58225231 : ℝ) / 100000000) ((59019137 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((13325679 : ℝ) / 12500000) ((2707563 : ℝ) / 2500000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((825679 : ℝ) / 12500000) ((207563 : ℝ) / 2500000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99975649 : ℝ) / 100000000) ((24994177 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((31458803 : ℝ) / 50000000) ((985303 : ℝ) / 1562500) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((17899 : ℝ) / 100000000) ((4691 : ℝ) / 25000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((24995309 : ℝ) / 25000000) ((99982101 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((14889777 : ℝ) / 50000000) ((301239 : ℝ) / 1000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((14886983 : ℝ) / 50000000) ((30118509 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((41780027 : ℝ) / 20000000) ((211793727 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((61780027 : ℝ) / 20000000) ((311793727 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1204453587 : ℝ) / 100000000) ((756952763 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16036243 : ℝ) / 50000000) ((32372923 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5433 : ℝ) / 1600) ((2733 : ℝ) / 800) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((323901 : ℝ) / 6250000) ((266549 : ℝ) / 5000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((25381551 : ℝ) / 25000000) ((101560477 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1275697 : ℝ) / 25000000) ((2625421 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((26275697 : ℝ) / 25000000) ((52625421 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((11004929 : ℝ) / 12500000) ((89175989 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((170709531 : ℝ) / 100000000) ((173030091 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((207586 : ℝ) / 390625) ((434511 : ℝ) / 800000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((10721 : ℝ) / 25000000) ((45823 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99954177 : ℝ) / 100000000) ((24989279 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((85315653 : ℝ) / 50000000) ((172955889 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((193901219 : ℝ) / 50000000) ((24254019 : ℝ) / 6250000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((92479 : ℝ) / 1562500) ((1211131 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8633 : ℝ) / 3200) ((4333 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1092759 : ℝ) / 50000000) ((1122327 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((3656443 : ℝ) / 100000000) ((952721 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((103656443 : ℝ) / 100000000) ((25952721 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((249698749 : ℝ) / 20000000) ((157159871 : ℝ) / 10000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((234577 : ℝ) / 20000000) ((601203 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20234577 : ℝ) / 20000000) ((50601203 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32448659 : ℝ) / 100000000) ((32762177 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((320235601 : ℝ) / 25000000) ((1604360887 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((13997613 : ℝ) / 50000000) ((36012351 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8633 : ℝ) / 3200) ((4333 : ℝ) / 1600) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((26275697 : ℝ) / 12500000) ((52625421 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1236526073 : ℝ) / 100000000) ((1546278449 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1299623377 : ℝ) / 50000000) ((130197687 : ℝ) / 4000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8288357 : ℝ) / 100000000) ((2604721 : ℝ) / 25000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-249031847 : ℝ) / 100000000) ((-9046201 : ℝ) / 4000000) := rb_log h47 (by norm_num) cov_log_932.1 cov_log_933.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((92479 : ℝ) / 3125000) ((756957 : ℝ) / 25000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-176010401 : ℝ) / 50000000) ((-69946493 : ℝ) / 20000000) := rb_log h49 (by norm_num) cov_log_934.1 cov_log_935.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((33108933 : ℝ) / 50000000) ((66285371 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_921.1 cov_log_922.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((1405319 : ℝ) / 1250000) ((1132237 : ℝ) / 1000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-119797641 : ℝ) / 50000000) ((-47301753 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((5243579 : ℝ) / 50000000) ((6405871 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((29121003 : ℝ) / 100000000) ((1830561 : ℝ) / 4000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-210474279 : ℝ) / 100000000) ((-9537237 : ℝ) / 5000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((26275697 : ℝ) / 25000000) ((52625421 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-249031847 : ℝ) / 100000000) ((-9046201 : ℝ) / 4000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-210474279 : ℝ) / 100000000) ((-9537237 : ℝ) / 5000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((299 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((3656443 : ℝ) / 100000000) ((952721 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((41 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((25952721 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((299 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((41 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-218857581 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((299 : ℝ) / 100) + hfun ((41 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_15, cov_h_13]
  have hP : ((284664991 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((9537237 : ℝ) / 5000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((9537237 : ℝ) / 5000000))
    linarith [hap.2]
  have hS : ((60829403 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((41 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((277 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((649 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((649 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((659 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((659 : ℝ) / 250)) (lo := ((649 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((669 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((669 : ℝ) / 250)) (lo := ((659 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((679 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((679 : ℝ) / 250)) (lo := ((669 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((689 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((689 : ℝ) / 250)) (lo := ((679 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((699 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((699 : ℝ) / 250)) (lo := ((689 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((709 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((709 : ℝ) / 250)) (lo := ((699 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((719 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((719 : ℝ) / 250)) (lo := ((709 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((729 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((729 : ℝ) / 250)) (lo := ((719 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((739 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((739 : ℝ) / 250)) (lo := ((729 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((299 : ℝ) / 100)) (lo := ((739 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_51 {k : ℝ} (hk : RB k ((5433 : ℝ) / 3200) ((2733 : ℝ) / 1600)) :
    RB (k / (k + 1)) ((5433 : ℝ) / 8633) ((2733 : ℝ) / 4333) ∧
    RB (qa (r1A k)) ((381551 : ℝ) / 25000000) ((1560477 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((193901219 : ℝ) / 100000000) ((24254019 : ℝ) / 12500000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((165802 : ℝ) / 390625) ((2733 : ℝ) / 6400) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((60127 : ℝ) / 32000) ((2939917 : ℝ) / 1562500) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((137075481 : ℝ) / 100000000) ((13716949 : ℝ) / 10000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((278496837 : ℝ) / 100000000) ((278590847 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69624209 : ℝ) / 50000000) ((2176491 : ℝ) / 1562500) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((193901219 : ℝ) / 100000000) ((24254019 : ℝ) / 12500000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((185083 : ℝ) / 1562500) ((3873 : ℝ) / 32000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((185083 : ℝ) / 6250000) ((1512891 : ℝ) / 50000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((381551 : ℝ) / 25000000) ((1560477 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((193901219 : ℝ) / 100000000) ((24254019 : ℝ) / 12500000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((381551 : ℝ) / 25000000) ((1560477 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5433 : ℝ) / 8633) ((2733 : ℝ) / 4333) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_51 {k : ℝ} (hk : RB k ((5433 : ℝ) / 3200) ((2733 : ℝ) / 1600)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_51 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_51 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40947911 : ℝ) / 100000000)) (ph := ((20870061 : ℝ) / 50000000)) (ml := ((64889777 : ℝ) / 50000000)) (mh := ((1301239 : ℝ) / 1000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_51 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_52 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((2733 : ℝ) / 4333) ((5499 : ℝ) / 8699))
    (hq : RB (qa a) ((62419 : ℝ) / 4000000) ((797397 : ℝ) / 50000000))
    (hd : RB (D0a a) ((193770247 : ℝ) / 100000000) ((7756049 : ℝ) / 4000000))
    : certE k a ((40865461 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((41641917 : ℝ) / 100000000) ∧ 0 < certE k a ((3247373 : ℝ) / 2500000) ∧ certE k a ((65118757 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((487 : ℝ) / 2000000) ((12717 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((40865461 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((40840027 : ℝ) / 100000000) ((40841111 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((40865461 : ℝ) / 100000000) ((40865461 : ℝ) / 100000000) ((40865461 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((59134539 : ℝ) / 100000000))
  have h3 : RB z3 ((69062899 : ℝ) / 100000000) ((69064733 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((59134539 : ℝ) / 100000000) ((59134539 : ℝ) / 100000000) ((59134539 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-9253813 : ℝ) / 25000000) ((-9253149 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_936.1 cov_log_937.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-11699441 : ℝ) / 50000000) ((-4669071 : ℝ) / 20000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((40865461 : ℝ) / 100000000))
  have h6 : RB z6 ((-89488497 : ℝ) / 100000000) ((-17897699 : ℝ) / 20000000) := rb_log (show RB ((40865461 : ℝ) / 100000000) ((40865461 : ℝ) / 100000000) ((40865461 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_938.1 cov_log_938.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((66089613 : ℝ) / 100000000) ((33071571 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66150297 : ℝ) / 100000000) ((66217871 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_939.1 cov_log_940.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-64129 : ℝ) / 50000000) ((-1431 : ℝ) / 20000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((487 : ℝ) / 2000000) ((12717 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((41641917 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((41616483 : ℝ) / 100000000) ((41617567 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((41641917 : ℝ) / 100000000) ((41641917 : ℝ) / 100000000) ((41641917 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((58358083 : ℝ) / 100000000))
  have h12 : RB z12 ((14262457 : ℝ) / 20000000) ((2228567 : ℝ) / 3125000) := rb_div_signed h11 (show RB ((58358083 : ℝ) / 100000000) ((58358083 : ℝ) / 100000000) ((58358083 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-16905079 : ℝ) / 50000000) ((-676151 : ℝ) / 2000000) := rb_log h12 (by norm_num) cov_log_941.1 cov_log_942.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-21372809 : ℝ) / 100000000) ((-10661901 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((41641917 : ℝ) / 100000000))
  have h15 : RB z15 ((-21901573 : ℝ) / 25000000) ((-8760629 : ℝ) / 10000000) := rb_log (show RB ((41641917 : ℝ) / 100000000) ((41641917 : ℝ) / 100000000) ((41641917 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_943.1 cov_log_943.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66233481 : ℝ) / 100000000) ((6628249 : ℝ) / 10000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66150297 : ℝ) / 100000000) ((66217871 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_939.1 cov_log_940.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((1561 : ℝ) / 10000000) ((132193 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((487 : ℝ) / 2000000) ((12717 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((3247373 : ℝ) / 2500000)) - (z19)
  have h20 : RB z20 ((64934743 : ℝ) / 50000000) ((12987057 : ℝ) / 10000000) := rb_widen (rb_sub (show RB ((3247373 : ℝ) / 2500000) ((3247373 : ℝ) / 2500000) ((3247373 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((747373 : ℝ) / 2500000))
  have h21 : RB z21 ((217209957 : ℝ) / 50000000) ((434423541 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((747373 : ℝ) / 2500000) ((747373 : ℝ) / 2500000) ((747373 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((73442071 : ℝ) / 50000000) ((7344249 : ℝ) / 5000000) := rb_log h21 (by norm_num) cov_log_944.1 cov_log_945.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((3705833 : ℝ) / 4000000) ((92852111 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((3247373 : ℝ) / 2500000))
  have h24 : RB z24 ((13077781 : ℝ) / 50000000) ((26155563 : ℝ) / 100000000) := rb_log (show RB ((3247373 : ℝ) / 2500000) ((3247373 : ℝ) / 2500000) ((3247373 : ℝ) / 2500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_946.1 cov_log_946.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((33245131 : ℝ) / 50000000) ((66696549 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66150297 : ℝ) / 100000000) ((66217871 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_939.1 cov_log_940.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((272391 : ℝ) / 100000000) ((136563 : ℝ) / 25000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((487 : ℝ) / 2000000) ((12717 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((65118757 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((1627651 : ℝ) / 1250000) ((32553291 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((65118757 : ℝ) / 50000000) ((65118757 : ℝ) / 50000000) ((65118757 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((15118757 : ℝ) / 50000000))
  have h30 : RB z30 ((53828863 : ℝ) / 12500000) ((43063449 : ℝ) / 10000000) := rb_div_signed h29 (show RB ((15118757 : ℝ) / 50000000) ((15118757 : ℝ) / 50000000) ((15118757 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((36502029 : ℝ) / 25000000) ((18251119 : ℝ) / 12500000) := rb_log h30 (by norm_num) cov_log_947.1 cov_log_948.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((92093279 : ℝ) / 100000000) ((92298337 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((65118757 : ℝ) / 50000000))
  have h33 : RB z33 ((13209481 : ℝ) / 50000000) ((26418963 : ℝ) / 100000000) := rb_log (show RB ((65118757 : ℝ) / 50000000) ((65118757 : ℝ) / 50000000) ((65118757 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_949.1 cov_log_949.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((16418579 : ℝ) / 25000000) ((105407 : ℝ) / 160000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66150297 : ℝ) / 100000000) ((66217871 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_939.1 cov_log_940.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-108711 : ℝ) / 20000000) ((-135461 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((40865461 : ℝ) / 100000000)) ((-64129 : ℝ) / 50000000) ((-1431 : ℝ) / 20000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((41641917 : ℝ) / 100000000)) ((1561 : ℝ) / 10000000) ((132193 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((3247373 : ℝ) / 2500000)) ((272391 : ℝ) / 100000000) ((136563 : ℝ) / 25000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((65118757 : ℝ) / 50000000)) ((-108711 : ℝ) / 20000000) ((-135461 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_52 {k A q d vp vm : ℝ}
    (hk : RB k ((2733 : ℝ) / 1600) ((5499 : ℝ) / 3200))
    (hA : RB A ((2733 : ℝ) / 4333) ((5499 : ℝ) / 8699))
    (hq : RB q ((62419 : ℝ) / 4000000) ((797397 : ℝ) / 50000000))
    (hd : RB d ((193770247 : ℝ) / 100000000) ((7756049 : ℝ) / 4000000))
    (hp : RB vp ((40865461 : ℝ) / 100000000) ((41641917 : ℝ) / 100000000))
    (hm : RB vm ((3247373 : ℝ) / 2500000) ((65118757 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((487 : ℝ) / 2000000) ((12717 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49987283 : ℝ) / 50000000) ((1999513 : ℝ) / 2000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((1576451 : ℝ) / 2500000) ((6319877 : ℝ) / 10000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((29237 : ℝ) / 50000000) ((62239 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99937761 : ℝ) / 100000000) ((49970763 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((58358083 : ℝ) / 100000000) ((59134539 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58321761 : ℝ) / 100000000) ((59099961 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106697261 : ℝ) / 100000000) ((54181123 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6697261 : ℝ) / 100000000) ((4181123 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49987283 : ℝ) / 50000000) ((1999513 : ℝ) / 2000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((1576451 : ℝ) / 2500000) ((6319877 : ℝ) / 10000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((2337 : ℝ) / 12500000) ((19581 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99980419 : ℝ) / 100000000) ((12497663 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((747373 : ℝ) / 2500000) ((15118757 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((14944533 : ℝ) / 50000000) ((30231861 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((208581403 : ℝ) / 100000000) ((105722223 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((308581403 : ℝ) / 100000000) ((155722223 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1195850971 : ℝ) / 100000000) ((746573861 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6421691 : ℝ) / 20000000) ((810159 : ℝ) / 2500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((2733 : ℝ) / 800) ((5499 : ℝ) / 1600) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((1332743 : ℝ) / 25000000) ((1370277 : ℝ) / 25000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((4062419 : ℝ) / 4000000) ((50797397 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((655911 : ℝ) / 12500000) ((5396891 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((13155911 : ℝ) / 12500000) ((105396891 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((88253003 : ℝ) / 100000000) ((89372053 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((171008061 : ℝ) / 100000000) ((86646753 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((53082157 : ℝ) / 100000000) ((27116699 : ℝ) / 50000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((22449 : ℝ) / 50000000) ((9583 : ℝ) / 20000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((19990417 : ℝ) / 20000000) ((49977551 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((85463061 : ℝ) / 50000000) ((173215701 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((193770247 : ℝ) / 50000000) ((7756049 : ℝ) / 2000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((377967 : ℝ) / 6250000) ((6184651 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((4333 : ℝ) / 1600) ((8699 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2224613 : ℝ) / 100000000) ((114187 : ℝ) / 5000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((749473 : ℝ) / 20000000) ((975637 : ℝ) / 25000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((20749473 : ℝ) / 20000000) ((25975637 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((1240663871 : ℝ) / 100000000) ((1551418529 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((37443 : ℝ) / 3125000) ((613879 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((3162443 : ℝ) / 3125000) ((50613879 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((3249317 : ℝ) / 10000000) ((4100529 : ℝ) / 12500000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1273157041 : ℝ) / 100000000) ((1584222761 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((28322817 : ℝ) / 100000000) ((36179529 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((4333 : ℝ) / 1600) ((8699 : ℝ) / 3200) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((13155911 : ℝ) / 6250000) ((105396891 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((613979713 : ℝ) / 50000000) ((762777041 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((2584787987 : ℝ) / 100000000) ((1607886573 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((421069 : ℝ) / 5000000) ((5258531 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-247439651 : ℝ) / 100000000) ((-225217129 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_950.1 cov_log_951.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((377967 : ℝ) / 12500000) ((1546163 : ℝ) / 50000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-349867709 : ℝ) / 100000000) ((-173812331 : ℝ) / 50000000) := rb_log h49 (by norm_num) cov_log_952.1 cov_log_953.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66150297 : ℝ) / 100000000) ((66217871 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_939.1 cov_log_940.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((7062061 : ℝ) / 6250000) ((113791273 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-236874733 : ℝ) / 100000000) ((-233833389 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((5113673 : ℝ) / 50000000) ((6258463 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((14134161 : ℝ) / 50000000) ((4419379 : ℝ) / 10000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-208606411 : ℝ) / 100000000) ((-189639599 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((13155911 : ℝ) / 12500000) ((105396891 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-247439651 : ℝ) / 100000000) ((-225217129 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-208606411 : ℝ) / 100000000) ((-189639599 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((299 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((749473 : ℝ) / 20000000) ((975637 : ℝ) / 25000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((41 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((25975637 : ℝ) / 50000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((299 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((41 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-43453077 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((299 : ℝ) / 100) + hfun ((41 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_15, cov_h_13]
  have hP : ((565247033 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((189639599 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((189639599 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((60829403 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((41 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((277 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((649 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((649 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((659 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((659 : ℝ) / 250)) (lo := ((649 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((669 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((669 : ℝ) / 250)) (lo := ((659 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((679 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((679 : ℝ) / 250)) (lo := ((669 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((689 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((689 : ℝ) / 250)) (lo := ((679 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((699 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((699 : ℝ) / 250)) (lo := ((689 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((709 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((709 : ℝ) / 250)) (lo := ((699 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((719 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((719 : ℝ) / 250)) (lo := ((709 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((729 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((729 : ℝ) / 250)) (lo := ((719 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((739 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((739 : ℝ) / 250)) (lo := ((729 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((299 : ℝ) / 100)) (lo := ((739 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_52 {k : ℝ} (hk : RB k ((2733 : ℝ) / 1600) ((5499 : ℝ) / 3200)) :
    RB (k / (k + 1)) ((2733 : ℝ) / 4333) ((5499 : ℝ) / 8699) ∧
    RB (qa (r1A k)) ((62419 : ℝ) / 4000000) ((797397 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((193770247 : ℝ) / 100000000) ((7756049 : ℝ) / 4000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((2733 : ℝ) / 6400) ((21480469 : ℝ) / 50000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((93819531 : ℝ) / 50000000) ((60127 : ℝ) / 32000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((4280669 : ℝ) / 3125000) ((68537741 : ℝ) / 50000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((69600691 : ℝ) / 25000000) ((278496839 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((69600691 : ℝ) / 50000000) ((6962421 : ℝ) / 5000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((193770247 : ℝ) / 100000000) ((7756049 : ℝ) / 4000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((3873 : ℝ) / 32000) ((6180469 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((3025781 : ℝ) / 100000000) ((618047 : ℝ) / 20000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((62419 : ℝ) / 4000000) ((797397 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((193770247 : ℝ) / 100000000) ((7756049 : ℝ) / 4000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((62419 : ℝ) / 4000000) ((797397 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((2733 : ℝ) / 4333) ((5499 : ℝ) / 8699) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_52 {k : ℝ} (hk : RB k ((2733 : ℝ) / 1600) ((5499 : ℝ) / 3200)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_52 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_52 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((40865461 : ℝ) / 100000000)) (ph := ((41641917 : ℝ) / 100000000)) (ml := ((3247373 : ℝ) / 2500000)) (mh := ((65118757 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_52 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_53 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((5499 : ℝ) / 8699) ((1383 : ℝ) / 2183))
    (hq : RB (qa a) ((199349 : ℝ) / 12500000) ((814579 : ℝ) / 50000000))
    (hd : RB (D0a a) ((48409807 : ℝ) / 25000000) ((193770251 : ℝ) / 100000000))
    : certE k a ((20392171 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((41545909 : ℝ) / 100000000) ∧ 0 < certE k a ((65004847 : ℝ) / 50000000) ∧ certE k a ((130350559 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((25433 : ℝ) / 100000000) ((13271 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((20392171 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((203789 : ℝ) / 500000) ((40758909 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((20392171 : ℝ) / 50000000) ((20392171 : ℝ) / 50000000) ((20392171 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((29607829 : ℝ) / 50000000))
  have h3 : RB z3 ((6882943 : ℝ) / 10000000) ((8603913 : ℝ) / 12500000) := rb_div_signed h2 (show RB ((29607829 : ℝ) / 50000000) ((29607829 : ℝ) / 50000000) ((29607829 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-18676939 : ℝ) / 50000000) ((-18675577 : ℝ) / 50000000) := rb_log h3 (by norm_num) cov_log_954.1 cov_log_955.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-23664871 : ℝ) / 100000000) ((-23611219 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((20392171 : ℝ) / 50000000))
  have h6 : RB z6 ((-89687197 : ℝ) / 100000000) ((-17937439 : ℝ) / 20000000) := rb_log (show RB ((20392171 : ℝ) / 50000000) ((20392171 : ℝ) / 50000000) ((20392171 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_956.1 cov_log_956.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((16505581 : ℝ) / 25000000) ((33037989 : ℝ) / 50000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66082659 : ℝ) / 100000000) ((66150301 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_957.1 cov_log_958.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-127977 : ℝ) / 100000000) ((-6681 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((25433 : ℝ) / 100000000) ((13271 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((41545909 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((41519367 : ℝ) / 100000000) ((10380119 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((41545909 : ℝ) / 100000000) ((41545909 : ℝ) / 100000000) ((41545909 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((58454091 : ℝ) / 100000000))
  have h12 : RB z12 ((35514509 : ℝ) / 50000000) ((17757729 : ℝ) / 25000000) := rb_div_signed h11 (show RB ((58454091 : ℝ) / 100000000) ((58454091 : ℝ) / 100000000) ((58454091 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-34208169 : ℝ) / 100000000) ((-4275687 : ℝ) / 12500000) := rb_log h12 (by norm_num) cov_log_959.1 cov_log_960.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-4334393 : ℝ) / 20000000) ((-21622717 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((41545909 : ℝ) / 100000000))
  have h15 : RB z15 ((-43918557 : ℝ) / 50000000) ((-10979639 : ℝ) / 12500000) := rb_log (show RB ((41545909 : ℝ) / 100000000) ((41545909 : ℝ) / 100000000) ((41545909 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_961.1 cov_log_961.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66165147 : ℝ) / 100000000) ((66214397 : ℝ) / 100000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66082659 : ℝ) / 100000000) ((66150301 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_957.1 cov_log_958.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((7423 : ℝ) / 50000000) ((65869 : ℝ) / 50000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((25433 : ℝ) / 100000000) ((13271 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((65004847 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((8123947 : ℝ) / 6250000) ((129984261 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((65004847 : ℝ) / 50000000) ((65004847 : ℝ) / 50000000) ((65004847 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((15004847 : ℝ) / 50000000))
  have h21 : RB z21 ((108284303 : ℝ) / 25000000) ((108285227 : ℝ) / 25000000) := rb_div_signed h20 (show RB ((15004847 : ℝ) / 50000000) ((15004847 : ℝ) / 50000000) ((15004847 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((146588437 : ℝ) / 100000000) ((73294647 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_962.1 cov_log_963.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23166163 : ℝ) / 25000000) ((18573797 : ℝ) / 20000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((65004847 : ℝ) / 50000000))
  have h24 : RB z24 ((26243883 : ℝ) / 100000000) ((6560971 : ℝ) / 25000000) := rb_log (show RB ((65004847 : ℝ) / 50000000) ((65004847 : ℝ) / 50000000) ((65004847 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_964.1 cov_log_964.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((2075649 : ℝ) / 3125000) ((33312551 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66082659 : ℝ) / 100000000) ((66150301 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_957.1 cov_log_958.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((270467 : ℝ) / 100000000) ((542443 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((25433 : ℝ) / 100000000) ((13271 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((130350559 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((130324017 : ℝ) / 100000000) ((65162563 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((130350559 : ℝ) / 100000000) ((130350559 : ℝ) / 100000000) ((130350559 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((30350559 : ℝ) / 100000000))
  have h30 : RB z30 ((429395771 : ℝ) / 100000000) ((214699713 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((30350559 : ℝ) / 100000000) ((30350559 : ℝ) / 100000000) ((30350559 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((36430221 : ℝ) / 25000000) ((145721739 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_965.1 cov_log_966.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((23029059 : ℝ) / 25000000) ((92319361 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((130350559 : ℝ) / 100000000))
  have h33 : RB z33 ((6626431 : ℝ) / 25000000) ((1060229 : ℝ) / 4000000) := rb_log (show RB ((130350559 : ℝ) / 100000000) ((130350559 : ℝ) / 100000000) ((130350559 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_967.1 cov_log_967.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((65610511 : ℝ) / 100000000) ((65813637 : ℝ) / 100000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66082659 : ℝ) / 100000000) ((66150301 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_957.1 cov_log_958.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-53979 : ℝ) / 10000000) ((-134511 : ℝ) / 50000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((20392171 : ℝ) / 50000000)) ((-127977 : ℝ) / 100000000) ((-6681 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((41545909 : ℝ) / 100000000)) ((7423 : ℝ) / 50000000) ((65869 : ℝ) / 50000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((65004847 : ℝ) / 50000000)) ((270467 : ℝ) / 100000000) ((542443 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((130350559 : ℝ) / 100000000)) ((-53979 : ℝ) / 10000000) ((-134511 : ℝ) / 50000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_53 {k A q d vp vm : ℝ}
    (hk : RB k ((5499 : ℝ) / 3200) ((1383 : ℝ) / 800))
    (hA : RB A ((5499 : ℝ) / 8699) ((1383 : ℝ) / 2183))
    (hq : RB q ((199349 : ℝ) / 12500000) ((814579 : ℝ) / 50000000))
    (hd : RB d ((48409807 : ℝ) / 25000000) ((193770251 : ℝ) / 100000000))
    (hp : RB vp ((20392171 : ℝ) / 50000000) ((41545909 : ℝ) / 100000000))
    (hm : RB vm ((65004847 : ℝ) / 50000000) ((130350559 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((25433 : ℝ) / 100000000) ((13271 : ℝ) / 50000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((49986729 : ℝ) / 50000000) ((99974567 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((7899673 : ℝ) / 12500000) ((3958567 : ℝ) / 6250000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((1913 : ℝ) / 3125000) ((65079 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99934921 : ℝ) / 100000000) ((3123087 : ℝ) / 3125000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((58454091 : ℝ) / 100000000) ((29607829 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((58416049 : ℝ) / 100000000) ((59179409 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((106789481 : ℝ) / 100000000) ((21684819 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((6789481 : ℝ) / 100000000) ((1684819 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((49986729 : ℝ) / 50000000) ((99974567 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((7899673 : ℝ) / 12500000) ((3958567 : ℝ) / 6250000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((19511 : ℝ) / 100000000) ((319 : ℝ) / 1562500) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((1562181 : ℝ) / 1562500) ((99980489 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((15004847 : ℝ) / 50000000) ((30350559 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((30003567 : ℝ) / 100000000) ((15172319 : ℝ) / 50000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((208265407 : ℝ) / 100000000) ((105549237 : ℝ) / 50000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((308265407 : ℝ) / 100000000) ((155549237 : ℝ) / 50000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((1187071133 : ℝ) / 100000000) ((1472866631 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((16072081 : ℝ) / 50000000) ((32439579 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((5499 : ℝ) / 1600) ((1383 : ℝ) / 400) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((54811 : ℝ) / 1000000) ((2816407 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((12699349 : ℝ) / 12500000) ((50814579 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((1078647 : ℝ) / 20000000) ((5544393 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((21078647 : ℝ) / 20000000) ((105544393 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((17692757 : ℝ) / 20000000) ((89566217 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((17130059 : ℝ) / 10000000) ((43388171 : ℝ) / 25000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((26511799 : ℝ) / 50000000) ((2166213 : ℝ) / 4000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((46963 : ℝ) / 100000000) ((50057 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99949943 : ℝ) / 100000000) ((99953037 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((85607421 : ℝ) / 50000000) ((173471179 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((48409807 : ℝ) / 12500000) ((193770251 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((1235257 : ℝ) / 20000000) ((394603 : ℝ) / 6250000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((8699 : ℝ) / 3200) ((2183 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((2263411 : ℝ) / 100000000) ((2322529 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((30709 : ℝ) / 800000) ((499321 : ℝ) / 12500000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((830709 : ℝ) / 800000) ((12999321 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((616319171 : ℝ) / 50000000) ((1531701291 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1223463 : ℝ) / 100000000) ((626553 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101223463 : ℝ) / 100000000) ((50626553 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32537433 : ℝ) / 100000000) ((16423041 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((50607031 : ℝ) / 4000000) ((1564547373 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((28636127 : ℝ) / 100000000) ((36337067 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((8699 : ℝ) / 3200) ((2183 : ℝ) / 800) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((21078647 : ℝ) / 10000000) ((105544393 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((243843059 : ℝ) / 20000000) ((150530621 : ℝ) / 10000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1284970441 : ℝ) / 50000000) ((635506521 : ℝ) / 20000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8555183 : ℝ) / 100000000) ((10617949 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-61465823 : ℝ) / 25000000) ((-224262431 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_968.1 cov_log_969.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((1544071 : ℝ) / 50000000) ((394603 : ℝ) / 12500000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-173880031 : ℝ) / 50000000) ((-86390093 : ℝ) / 25000000) := rb_log h49 (by norm_num) cov_log_970.1 cov_log_971.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66082659 : ℝ) / 100000000) ((66150301 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_957.1 cov_log_958.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((113558919 : ℝ) / 100000000) ((114357333 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-234201143 : ℝ) / 100000000) ((-231203039 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2492967 : ℝ) / 25000000) ((6114103 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((107198 : ℝ) / 390625) ((1708081 : ℝ) / 4000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-41351691 : ℝ) / 20000000) ((-94250507 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((21078647 : ℝ) / 20000000) ((105544393 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-61465823 : ℝ) / 25000000) ((-224262431 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-41351691 : ℝ) / 20000000) ((-94250507 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((299 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((30709 : ℝ) / 800000) ((499321 : ℝ) / 12500000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((41 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((12999321 : ℝ) / 25000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((299 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((41 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-107844513 : ℝ) / 50000000) ≤ formC0 k A q vp vm + hfun ((299 : ℝ) / 100) + hfun ((41 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_15, cov_h_13]
  have hP : ((280534057 : ℝ) / 50000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((94250507 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((94250507 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((60829403 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((41 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((277 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((649 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((649 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((659 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((659 : ℝ) / 250)) (lo := ((649 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((669 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((669 : ℝ) / 250)) (lo := ((659 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((679 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((679 : ℝ) / 250)) (lo := ((669 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((689 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((689 : ℝ) / 250)) (lo := ((679 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((699 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((699 : ℝ) / 250)) (lo := ((689 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((709 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((709 : ℝ) / 250)) (lo := ((699 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((719 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((719 : ℝ) / 250)) (lo := ((709 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((729 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((729 : ℝ) / 250)) (lo := ((719 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((739 : ℝ) / 250) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((739 : ℝ) / 250)) (lo := ((729 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((299 : ℝ) / 100)) (lo := ((739 : ℝ) / 250)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_53 {k : ℝ} (hk : RB k ((5499 : ℝ) / 3200) ((1383 : ℝ) / 800)) :
    RB (k / (k + 1)) ((5499 : ℝ) / 8699) ((1383 : ℝ) / 2183) ∧
    RB (qa (r1A k)) ((199349 : ℝ) / 12500000) ((814579 : ℝ) / 50000000) ∧ RB (D0a (r1A k)) ((48409807 : ℝ) / 25000000) ((193770251 : ℝ) / 100000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((42960937 : ℝ) / 100000000) ((1383 : ℝ) / 3200) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((29981 : ℝ) / 16000) ((187639063 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((136887271 : ℝ) / 100000000) ((136981409 : ℝ) / 100000000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((278308627 : ℝ) / 100000000) ((139201383 : ℝ) / 50000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((139154313 : ℝ) / 100000000) ((139201383 : ℝ) / 100000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((48409807 : ℝ) / 25000000) ((193770251 : ℝ) / 100000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((12360937 : ℝ) / 100000000) ((2019 : ℝ) / 16000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((1545117 : ℝ) / 50000000) ((12323 : ℝ) / 390625) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((199349 : ℝ) / 12500000) ((814579 : ℝ) / 50000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((48409807 : ℝ) / 25000000) ((193770251 : ℝ) / 100000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((199349 : ℝ) / 12500000) ((814579 : ℝ) / 50000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((5499 : ℝ) / 8699) ((1383 : ℝ) / 2183) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_53 {k : ℝ} (hk : RB k ((5499 : ℝ) / 3200) ((1383 : ℝ) / 800)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_53 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_53 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((20392171 : ℝ) / 50000000)) (ph := ((41545909 : ℝ) / 100000000)) (ml := ((65004847 : ℝ) / 50000000)) (mh := ((130350559 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_53 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_54 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1383 : ℝ) / 2183) ((1113 : ℝ) / 1753))
    (hq : RB (qa a) ((407289 : ℝ) / 25000000) ((1663569 : ℝ) / 100000000))
    (hd : RB (D0a a) ((48377041 : ℝ) / 25000000) ((96819617 : ℝ) / 50000000))
    : certE k a ((20352241 : ℝ) / 50000000) < 0 ∧ 0 < certE k a ((20725989 : ℝ) / 50000000) ∧ 0 < certE k a ((32530971 : ℝ) / 25000000) ∧ certE k a ((65231521 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((26541 : ℝ) / 100000000) ((1107 : ℝ) / 4000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((20352241 : ℝ) / 50000000)) - (z1)
  have h2 : RB z2 ((40676807 : ℝ) / 100000000) ((40677941 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((20352241 : ℝ) / 50000000) ((20352241 : ℝ) / 50000000) ((20352241 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((29647759 : ℝ) / 50000000))
  have h3 : RB z3 ((68600137 : ℝ) / 100000000) ((68602051 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((29647759 : ℝ) / 50000000) ((29647759 : ℝ) / 50000000) ((29647759 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-18843783 : ℝ) / 50000000) ((-1507391 : ℝ) / 4000000) := rb_log h3 (by norm_num) cov_log_972.1 cov_log_973.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-23928273 : ℝ) / 100000000) ((-2984313 : ℝ) / 12500000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((20352241 : ℝ) / 50000000))
  have h6 : RB z6 ((-89883199 : ℝ) / 100000000) ((-89883197 : ℝ) / 100000000) := rb_log (show RB ((20352241 : ℝ) / 50000000) ((20352241 : ℝ) / 50000000) ((20352241 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_974.1 cov_log_974.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((16488731 : ℝ) / 25000000) ((13201739 : ℝ) / 20000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((66014951 : ℝ) / 100000000) ((8260333 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_975.1 cov_log_976.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-6387 : ℝ) / 5000000) ((-391 : ℝ) / 6250000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((26541 : ℝ) / 100000000) ((1107 : ℝ) / 4000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((20725989 : ℝ) / 50000000)) - (z10)
  have h11 : RB z11 ((41424303 : ℝ) / 100000000) ((41425437 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((20725989 : ℝ) / 50000000) ((20725989 : ℝ) / 50000000) ((20725989 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((29274011 : ℝ) / 50000000))
  have h12 : RB z12 ((35376347 : ℝ) / 50000000) ((8844329 : ℝ) / 12500000) := rb_div_signed h11 (show RB ((29274011 : ℝ) / 50000000) ((29274011 : ℝ) / 50000000) ((29274011 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-17298979 : ℝ) / 50000000) ((-17297609 : ℝ) / 50000000) := rb_log h12 (by norm_num) cov_log_977.1 cov_log_978.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-4393329 : ℝ) / 20000000) ((-5479293 : ℝ) / 25000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((20725989 : ℝ) / 50000000))
  have h15 : RB z15 ((-4403173 : ℝ) / 5000000) ((-44031729 : ℝ) / 50000000) := rb_log (show RB ((20725989 : ℝ) / 50000000) ((20725989 : ℝ) / 50000000) ((20725989 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_979.1 cov_log_979.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((66096813 : ℝ) / 100000000) ((4134143 : ℝ) / 6250000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((66014951 : ℝ) / 100000000) ((8260333 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_975.1 cov_log_976.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((14149 : ℝ) / 100000000) ((131337 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((26541 : ℝ) / 100000000) ((1107 : ℝ) / 4000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((32530971 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((130096209 : ℝ) / 100000000) ((130097343 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((32530971 : ℝ) / 25000000) ((32530971 : ℝ) / 25000000) ((32530971 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((7530971 : ℝ) / 25000000))
  have h21 : RB z21 ((215935317 : ℝ) / 50000000) ((539843 : ℝ) / 125000) := rb_div_signed h20 (show RB ((7530971 : ℝ) / 25000000) ((7530971 : ℝ) / 25000000) ((7530971 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((146295589 : ℝ) / 100000000) ((9143529 : ℝ) / 6250000) := rb_log h21 (by norm_num) cov_log_980.1 cov_log_981.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((92682913 : ℝ) / 100000000) ((2322133 : ℝ) / 2500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((32530971 : ℝ) / 25000000))
  have h24 : RB z24 ((6582919 : ℝ) / 25000000) ((26331677 : ℝ) / 100000000) := rb_log (show RB ((32530971 : ℝ) / 25000000) ((32530971 : ℝ) / 25000000) ((32530971 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_982.1 cov_log_982.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((16587809 : ℝ) / 25000000) ((16638411 : ℝ) / 25000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((66014951 : ℝ) / 100000000) ((8260333 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_975.1 cov_log_976.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((67143 : ℝ) / 25000000) ((538693 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((26541 : ℝ) / 100000000) ((1107 : ℝ) / 4000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((65231521 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((130435367 : ℝ) / 100000000) ((130436501 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((65231521 : ℝ) / 50000000) ((65231521 : ℝ) / 50000000) ((65231521 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((15231521 : ℝ) / 50000000))
  have h30 : RB z30 ((428175777 : ℝ) / 100000000) ((428179501 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((15231521 : ℝ) / 50000000) ((15231521 : ℝ) / 50000000) ((15231521 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((145436361 : ℝ) / 100000000) ((72718617 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_983.1 cov_log_984.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((23034641 : ℝ) / 25000000) ((18467957 : ℝ) / 20000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((65231521 : ℝ) / 50000000))
  have h33 : RB z33 ((26591979 : ℝ) / 100000000) ((1329599 : ℝ) / 5000000) := rb_log (show RB ((65231521 : ℝ) / 50000000) ((65231521 : ℝ) / 50000000) ((65231521 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_985.1 cov_log_985.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((8193323 : ℝ) / 12500000) ((32873903 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((66014951 : ℝ) / 100000000) ((8260333 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_975.1 cov_log_976.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-6701 : ℝ) / 1250000) ((-53429 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((20352241 : ℝ) / 50000000)) ((-6387 : ℝ) / 5000000) ((-391 : ℝ) / 6250000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((20725989 : ℝ) / 50000000)) ((14149 : ℝ) / 100000000) ((131337 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((32530971 : ℝ) / 25000000)) ((67143 : ℝ) / 25000000) ((538693 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((65231521 : ℝ) / 50000000)) ((-6701 : ℝ) / 1250000) ((-53429 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_54 {k A q d vp vm : ℝ}
    (hk : RB k ((1383 : ℝ) / 800) ((1113 : ℝ) / 640))
    (hA : RB A ((1383 : ℝ) / 2183) ((1113 : ℝ) / 1753))
    (hq : RB q ((407289 : ℝ) / 25000000) ((1663569 : ℝ) / 100000000))
    (hd : RB d ((48377041 : ℝ) / 25000000) ((96819617 : ℝ) / 50000000))
    (hp : RB vp ((20352241 : ℝ) / 50000000) ((20725989 : ℝ) / 50000000))
    (hm : RB vm ((32530971 : ℝ) / 25000000) ((65231521 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((26541 : ℝ) / 100000000) ((1107 : ℝ) / 4000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((3998893 : ℝ) / 4000000) ((99973459 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((1266713 : ℝ) / 2000000) ((63474307 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((16007 : ℝ) / 25000000) ((67991 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99932009 : ℝ) / 100000000) ((24983993 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((29274011 : ℝ) / 50000000) ((29647759 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((29254107 : ℝ) / 50000000) ((59257553 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((53440993 : ℝ) / 50000000) ((108487857 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((3440993 : ℝ) / 50000000) ((8487857 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((3998893 : ℝ) / 4000000) ((99973459 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((1266713 : ℝ) / 2000000) ((63474307 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((20343 : ℝ) / 100000000) ((21269 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99978731 : ℝ) / 100000000) ((99979657 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((7530971 : ℝ) / 25000000) ((15231521 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((7529369 : ℝ) / 25000000) ((6091369 : ℝ) / 20000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((25994013 : ℝ) / 12500000) ((52688933 : ℝ) / 25000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((38494013 : ℝ) / 12500000) ((77688933 : ℝ) / 25000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((294538421 : ℝ) / 25000000) ((726534463 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((6435923 : ℝ) / 20000000) ((32472583 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1383 : ℝ) / 400) ((1113 : ℝ) / 320) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2816403 : ℝ) / 50000000) ((5786101 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((25407289 : ℝ) / 25000000) ((101663569 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5540633 : ℝ) / 100000000) ((1423337 : ℝ) / 25000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((105540633 : ℝ) / 100000000) ((26423337 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((44335953 : ℝ) / 50000000) ((560991 : ℝ) / 625000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((171587377 : ℝ) / 100000000) ((173807789 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13241563 : ℝ) / 25000000) ((6759939 : ℝ) / 12500000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((49077 : ℝ) / 100000000) ((52251 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99947749 : ℝ) / 100000000) ((99950923 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((4287443 : ℝ) / 2500000) ((17372249 : ℝ) / 10000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((48377041 : ℝ) / 12500000) ((96819617 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((6305099 : ℝ) / 100000000) ((1288529 : ℝ) / 20000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((2183 : ℝ) / 800) ((1753 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1150959 : ℝ) / 50000000) ((94441 : ℝ) / 4000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((245639 : ℝ) / 6250000) ((127717 : ℝ) / 3125000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((6495639 : ℝ) / 6250000) ((3252717 : ℝ) / 3125000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((612228881 : ℝ) / 50000000) ((2363211 : ℝ) / 156250) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1248749 : ℝ) / 100000000) ((1278451 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101248749 : ℝ) / 100000000) ((101278451 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((32581457 : ℝ) / 100000000) ((3288773 : ℝ) / 10000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((1257039219 : ℝ) / 100000000) ((154534277 : ℝ) / 10000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((7234003 : ℝ) / 25000000) ((3648593 : ℝ) / 10000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((2183 : ℝ) / 800) ((1753 : ℝ) / 640) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((105540633 : ℝ) / 50000000) ((26423337 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((1210333299 : ℝ) / 100000000) ((1485541509 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((51095737 : ℝ) / 2000000) ((1570118557 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((868963 : ℝ) / 10000000) ((670081 : ℝ) / 6250000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-122151993 : ℝ) / 50000000) ((-111646907 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_986.1 cov_log_987.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((3152549 : ℝ) / 100000000) ((3221323 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-345695891 : ℝ) / 100000000) ((-343537803 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_988.1 cov_log_989.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((66014951 : ℝ) / 100000000) ((8260333 : ℝ) / 12500000) := rb_log hd (by norm_num) cov_log_975.1 cov_log_976.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((57061673 : ℝ) / 50000000) ((114921883 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-46314509 : ℝ) / 20000000) ((-2857699 : ℝ) / 1250000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((9720557 : ℝ) / 100000000) ((746583 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((6660483 : ℝ) / 25000000) ((20640937 : ℝ) / 50000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-204930613 : ℝ) / 100000000) ((-93667023 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((105540633 : ℝ) / 100000000) ((26423337 : ℝ) / 25000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-122151993 : ℝ) / 50000000) ((-111646907 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-204930613 : ℝ) / 100000000) ((-93667023 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((149 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((245639 : ℝ) / 6250000) ((127717 : ℝ) / 3125000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((41 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((3252717 : ℝ) / 6250000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((149 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((41 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-42775599 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((149 : ℝ) / 50) + hfun ((41 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_16, cov_h_13]
  have hP : ((13920221 : ℝ) / 2500000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((93667023 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((93667023 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((60829403 : ℝ) / 100000000) ≤ EP1038.Arc.sinc ((41 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((277 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((1299 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1299 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((1319 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1319 : ℝ) / 500)) (lo := ((1299 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1339 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1339 : ℝ) / 500)) (lo := ((1319 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1359 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1359 : ℝ) / 500)) (lo := ((1339 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1379 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1379 : ℝ) / 500)) (lo := ((1359 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1399 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1399 : ℝ) / 500)) (lo := ((1379 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1419 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1419 : ℝ) / 500)) (lo := ((1399 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1439 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1439 : ℝ) / 500)) (lo := ((1419 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1459 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1459 : ℝ) / 500)) (lo := ((1439 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((1479 : ℝ) / 500) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((1479 : ℝ) / 500)) (lo := ((1459 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((149 : ℝ) / 50)) (lo := ((1479 : ℝ) / 500)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_54 {k : ℝ} (hk : RB k ((1383 : ℝ) / 800) ((1113 : ℝ) / 640)) :
    RB (k / (k + 1)) ((1383 : ℝ) / 2183) ((1113 : ℝ) / 1753) ∧
    RB (qa (r1A k)) ((407289 : ℝ) / 25000000) ((1663569 : ℝ) / 100000000) ∧ RB (D0a (r1A k)) ((48377041 : ℝ) / 25000000) ((96819617 : ℝ) / 50000000) := by
  let z1 : ℝ := (k) / ((4 : ℝ))
  have h1 : RB z1 ((1383 : ℝ) / 3200) ((43476563 : ℝ) / 100000000) := rb_div_signed hk (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := (((1153 : ℝ) / 500)) - (z1)
  have h2 : RB z2 ((187123437 : ℝ) / 100000000) ((29981 : ℝ) / 16000) := rb_widen (rb_sub (show RB ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) ((1153 : ℝ) / 500) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := Real.sqrt (z2)
  have h3 : RB z3 ((34198267 : ℝ) / 25000000) ((17110909 : ℝ) / 12500000) := rb_sqrt h2 (by linarith [h2.1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.sqrt ((2 : ℝ))
  have h4 : RB z4 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z3) + (z4)
  have h5 : RB z5 ((34776803 : ℝ) / 12500000) ((278308629 : ℝ) / 100000000) := rb_widen (rb_add h3 h4) (by norm_num) (by norm_num)
  let z6 : ℝ := (z5) / ((2 : ℝ))
  have h6 : RB z6 ((34776803 : ℝ) / 25000000) ((27830863 : ℝ) / 20000000) := rb_div_signed h5 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) ^ 2
  have h7 : RB z7 ((48377041 : ℝ) / 25000000) ((96819617 : ℝ) / 50000000) := rb_widen (rb_sq h6 (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := ((2 : ℝ)) - (z2)
  have h8 : RB z8 ((2019 : ℝ) / 16000) ((12876563 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) / ((4 : ℝ))
  have h9 : RB z9 ((3154687 : ℝ) / 100000000) ((3219141 : ℝ) / 100000000) := rb_div_signed h8 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z10 : ℝ := (z9) / (z7)
  have h10 : RB z10 ((407289 : ℝ) / 25000000) ((1663569 : ℝ) / 100000000) := rb_div_signed h9 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < r1A k := by dsimp [r1A]; linarith [hk.2]
  have ha2 : r1A k < 2 := by dsimp [r1A]; linarith [hk.1]
  have hd : RB (D0a (r1A k)) ((48377041 : ℝ) / 25000000) ((96819617 : ℝ) / 50000000) := by
    have hh := h7
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (r1A k)) ((407289 : ℝ) / 25000000) ((1663569 : ℝ) / 100000000) := by
    have hh := h10
    rw [show qa (r1A k) = ((2 - r1A k) / 4) / D0a (r1A k) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1383 : ℝ) / 2183) ((1113 : ℝ) / 1753) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_54 {k : ℝ} (hk : RB k ((1383 : ℝ) / 800) ((1113 : ℝ) / 640)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_54 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_54 hA hq hd
  have hR1 : k ∈ r1Range := ⟨by linarith [hk.1], by linarith [hk.2]⟩
  have hk0 := r1_k_pos hR1
  have ha := r1_a_pos hR1
  have ha2 := (r1_a_mem hR1).2
  have hH := r1_H1 hR1
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((20352241 : ℝ) / 50000000)) (ph := ((20725989 : ℝ) / 50000000)) (ml := ((32530971 : ℝ) / 25000000)) (mh := ((65231521 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_54 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
