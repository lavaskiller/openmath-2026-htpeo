import LeanProject.Stage9D3

/-!
# EP-1038, Stage 9, Theorem 9.4 (sharpness): `inf_{f ∈ 𝒫} |S_f| ≤ D`

* `sublevel_le_VN`: the roots `r_j = Q(u_j) - 1 ∈ [-1, 1]` give `|S_{f_N}| ≤ |{V_N < 0}|`
  (translation by `1`, and `log|∏| = Σ log` off the finitely many roots).
* `step_N` (`N → ∞`): for `A(q) < A < s`, Lemma Q + Lemma A′ + Lemma B′ give
  `|{V_N < 0}| ≤ |E_{μ_A}| + ε` for some `N`.
* `step_A` (`A ↓ A(q)`): dominated convergence of indicators; on the platform both indicators vanish,
  off it the zeros of `V_{A(q)}` are finite (`zero_off_platform`).
* `sharpness`: `∀ q ∈ (0, q_s), ∀ ε > 0, ∃` a root vector in `[-1,1]^n` with `|S| < Λ(q) + ε`.
* `inf_le_D`, `iInf_le_D`: `inf |S_f| ≤ D` (over root vectors of length `n ≥ 1`; `n = 0` would make the
  infimum trivially `0`, since the empty product is `1`).
-/

open Real Set Filter Topology MeasureTheory intervalIntegral
open scoped ENNReal

namespace EP1038.Stage9

open Arc

/-- The roots of `f_N`: `r_j = Q(u_j) - 1`. -/
noncomputable def rootsN (Q : ℝ → ℝ) (N : ℕ) : Fin N → ℝ := fun j => Q (usamp N j) - 1

theorem rootsN_mem {Q : ℝ → ℝ} (hQr : ∀ u, Q u ∈ Icc (0 : ℝ) 2) (N : ℕ) (j : Fin N) :
    rootsN Q N j ∈ Icc (-1 : ℝ) 1 := by
  have := hQr (usamp N j)
  unfold rootsN
  constructor <;> linarith [this.1, this.2]

theorem sublevel_le_VN (Q : ℝ → ℝ) {N : ℕ} (hN : 0 < N) :
    volume (sublevel (rootsN Q N)) ≤ volume {y | VN Q N y < 0} := by
  set S' := {y : ℝ | |∏ j ∈ Finset.range N, (y - Q (usamp N j))| < 1} with hS'
  have hpre : sublevel (rootsN Q N) = (fun x => x + 1) ⁻¹' S' := by
    ext x
    simp only [sublevel, rootsN, mem_setOf_eq, mem_preimage, hS']
    have e : ∀ j : Fin N, x - (Q (usamp N j) - 1) = x + 1 - Q (usamp N (j : ℕ)) := fun j => by ring
    simp only [e]
    rw [Fin.prod_univ_eq_prod_range (fun j => x + 1 - Q (usamp N j)) N]
  rw [hpre, measure_preimage_add_right]
  set T : Set ℝ := (((Finset.range N).image fun j => Q (usamp N j) : Finset ℝ) : Set ℝ) with hT
  have hsub : S' ⊆ {y | VN Q N y < 0} ∪ T := by
    intro y hy
    by_cases hroot : y ∈ T
    · exact Or.inr hroot
    left
    have hne : ∀ j ∈ Finset.range N, y - Q (usamp N j) ≠ 0 := by
      intro j hj h
      exact hroot (by
        simp only [hT, Finset.coe_image, Finset.coe_range, mem_image, mem_Iio]
        exact ⟨j, Finset.mem_range.mp hj, (sub_eq_zero.mp h).symm⟩)
    have hprod_ne : ∏ j ∈ Finset.range N, (y - Q (usamp N j)) ≠ 0 := Finset.prod_ne_zero_iff.mpr hne
    have hlog : Real.log |∏ j ∈ Finset.range N, (y - Q (usamp N j))| < 0 :=
      Real.log_neg (abs_pos.mpr hprod_ne) hy
    rw [Real.log_abs, Real.log_prod hne] at hlog
    simp only [mem_setOf_eq, VN]
    exact div_neg_of_neg_of_pos hlog (by exact_mod_cast hN)
  calc volume S' ≤ volume ({y | VN Q N y < 0} ∪ T) := measure_mono hsub
    _ ≤ volume {y | VN Q N y < 0} + volume T := measure_union_le _ _
    _ = volume {y | VN Q N y < 0} := by
        rw [(Finset.finite_toSet _).measure_zero, add_zero]

/-- **Step `N → ∞`.** -/
theorem step_N {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA0 : 0 < A) (hAs : A * (1 + q) < 1 - q)
    (hC : 0 < CA A q) {ε : ℝ≥0∞} (hε : 0 < ε) :
    ∃ N, 0 < N ∧ volume {y | VN (Qu A q) N y < 0} ≤ volume {y | VA A q y < 0} + ε := by
  have hQ := Qu_mono hq hq1 hA0 hAs
  have hQr : ∀ u, Qu A q u ∈ Icc (0 : ℝ) 2 := Qu_mem hq hq1
  have hconv := lemmaA_tendsto hQ hQr (by norm_num : (-1 : ℝ) ≤ 3) (by norm_num : (-1 : ℝ) ≤ 0)
    (by norm_num : (2 : ℝ) ≤ 3)
  have hVQ : VQ (Qu A q) = VA A q := funext (VQ_eq_VA hq hq1 hA0 hAs)
  rw [hVQ] at hconv
  have hmeas : Measurable (VA A q) := hVQ ▸ VQ_measurable hQ
  obtain ⟨-, -, -, -, -, -, -, -, -, hz0⟩ := volume_sublevel_VA hq hq1 hA0 hAs hC.le
  have hz : volume ({y | VA A q y = 0} ∩ Ioc (-1 : ℝ) 3) = 0 :=
    measure_mono_null inter_subset_left (hz0 hC)
  have hB := lemmaB measurableSet_Ioc measure_Ioc_lt_top.ne hmeas (VN_measurable (Qu A q)) hconv hz hε
  obtain ⟨N, hN, hNpos⟩ := (hB.and (eventually_gt_atTop 0)).exists
  refine ⟨N, hNpos, ?_⟩
  have e : {y | VN (Qu A q) N y < 0} = {y | VN (Qu A q) N y < 0} ∩ Ioc (-1 : ℝ) 3 := by
    ext y
    simp only [mem_inter_iff, mem_setOf_eq]
    constructor
    · intro h
      refine ⟨h, ?_⟩
      by_contra hy
      exact absurd (VN_nonneg_out hQr N hy) (not_le.mpr h)
    · exact fun h => h.1
  rw [e]
  refine hN.trans ?_
  gcongr
  exact inter_subset_left

theorem sublevel_VA_sub {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA0 : 0 < A)
    (hAs : A * (1 + q) < 1 - q) : {y | VA A q y < 0} ⊆ Ioc (-1 : ℝ) 3 := by
  intro y hy
  by_contra hy'
  have := VQ_nonneg_out (Qu_mem (A := A) hq hq1) hy'
  rw [VQ_eq_VA hq hq1 hA0 hAs] at this
  exact absurd this (not_le.mpr hy)

theorem measurable_VA {A q : ℝ} (hq : 0 < q) (hq1 : q < 1) (hA0 : 0 < A)
    (hAs : A * (1 + q) < 1 - q) : Measurable (VA A q) :=
  (funext (VQ_eq_VA hq hq1 hA0 hAs)) ▸ VQ_measurable (Qu_mono hq hq1 hA0 hAs)

/-- **Step `A ↓ A(q)`.** -/
theorem step_A {q : ℝ} (hqa : q ∈ Qadm) {ε : ℝ≥0∞} (hε : 0 < ε) :
    ∃ A, Aq q < A ∧ A * (1 + q) < 1 - q ∧
      volume {y | VA A q y < 0} < ENNReal.ofReal (Lam q) + ε := by
  obtain ⟨hq, hq1, hf⟩ := hqa
  set A0 := Aq q with hA0def
  have hA0 : 0 < A0 := Aq_pos hq hq1
  have hA0s : A0 * (1 + q) < 1 - q := (Aq_lt_s_iff hq hq1).mpr hf
  have h1q : 0 < 1 + q := by linarith
  set s := (1 - q) / (1 + q) with hs
  have hA0lt : A0 < s := by rw [hs, lt_div_iff₀ h1q]; exact hA0s
  set An : ℕ → ℝ := fun n => A0 + (s - A0) / ((n + 2 : ℕ) : ℝ) with hAn
  have hpos : ∀ n : ℕ, (0 : ℝ) < ((n + 2 : ℕ) : ℝ) := fun n => by positivity
  have hAn_gt : ∀ n, A0 < An n := fun n => by
    simp only [hAn]; have := div_pos (sub_pos.mpr hA0lt) (hpos n); linarith
  have hAn_lt : ∀ n, An n < s := fun n => by
    simp only [hAn]
    have h2 : (s - A0) / ((n + 2 : ℕ) : ℝ) < s - A0 := by
      rw [div_lt_iff₀ (hpos n)]
      have : (1 : ℝ) < ((n + 2 : ℕ) : ℝ) := by push_cast; linarith [(Nat.cast_nonneg n : (0 : ℝ) ≤ n)]
      nlinarith [sub_pos.mpr hA0lt]
    linarith
  have hAn_s : ∀ n, An n * (1 + q) < 1 - q := fun n => by
    have := hAn_lt n
    rw [hs, lt_div_iff₀ h1q] at this
    exact this
  have hAn_pos : ∀ n, 0 < An n := fun n => hA0.trans (hAn_gt n)
  have hAn_tend : Tendsto An atTop (𝓝 A0) := by
    have h := (tendsto_const_div_atTop_nhds_zero_nat (s - A0)).comp (tendsto_add_atTop_nat 2)
    have := h.const_add A0
    simpa [hAn, Function.comp_def] using this
  -- the limit set and its measure
  have hK : volume (Ioc (-1 : ℝ) 3) ≠ ∞ := measure_Ioc_lt_top.ne
  have hLfin : volume {y | VA A0 q y < 0} ≠ ∞ :=
    ne_top_of_le_ne_top hK (measure_mono (sublevel_VA_sub hq hq1 hA0 hA0s))
  have hLam : ENNReal.ofReal (Lam q) = volume {y | VA A0 q y < 0} := by
    unfold Lam
    exact ENNReal.ofReal_toReal hLfin
  -- dominated convergence
  have hmeasS : ∀ A, 0 < A → A * (1 + q) < 1 - q → MeasurableSet {y | VA A q y < 0} :=
    fun A h0 h1 => measurableSet_lt (measurable_VA hq hq1 h0 h1) measurable_const
  obtain ⟨a, b, hzero⟩ := zero_off_platform hq hq1 hA0 hA0s (CA_Aq hq hq1).symm.le
  have hZ : ∀ᵐ y ∂(volume : Measure ℝ), y ∉ ({0, a, b} : Set ℝ) := by
    rw [ae_iff]
    simp only [not_not, setOf_mem_eq]
    exact (Set.toFinite _).measure_zero _
  have hlim : ∀ᵐ y ∂(volume : Measure ℝ), Tendsto
      (fun n => {y | VA (An n) q y < 0}.indicator (1 : ℝ → ℝ≥0∞) y) atTop
      (𝓝 ({y | VA A0 q y < 0}.indicator 1 y)) := by
    filter_upwards [hZ] with y hy
    have hcont : Tendsto (fun n => VA (An n) q y) atTop (𝓝 (VA A0 q y)) :=
      ((VA_continuous_A hq hq1 y).tendsto A0).comp hAn_tend
    by_cases hplat : y ∈ Icc (D0q q * (1 - q) ^ 2) (D0q q * (1 + q) ^ 2)
    · have h0 : VA A0 q y = 0 := by rw [VA_on_platform hq hq1 hplat, CA_Aq hq hq1]
      have hn : ∀ n, ¬ VA (An n) q y < 0 := fun n => by
        rw [VA_on_platform hq hq1 hplat]
        exact not_lt.mpr (CA_pos hq hq1 (hAn_gt n)).le
      simp only [indicator, mem_setOf_eq, hn, h0, lt_irrefl, if_false]
      exact tendsto_const_nhds
    · have hne : VA A0 q y ≠ 0 := by
        intro h
        rcases hzero y h hplat with h1 | h1 | h1 <;> exact hy (by simp [h1])
      rcases lt_or_gt_of_ne hne with hlt | hgt
      · have hev : ∀ᶠ n in atTop, VA (An n) q y < 0 := hcont.eventually (gt_mem_nhds hlt)
        refine tendsto_const_nhds.congr' ?_
        filter_upwards [hev] with n hn
        simp only [indicator, mem_setOf_eq, hn, hlt, if_true]
      · have hev : ∀ᶠ n in atTop, 0 < VA (An n) q y := hcont.eventually (lt_mem_nhds hgt)
        refine tendsto_const_nhds.congr' ?_
        filter_upwards [hev] with n hn
        simp only [indicator, mem_setOf_eq, not_lt.mpr hn.le, not_lt.mpr hgt.le, if_false]
  have hT : Tendsto (fun n => volume {y | VA (An n) q y < 0}) atTop
      (𝓝 (volume {y | VA A0 q y < 0})) := by
    have hdct := tendsto_lintegral_of_dominated_convergence (μ := volume)
      ((Ioc (-1 : ℝ) 3).indicator 1)
      (fun n => measurable_one.indicator (hmeasS _ (hAn_pos n) (hAn_s n)))
      (fun n => Eventually.of_forall fun y =>
        indicator_le_indicator_of_subset (sublevel_VA_sub hq hq1 (hAn_pos n) (hAn_s n))
          (fun _ => by simp) y)
      (by rw [lintegral_indicator_one measurableSet_Ioc]; exact hK) hlim
    simp only [lintegral_indicator_one (hmeasS _ (hAn_pos _) (hAn_s _)),
      lintegral_indicator_one (hmeasS _ hA0 hA0s)] at hdct
    exact hdct
  rw [hLam]
  obtain ⟨n, hn⟩ := ((tendsto_order.1 hT).2 _ (ENNReal.lt_add_right hLfin hε.ne')).exists
  exact ⟨An n, hAn_gt n, hAn_s n, hn⟩

/-- **Theorem 9.4 at fixed `q`**: for `0 < q < q_s` and `ε > 0` there is a monic polynomial with all
roots in `[-1, 1]` and `|S_f| < Λ(q) + ε`. -/
theorem sharpness {q : ℝ} (hq : q ∈ Qadm) {ε : ℝ} (hε : 0 < ε) :
    ∃ (n : ℕ) (r : Fin n → ℝ), 0 < n ∧ (∀ i, r i ∈ Icc (-1 : ℝ) 1) ∧
      volume (sublevel r) < ENNReal.ofReal (Lam q + ε) := by
  have hq0 := hq.1
  have hq1 := hq.2.1
  have he : 0 < ENNReal.ofReal (ε / 2) := ENNReal.ofReal_pos.mpr (half_pos hε)
  obtain ⟨A, hA, hAs, hvol⟩ := step_A hq he
  have hA0 : 0 < A := (Aq_pos hq0 hq1).trans hA
  obtain ⟨N, hN, hVN⟩ := step_N hq0 hq1 hA0 hAs (CA_pos hq0 hq1 hA) he
  refine ⟨N, rootsN (Qu A q) N, hN, rootsN_mem (Qu_mem hq0 hq1) N, ?_⟩
  have hsplit : ENNReal.ofReal (Lam q + ε) =
      ENNReal.ofReal (Lam q) + ENNReal.ofReal (ε / 2) + ENNReal.ofReal (ε / 2) := by
    rw [add_assoc, ← ENNReal.ofReal_add (half_pos hε).le (half_pos hε).le, add_halves,
      ENNReal.ofReal_add (Lam_nonneg q) hε.le]
  rw [hsplit]
  calc volume (sublevel (rootsN (Qu A q) N)) ≤ volume {y | VN (Qu A q) N y < 0} :=
        sublevel_le_VN _ hN
    _ ≤ volume {y | VA A q y < 0} + ENNReal.ofReal (ε / 2) := hVN
    _ < ENNReal.ofReal (Lam q) + ENNReal.ofReal (ε / 2) + ENNReal.ofReal (ε / 2) :=
        ENNReal.add_lt_add_right ENNReal.ofReal_ne_top hvol

theorem Dval_nonneg : 0 ≤ Dval :=
  le_csInf (Qadm_nonempty.image Lam) (by rintro _ ⟨x, -, rfl⟩; exact Lam_nonneg x)

/-- **Theorem 9.4**: for every `ε > 0` some monic polynomial with all roots in `[-1, 1]` has
`|S_f| < D + ε`. -/
theorem inf_le_D {ε : ℝ} (hε : 0 < ε) :
    ∃ (n : ℕ) (r : Fin n → ℝ), 0 < n ∧ (∀ i, r i ∈ Icc (-1 : ℝ) 1) ∧
      volume (sublevel r) < ENNReal.ofReal (Dval + ε) := by
  obtain ⟨q, hq, hlt⟩ := exists_Lam_lt (half_pos hε)
  obtain ⟨n, r, hn, hr, hv⟩ := sharpness hq (half_pos hε)
  exact ⟨n, r, hn, hr, hv.trans_le (ENNReal.ofReal_le_ofReal (by linarith))⟩

/-- **Theorem 9.4** (infimum form): `inf_{f ∈ 𝒫} |S_f| ≤ D`, the infimum over root vectors
`r ∈ [-1,1]^n` of positive length `n ≥ 1` (for `n = 0` the sublevel set is empty). -/
theorem iInf_le_D :
    (⨅ (n : ℕ) (_ : 0 < n) (r : Fin n → ℝ) (_ : ∀ i, r i ∈ Icc (-1 : ℝ) 1),
      volume (sublevel r)) ≤ ENNReal.ofReal Dval := by
  refine ENNReal.le_of_forall_pos_le_add fun ε hε _ => ?_
  obtain ⟨n, r, hn, hr, hv⟩ := inf_le_D (ε := ε) (by exact_mod_cast hε)
  calc (⨅ (n : ℕ) (_ : 0 < n) (r : Fin n → ℝ) (_ : ∀ i, r i ∈ Icc (-1 : ℝ) 1),
        volume (sublevel r))
      ≤ volume (sublevel r) := iInf₂_le_of_le n hn (iInf₂_le_of_le r hr le_rfl)
    _ ≤ ENNReal.ofReal (Dval + ε) := hv.le
    _ = ENNReal.ofReal Dval + ε := by
        rw [ENNReal.ofReal_add Dval_nonneg (by positivity), ENNReal.ofReal_coe_nnreal]

end EP1038.Stage9
