import LeanProject.DLowerArithmetic
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_log_60 : RB (Real.log ((43248342967 : ℝ) / 12500000000000)) ((-5666525003549 : ℝ) / 1000000000000) ((-5666525003547 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((43248342967 : ℝ) / 48828125000)) (t := ((-5579782033 : ℝ) / 92076467967))
    (lo := ((-121347559069 : ℝ) / 1000000000000)) (hi := ((-30336889767 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((43248342967 : ℝ) / 12500000000000) = Real.log ((43248342967 : ℝ) / 48828125000) - 8 * Real.log 2 := by
    rw [show ((43248342967 : ℝ) / 12500000000000) = ((43248342967 : ℝ) / 48828125000) / (2 : ℝ) ^ 8 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_61 : RB (Real.log ((1003459867437 : ℝ) / 1000000000000)) ((690779173 : ℝ) / 200000000000) ((1726947933 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1003459867437 : ℝ) / 1000000000000)) (t := ((3459867437 : ℝ) / 2003459867437))
    (lo := ((690779173 : ℝ) / 200000000000)) (hi := ((1726947933 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_62 : RB (Real.log ((100426781323 : ℝ) / 100000000000)) ((532341493 : ℝ) / 125000000000) ((851746389 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((100426781323 : ℝ) / 100000000000)) (t := ((426781323 : ℝ) / 200426781323))
    (lo := ((532341493 : ℝ) / 125000000000)) (hi := ((851746389 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_63 : RB (Real.log ((494350381319 : ℝ) / 500000000000)) ((-5681779363 : ℝ) / 500000000000) ((-454542349 : ℝ) / 40000000000) := by
  have hm := log_bounds_of_series (x := ((494350381319 : ℝ) / 500000000000)) (t := ((-5649618681 : ℝ) / 994350381319))
    (lo := ((-5681779363 : ℝ) / 500000000000)) (hi := ((-454542349 : ℝ) / 40000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_64 : RB (Real.log ((494356589707 : ℝ) / 500000000000)) ((-90808001 : ℝ) / 8000000000) ((-2837750031 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((494356589707 : ℝ) / 500000000000)) (t := ((-5643410293 : ℝ) / 994356589707))
    (lo := ((-90808001 : ℝ) / 8000000000)) (hi := ((-2837750031 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_65 : RB (Real.log ((124292074937 : ℝ) / 250000000000)) ((-27953067157 : ℝ) / 40000000000) ((-698826678923 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((124292074937 : ℝ) / 125000000000)) (t := ((-707925063 : ℝ) / 249292074937))
    (lo := ((-1135899673 : ℝ) / 200000000000)) (hi := ((-1419874591 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((124292074937 : ℝ) / 250000000000) = Real.log ((124292074937 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((124292074937 : ℝ) / 250000000000) = ((124292074937 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_66 : RB (Real.log ((3332664186099 : ℝ) / 1000000000000)) ((601886020001 : ℝ) / 500000000000) ((300943010001 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((3332664186099 : ℝ) / 4000000000000)) (t := ((-667335813901 : ℝ) / 7332664186099))
    (lo := ((-182522321117 : ℝ) / 1000000000000)) (hi := ((-45630580279 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3332664186099 : ℝ) / 1000000000000) = Real.log ((3332664186099 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3332664186099 : ℝ) / 1000000000000) = ((3332664186099 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_67 : RB (Real.log ((1666339375233 : ℝ) / 500000000000)) ((60188820509 : ℝ) / 50000000000) ((601888205091 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1666339375233 : ℝ) / 2000000000000)) (t := ((-333660624767 : ℝ) / 3666339375233))
    (lo := ((-182517950939 : ℝ) / 1000000000000)) (hi := ((-91258975469 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1666339375233 : ℝ) / 500000000000) = Real.log ((1666339375233 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1666339375233 : ℝ) / 500000000000) = ((1666339375233 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_68 : RB (Real.log ((357171640021 : ℝ) / 250000000000)) ((356755532749 : ℝ) / 1000000000000) ((356755532751 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((357171640021 : ℝ) / 500000000000)) (t := ((-142828359979 : ℝ) / 857171640021))
    (lo := ((-33639164781 : ℝ) / 100000000000)) (hi := ((-336391647809 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((357171640021 : ℝ) / 250000000000) = Real.log ((357171640021 : ℝ) / 500000000000) + 1 * Real.log 2 := by
    rw [show ((357171640021 : ℝ) / 250000000000) = ((357171640021 : ℝ) / 500000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_69 : RB (Real.log ((518610047607 : ℝ) / 100000000000000)) ((-5261773217571 : ℝ) / 1000000000000) ((-5261773217569 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((518610047607 : ℝ) / 390625000000)) (t := ((127985047607 : ℝ) / 909235047607))
    (lo := ((283404226909 : ℝ) / 1000000000000)) (hi := ((28340422691 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((518610047607 : ℝ) / 100000000000000) = Real.log ((518610047607 : ℝ) / 390625000000) - 8 * Real.log 2 := by
    rw [show ((518610047607 : ℝ) / 100000000000000) = ((518610047607 : ℝ) / 390625000000) / (2 : ℝ) ^ 8 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_70 : RB (Real.log ((426781322967 : ℝ) / 100000000000000)) ((-2728326853561 : ℝ) / 500000000000) ((-68208171339 : ℝ) / 12500000000) := by
  have hm := log_bounds_of_series (x := ((426781322967 : ℝ) / 390625000000)) (t := ((36156322967 : ℝ) / 817406322967))
    (lo := ((44261868679 : ℝ) / 500000000000)) (hi := ((88523737359 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((426781322967 : ℝ) / 100000000000000) = Real.log ((426781322967 : ℝ) / 390625000000) - 8 * Real.log 2 := by
    rw [show ((426781322967 : ℝ) / 100000000000000) = ((426781322967 : ℝ) / 390625000000) / (2 : ℝ) ^ 8 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_71 : RB (Real.log ((1004267813229 : ℝ) / 1000000000000)) ((4258731943 : ℝ) / 1000000000000) ((532341493 : ℝ) / 125000000000) := by
  have hm := log_bounds_of_series (x := ((1004267813229 : ℝ) / 1000000000000)) (t := ((4267813229 : ℝ) / 2004267813229))
    (lo := ((4258731943 : ℝ) / 1000000000000)) (hi := ((532341493 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_72 : RB (Real.log ((1005186100477 : ℝ) / 1000000000000)) ((1293174743 : ℝ) / 250000000000) ((5172698973 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1005186100477 : ℝ) / 1000000000000)) (t := ((5186100477 : ℝ) / 2005186100477))
    (lo := ((1293174743 : ℝ) / 250000000000)) (hi := ((5172698973 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_73 : RB (Real.log ((24632672083 : ℝ) / 25000000000)) ((-57820819 : ℝ) / 3906250000) ((-14802129663 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((24632672083 : ℝ) / 25000000000)) (t := ((-367327917 : ℝ) / 49632672083))
    (lo := ((-57820819 : ℝ) / 3906250000)) (hi := ((-14802129663 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_74 : RB (Real.log ((985324119047 : ℝ) / 1000000000000)) ((-14784637067 : ℝ) / 1000000000000) ((-7392318533 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((985324119047 : ℝ) / 1000000000000)) (t := ((-14675880953 : ℝ) / 1985324119047))
    (lo := ((-14784637067 : ℝ) / 1000000000000)) (hi := ((-7392318533 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_75 : RB (Real.log ((99262616499 : ℝ) / 200000000000)) ((-350274168341 : ℝ) / 500000000000) ((-17513708417 : ℝ) / 25000000000) := by
  have hm := log_bounds_of_series (x := ((99262616499 : ℝ) / 100000000000)) (t := ((-737383501 : ℝ) / 199262616499))
    (lo := ((-3700578061 : ℝ) / 500000000000)) (hi := ((-7401156121 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((99262616499 : ℝ) / 200000000000) = Real.log ((99262616499 : ℝ) / 100000000000) - 1 * Real.log 2 := by
    rw [show ((99262616499 : ℝ) / 200000000000) = ((99262616499 : ℝ) / 100000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_76 : RB (Real.log ((668470453859 : ℝ) / 200000000000)) ((301668707837 : ℝ) / 250000000000) ((24133496627 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((668470453859 : ℝ) / 800000000000)) (t := ((-131529546141 : ℝ) / 1468470453859))
    (lo := ((-179619529771 : ℝ) / 1000000000000)) (hi := ((-17961952977 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((668470453859 : ℝ) / 200000000000) = Real.log ((668470453859 : ℝ) / 800000000000) + 2 * Real.log 2 := by
    rw [show ((668470453859 : ℝ) / 200000000000) = ((668470453859 : ℝ) / 800000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_77 : RB (Real.log ((835593151191 : ℝ) / 250000000000)) ((301670228877 : ℝ) / 250000000000) ((120668091551 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((835593151191 : ℝ) / 1000000000000)) (t := ((-164406848809 : ℝ) / 1835593151191))
    (lo := ((-179613445611 : ℝ) / 1000000000000)) (hi := ((-17961344561 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((835593151191 : ℝ) / 250000000000) = Real.log ((835593151191 : ℝ) / 1000000000000) + 2 * Real.log 2 := by
    rw [show ((835593151191 : ℝ) / 250000000000) = ((835593151191 : ℝ) / 1000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_78 : RB (Real.log ((1426909785291 : ℝ) / 1000000000000)) ((355511116657 : ℝ) / 1000000000000) ((355511116659 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1426909785291 : ℝ) / 2000000000000)) (t := ((-573090214709 : ℝ) / 3426909785291))
    (lo := ((-168818031951 : ℝ) / 500000000000)) (hi := ((-337636063901 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426909785291 : ℝ) / 1000000000000) = Real.log ((1426909785291 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1426909785291 : ℝ) / 1000000000000) = ((1426909785291 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_79 : RB (Real.log ((31089198061 : ℝ) / 5000000000000)) ((-5080332761793 : ℝ) / 1000000000000) ((-5080332761791 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((31089198061 : ℝ) / 39062500000)) (t := ((-7973301939 : ℝ) / 70151698061))
    (lo := ((-228302497873 : ℝ) / 1000000000000)) (hi := ((-14268906117 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((31089198061 : ℝ) / 5000000000000) = Real.log ((31089198061 : ℝ) / 39062500000) - 7 * Real.log 2 := by
    rw [show ((31089198061 : ℝ) / 5000000000000) = ((31089198061 : ℝ) / 39062500000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_80 : RB (Real.log ((259305023801 : ℝ) / 50000000000000)) ((-5261773217581 : ℝ) / 1000000000000) ((-5261773217579 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((259305023801 : ℝ) / 195312500000)) (t := ((63992523801 : ℝ) / 454617523801))
    (lo := ((283404226899 : ℝ) / 1000000000000)) (hi := ((2834042269 : ℝ) / 10000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((259305023801 : ℝ) / 50000000000000) = Real.log ((259305023801 : ℝ) / 195312500000) - 8 * Real.log 2 := by
    rw [show ((259305023801 : ℝ) / 50000000000000) = ((259305023801 : ℝ) / 195312500000) / (2 : ℝ) ^ 8 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_81 : RB (Real.log ((251296525119 : ℝ) / 250000000000)) ((5172698971 : ℝ) / 1000000000000) ((1293174743 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((251296525119 : ℝ) / 250000000000)) (t := ((1296525119 : ℝ) / 501296525119))
    (lo := ((5172698971 : ℝ) / 1000000000000)) (hi := ((1293174743 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_82 : RB (Real.log ((1006217839613 : ℝ) / 1000000000000)) ((3099294303 : ℝ) / 500000000000) ((6198588607 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1006217839613 : ℝ) / 1000000000000)) (t := ((6217839613 : ℝ) / 2006217839613))
    (lo := ((3099294303 : ℝ) / 500000000000)) (hi := ((6198588607 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_83 : RB (Real.log ((98130534477 : ℝ) / 100000000000)) ((-18871609163 : ℝ) / 1000000000000) ((-9435804581 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((98130534477 : ℝ) / 100000000000)) (t := ((-1869465523 : ℝ) / 198130534477))
    (lo := ((-18871609163 : ℝ) / 1000000000000)) (hi := ((-9435804581 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_84 : RB (Real.log ((981328657497 : ℝ) / 1000000000000)) ((-1177990787 : ℝ) / 62500000000) ((-18847852591 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((981328657497 : ℝ) / 1000000000000)) (t := ((-18671342503 : ℝ) / 1981328657497))
    (lo := ((-1177990787 : ℝ) / 62500000000)) (hi := ((-18847852591 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_85 : RB (Real.log ((123825437721 : ℝ) / 250000000000)) ((-351294052199 : ℝ) / 500000000000) ((-175647026099 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((123825437721 : ℝ) / 125000000000)) (t := ((-1174562279 : ℝ) / 248825437721))
    (lo := ((-4720461919 : ℝ) / 500000000000)) (hi := ((-9440923837 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((123825437721 : ℝ) / 250000000000) = Real.log ((123825437721 : ℝ) / 125000000000) - 1 * Real.log 2 := by
    rw [show ((123825437721 : ℝ) / 250000000000) = ((123825437721 : ℝ) / 125000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_86 : RB (Real.log ((1675689742437 : ℝ) / 500000000000)) ((302343011901 : ℝ) / 250000000000) ((604686023803 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((1675689742437 : ℝ) / 2000000000000)) (t := ((-324310257563 : ℝ) / 3675689742437))
    (lo := ((-35384462703 : ℝ) / 200000000000)) (hi := ((-88461156757 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1675689742437 : ℝ) / 500000000000) = Real.log ((1675689742437 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1675689742437 : ℝ) / 500000000000) = ((1675689742437 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_87 : RB (Real.log ((3351407152021 : ℝ) / 1000000000000)) ((1209380303021 : ℝ) / 1000000000000) ((1209380303023 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3351407152021 : ℝ) / 4000000000000)) (t := ((-648592847979 : ℝ) / 7351407152021))
    (lo := ((-88457029049 : ℝ) / 500000000000)) (hi := ((-176914058097 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3351407152021 : ℝ) / 1000000000000) = Real.log ((3351407152021 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3351407152021 : ℝ) / 1000000000000) = ((3351407152021 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_88 : RB (Real.log ((356316456457 : ℝ) / 250000000000)) ((177179170381 : ℝ) / 500000000000) ((70871668153 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((356316456457 : ℝ) / 500000000000)) (t := ((-143683543543 : ℝ) / 856316456457))
    (lo := ((-338788839797 : ℝ) / 1000000000000)) (hi := ((-67757767959 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((356316456457 : ℝ) / 250000000000) = Real.log ((356316456457 : ℝ) / 500000000000) + 1 * Real.log 2 := by
    rw [show ((356316456457 : ℝ) / 250000000000) = ((356316456457 : ℝ) / 500000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_89 : RB (Real.log ((27107873297 : ℝ) / 4000000000000)) ((-156069544589 : ℝ) / 31250000000) ((-2497112713423 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((27107873297 : ℝ) / 31250000000)) (t := ((-4142126703 : ℝ) / 58357873297))
    (lo := ((-8887197683 : ℝ) / 62500000000)) (hi := ((-142195162927 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((27107873297 : ℝ) / 4000000000000) = Real.log ((27107873297 : ℝ) / 31250000000) - 7 * Real.log 2 := by
    rw [show ((27107873297 : ℝ) / 4000000000000) = ((27107873297 : ℝ) / 31250000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_90 : RB (Real.log ((124356792243 : ℝ) / 20000000000000)) ((-5080332761801 : ℝ) / 1000000000000) ((-5080332761799 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((124356792243 : ℝ) / 156250000000)) (t := ((-31893207757 : ℝ) / 280606792243))
    (lo := ((-228302497881 : ℝ) / 1000000000000)) (hi := ((-5707562447 : ℝ) / 25000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((124356792243 : ℝ) / 20000000000000) = Real.log ((124356792243 : ℝ) / 156250000000) - 7 * Real.log 2 := by
    rw [show ((124356792243 : ℝ) / 20000000000000) = ((124356792243 : ℝ) / 156250000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_91 : RB (Real.log ((251554459903 : ℝ) / 250000000000)) ((1239717721 : ℝ) / 200000000000) ((3099294303 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((251554459903 : ℝ) / 250000000000)) (t := ((1554459903 : ℝ) / 501554459903))
    (lo := ((1239717721 : ℝ) / 200000000000)) (hi := ((3099294303 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_92 : RB (Real.log ((40271078733 : ℝ) / 40000000000)) ((6754107899 : ℝ) / 1000000000000) ((67541079 : ℝ) / 10000000000) := by
  have hm := log_bounds_of_series (x := ((40271078733 : ℝ) / 40000000000)) (t := ((271078733 : ℝ) / 80271078733))
    (lo := ((6754107899 : ℝ) / 1000000000000)) (hi := ((67541079 : ℝ) / 10000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_93 : RB (Real.log ((485680629597 : ℝ) / 500000000000)) ((-29056831281 : ℝ) / 1000000000000) ((-363210391 : ℝ) / 12500000000) := by
  have hm := log_bounds_of_series (x := ((485680629597 : ℝ) / 500000000000)) (t := ((-14319370403 : ℝ) / 985680629597))
    (lo := ((-29056831281 : ℝ) / 1000000000000)) (hi := ((-363210391 : ℝ) / 12500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_94 : RB (Real.log ((60710973957 : ℝ) / 62500000000)) ((-3630260619 : ℝ) / 125000000000) ((-29042084951 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((60710973957 : ℝ) / 62500000000)) (t := ((-1789026043 : ℝ) / 123210973957))
    (lo := ((-3630260619 : ℝ) / 125000000000)) (hi := ((-29042084951 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_95 : RB (Real.log ((246379800243 : ℝ) / 500000000000)) ((-707733849657 : ℝ) / 1000000000000) ((-141546769931 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((246379800243 : ℝ) / 250000000000)) (t := ((-3620199757 : ℝ) / 496379800243))
    (lo := ((-14586669097 : ℝ) / 1000000000000)) (hi := ((-1823333637 : ℝ) / 125000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((246379800243 : ℝ) / 500000000000) = Real.log ((246379800243 : ℝ) / 250000000000) - 1 * Real.log 2 := by
    rw [show ((246379800243 : ℝ) / 500000000000) = ((246379800243 : ℝ) / 250000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_96 : RB (Real.log ((3339583091191 : ℝ) / 1000000000000)) ((1205845976199 : ℝ) / 1000000000000) ((1205845976201 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((3339583091191 : ℝ) / 4000000000000)) (t := ((-660416908809 : ℝ) / 7339583091191))
    (lo := ((-4511209623 : ℝ) / 25000000000)) (hi := ((-180448384919 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3339583091191 : ℝ) / 1000000000000) = Real.log ((3339583091191 : ℝ) / 4000000000000) + 2 * Real.log 2 := by
    rw [show ((3339583091191 : ℝ) / 1000000000000) = ((3339583091191 : ℝ) / 4000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_97 : RB (Real.log ((104362502839 : ℝ) / 31250000000)) ((60292553327 : ℝ) / 50000000000) ((602925533271 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((104362502839 : ℝ) / 125000000000)) (t := ((-20637497161 : ℝ) / 229362502839))
    (lo := ((-180443294579 : ℝ) / 1000000000000)) (hi := ((-90221647289 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((104362502839 : ℝ) / 31250000000) = Real.log ((104362502839 : ℝ) / 125000000000) + 2 * Real.log 2 := by
    rw [show ((104362502839 : ℝ) / 31250000000) = ((104362502839 : ℝ) / 125000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_98 : RB (Real.log ((1427406949753 : ℝ) / 1000000000000)) ((355859476361 : ℝ) / 1000000000000) ((355859476363 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1427406949753 : ℝ) / 2000000000000)) (t := ((-572593050247 : ℝ) / 3427406949753))
    (lo := ((-168643852099 : ℝ) / 500000000000)) (hi := ((-337287704197 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1427406949753 : ℝ) / 1000000000000) = Real.log ((1427406949753 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1427406949753 : ℝ) / 1000000000000) = ((1427406949753 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_99 : RB (Real.log ((736520543237 : ℝ) / 100000000000000)) ((-12277470841 : ℝ) / 2500000000) ((-2455494168199 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((736520543237 : ℝ) / 781250000000)) (t := ((-44729456763 : ℝ) / 1517770543237))
    (lo := ((-368487953 : ℝ) / 6250000000)) (hi := ((-58958072479 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((736520543237 : ℝ) / 100000000000000) = Real.log ((736520543237 : ℝ) / 781250000000) - 7 * Real.log 2 := by
    rw [show ((736520543237 : ℝ) / 100000000000000) = ((736520543237 : ℝ) / 781250000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_100 : RB (Real.log ((33884841621 : ℝ) / 5000000000000)) ((-998845085371 : ℝ) / 200000000000) ((-4994225426853 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((33884841621 : ℝ) / 39062500000)) (t := ((-5177658379 : ℝ) / 72947341621))
    (lo := ((-28439032587 : ℝ) / 200000000000)) (hi := ((-71097581467 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33884841621 : ℝ) / 5000000000000) = Real.log ((33884841621 : ℝ) / 39062500000) - 7 * Real.log 2 := by
    rw [show ((33884841621 : ℝ) / 5000000000000) = ((33884841621 : ℝ) / 39062500000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_101 : RB (Real.log ((251694242081 : ℝ) / 250000000000)) ((3377053949 : ℝ) / 500000000000) ((6754107899 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((251694242081 : ℝ) / 250000000000)) (t := ((1694242081 : ℝ) / 501694242081))
    (lo := ((3377053949 : ℝ) / 500000000000)) (hi := ((6754107899 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_102 : RB (Real.log ((1007365205433 : ℝ) / 1000000000000)) ((3669107377 : ℝ) / 500000000000) ((1467642951 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((1007365205433 : ℝ) / 1000000000000)) (t := ((7365205433 : ℝ) / 2007365205433))
    (lo := ((3669107377 : ℝ) / 500000000000)) (hi := ((1467642951 : ℝ) / 200000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_103 : RB (Real.log ((4842356643 : ℝ) / 5000000000)) ((-32036400497 : ℝ) / 1000000000000) ((-2002275031 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((4842356643 : ℝ) / 5000000000)) (t := ((-157643357 : ℝ) / 9842356643))
    (lo := ((-32036400497 : ℝ) / 1000000000000)) (hi := ((-2002275031 : ℝ) / 62500000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_104 : RB (Real.log ((96848770511 : ℝ) / 100000000000)) ((-2001218187 : ℝ) / 62500000000) ((-32019490991 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((96848770511 : ℝ) / 100000000000)) (t := ((-3151229489 : ℝ) / 196848770511))
    (lo := ((-2001218187 : ℝ) / 62500000000)) (hi := ((-32019490991 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_105 : RB (Real.log ((492019142357 : ℝ) / 1000000000000)) ((-354618828009 : ℝ) / 500000000000) ((-44327353501 : ℝ) / 62500000000) := by
  have hm := log_bounds_of_series (x := ((492019142357 : ℝ) / 500000000000)) (t := ((-7980857643 : ℝ) / 992019142357))
    (lo := ((-8045237729 : ℝ) / 500000000000)) (hi := ((-16090475457 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((492019142357 : ℝ) / 1000000000000) = Real.log ((492019142357 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((492019142357 : ℝ) / 1000000000000) = ((492019142357 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_106 : RB (Real.log ((66866103637 : ℝ) / 20000000000)) ((301739973271 : ℝ) / 250000000000) ((603479946543 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((66866103637 : ℝ) / 80000000000)) (t := ((-13133896363 : ℝ) / 146866103637))
    (lo := ((-35866893607 : ℝ) / 200000000000)) (hi := ((-89667234017 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((66866103637 : ℝ) / 20000000000) = Real.log ((66866103637 : ℝ) / 80000000000) + 2 * Real.log 2 := by
    rw [show ((66866103637 : ℝ) / 20000000000) = ((66866103637 : ℝ) / 80000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_107 : RB (Real.log ((1671662338377 : ℝ) / 500000000000)) ((241393144819 : ℝ) / 200000000000) ((1206965724097 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1671662338377 : ℝ) / 2000000000000)) (t := ((-328337661623 : ℝ) / 3671662338377))
    (lo := ((-5604019907 : ℝ) / 31250000000)) (hi := ((-179328637023 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1671662338377 : ℝ) / 500000000000) = Real.log ((1671662338377 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1671662338377 : ℝ) / 500000000000) = ((1671662338377 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_108 : RB (Real.log ((5706898037 : ℝ) / 4000000000)) ((355381263969 : ℝ) / 1000000000000) ((355381263971 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((5706898037 : ℝ) / 8000000000)) (t := ((-2293101963 : ℝ) / 13706898037))
    (lo := ((-33776591659 : ℝ) / 100000000000)) (hi := ((-337765916589 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5706898037 : ℝ) / 4000000000) = Real.log ((5706898037 : ℝ) / 8000000000) + 1 * Real.log 2 := by
    rw [show ((5706898037 : ℝ) / 4000000000) = ((5706898037 : ℝ) / 8000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_109 : RB (Real.log ((79826860143 : ℝ) / 10000000000000)) ((-966096066177 : ℝ) / 200000000000) ((-4830480330883 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((79826860143 : ℝ) / 78125000000)) (t := ((1701860143 : ℝ) / 157951860143))
    (lo := ((4309986607 : ℝ) / 200000000000)) (hi := ((5387483259 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((79826860143 : ℝ) / 10000000000000) = Real.log ((79826860143 : ℝ) / 78125000000) - 7 * Real.log 2 := by
    rw [show ((79826860143 : ℝ) / 10000000000000) = ((79826860143 : ℝ) / 78125000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_110 : RB (Real.log ((719258343 : ℝ) / 97656250000)) ((-4910988336407 : ℝ) / 1000000000000) ((-982197667281 : ℝ) / 200000000000) := by
  have hm := log_bounds_of_series (x := ((5754066744 : ℝ) / 6103515625)) (t := ((-349448881 : ℝ) / 11857582369))
    (lo := ((-58958072487 : ℝ) / 1000000000000)) (hi := ((-29479036243 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((719258343 : ℝ) / 97656250000) = Real.log ((5754066744 : ℝ) / 6103515625) - 7 * Real.log 2 := by
    rw [show ((719258343 : ℝ) / 97656250000) = ((5754066744 : ℝ) / 6103515625) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_111 : RB (Real.log ((125920650679 : ℝ) / 125000000000)) ((7338214753 : ℝ) / 1000000000000) ((3669107377 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((125920650679 : ℝ) / 125000000000)) (t := ((920650679 : ℝ) / 250920650679))
    (lo := ((7338214753 : ℝ) / 1000000000000)) (hi := ((3669107377 : ℝ) / 500000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_112 : RB (Real.log ((201596537203 : ℝ) / 200000000000)) ((7950992929 : ℝ) / 1000000000000) ((795099293 : ℝ) / 100000000000) := by
  have hm := log_bounds_of_series (x := ((201596537203 : ℝ) / 200000000000)) (t := ((1596537203 : ℝ) / 401596537203))
    (lo := ((7950992929 : ℝ) / 1000000000000)) (hi := ((795099293 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_113 : RB (Real.log ((965402514259 : ℝ) / 1000000000000)) ((-35210151389 : ℝ) / 1000000000000) ((-8802537847 : ℝ) / 250000000000) := by
  have hm := log_bounds_of_series (x := ((965402514259 : ℝ) / 1000000000000)) (t := ((-34597485741 : ℝ) / 1965402514259))
    (lo := ((-35210151389 : ℝ) / 1000000000000)) (hi := ((-8802537847 : ℝ) / 250000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_114 : RB (Real.log ((482710570809 : ℝ) / 500000000000)) ((-35190856661 : ℝ) / 1000000000000) ((-1759542833 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((482710570809 : ℝ) / 500000000000)) (t := ((-17289429191 : ℝ) / 982710570809))
    (lo := ((-35190856661 : ℝ) / 1000000000000)) (hi := ((-1759542833 : ℝ) / 50000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem dlower_log_115 : RB (Real.log ((491230793963 : ℝ) / 1000000000000)) ((-355420606411 : ℝ) / 500000000000) ((-35542060641 : ℝ) / 50000000000) := by
  have hm := log_bounds_of_series (x := ((491230793963 : ℝ) / 500000000000)) (t := ((-8769206037 : ℝ) / 991230793963))
    (lo := ((-8847016131 : ℝ) / 500000000000)) (hi := ((-17694032261 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((491230793963 : ℝ) / 1000000000000) = Real.log ((491230793963 : ℝ) / 500000000000) - 1 * Real.log 2 := by
    rw [show ((491230793963 : ℝ) / 1000000000000) = ((491230793963 : ℝ) / 500000000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_116 : RB (Real.log ((1673417245497 : ℝ) / 500000000000)) ((151001871381 : ℝ) / 125000000000) ((24160299421 : ℝ) / 20000000000) := by
  have hm := log_bounds_of_series (x := ((1673417245497 : ℝ) / 2000000000000)) (t := ((-326582754503 : ℝ) / 3673417245497))
    (lo := ((-178279390071 : ℝ) / 1000000000000)) (hi := ((-17827939007 : ℝ) / 100000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1673417245497 : ℝ) / 500000000000) = Real.log ((1673417245497 : ℝ) / 2000000000000) + 2 * Real.log 2 := by
    rw [show ((1673417245497 : ℝ) / 500000000000) = ((1673417245497 : ℝ) / 2000000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_117 : RB (Real.log ((209178545839 : ℝ) / 62500000000)) ((1208021616837 : ℝ) / 1000000000000) ((1208021616839 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((209178545839 : ℝ) / 250000000000)) (t := ((-40821454161 : ℝ) / 459178545839))
    (lo := ((-89136372141 : ℝ) / 500000000000)) (hi := ((-178272744281 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((209178545839 : ℝ) / 62500000000) = Real.log ((209178545839 : ℝ) / 250000000000) + 2 * Real.log 2 := by
    rw [show ((209178545839 : ℝ) / 62500000000) = ((209178545839 : ℝ) / 250000000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_118 : RB (Real.log ((1426078737363 : ℝ) / 1000000000000)) ((44366067001 : ℝ) / 125000000000) ((354928536011 : ℝ) / 1000000000000) := by
  have hm := log_bounds_of_series (x := ((1426078737363 : ℝ) / 2000000000000)) (t := ((-573921262637 : ℝ) / 3426078737363))
    (lo := ((-338218644551 : ℝ) / 1000000000000)) (hi := ((-338218644549 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1426078737363 : ℝ) / 1000000000000) = Real.log ((1426078737363 : ℝ) / 2000000000000) + 1 * Real.log 2 := by
    rw [show ((1426078737363 : ℝ) / 1000000000000) = ((1426078737363 : ℝ) / 2000000000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

theorem dlower_log_119 : RB (Real.log ((431474721779 : ℝ) / 50000000000000)) ((-297035584863 : ℝ) / 62500000000) ((-2376284678903 : ℝ) / 500000000000) := by
  have hm := log_bounds_of_series (x := ((431474721779 : ℝ) / 390625000000)) (t := ((40849721779 : ℝ) / 822099721779))
    (lo := ((777038329 : ℝ) / 7812500000)) (hi := ((99460906113 : ℝ) / 1000000000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((431474721779 : ℝ) / 50000000000000) = Real.log ((431474721779 : ℝ) / 390625000000) - 7 * Real.log 2 := by
    rw [show ((431474721779 : ℝ) / 50000000000000) = ((431474721779 : ℝ) / 390625000000) / (2 : ℝ) ^ 7 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, witness_log_two.1, witness_log_two.2]

end EP1038.DLowerCert
