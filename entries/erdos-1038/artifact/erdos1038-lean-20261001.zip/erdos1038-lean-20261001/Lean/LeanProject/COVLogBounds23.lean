import LeanProject.COVLogTwo
import LeanProject.COVLogBounds19
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_1840 : RB (Real.log ((47467083 : ℝ) / 25000000)) ((12823213 : ℝ) / 20000000) ((64116067 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((47467083 : ℝ) / 50000000)) (t := ((-2532917 : ℝ) / 97467083))
    (lo := ((-5198653 : ℝ) / 100000000)) (hi := ((-1299663 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((47467083 : ℝ) / 25000000) = Real.log ((47467083 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((47467083 : ℝ) / 25000000) = ((47467083 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1841 : RB (Real.log ((69299817 : ℝ) / 100000000)) ((-36672793 : ℝ) / 100000000) ((-4584099 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((69299817 : ℝ) / 100000000)) (t := ((-30700183 : ℝ) / 169299817))
    (lo := ((-36672793 : ℝ) / 100000000)) (hi := ((-4584099 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1842 : RB (Real.log ((69299819 : ℝ) / 100000000)) ((-3667279 : ℝ) / 10000000) ((-36672789 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((69299819 : ℝ) / 100000000)) (t := ((-30700181 : ℝ) / 169299819))
    (lo := ((-3667279 : ℝ) / 10000000)) (hi := ((-36672789 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1843 : RB (Real.log ((40974153 : ℝ) / 100000000)) ((-713783 : ℝ) / 800000) ((-89222873 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40974153 : ℝ) / 50000000)) (t := ((-9025847 : ℝ) / 90974153))
    (lo := ((-4977039 : ℝ) / 25000000)) (hi := ((-3981631 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40974153 : ℝ) / 100000000) = Real.log ((40974153 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40974153 : ℝ) / 100000000) = ((40974153 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1844 : RB (Real.log ((49715517 : ℝ) / 12500000)) ((27611769 : ℝ) / 20000000) ((4314339 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((49715517 : ℝ) / 50000000)) (t := ((-284483 : ℝ) / 99715517))
    (lo := ((-570591 : ℝ) / 100000000)) (hi := ((-57059 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((49715517 : ℝ) / 12500000) = Real.log ((49715517 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((49715517 : ℝ) / 12500000) = ((49715517 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1845 : RB (Real.log ((19886207 : ℝ) / 5000000)) ((69029423 : ℝ) / 50000000) ((138058849 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((19886207 : ℝ) / 20000000)) (t := ((-113793 : ℝ) / 39886207))
    (lo := ((-57059 : ℝ) / 10000000)) (hi := ((-570589 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((19886207 : ℝ) / 5000000) = Real.log ((19886207 : ℝ) / 20000000) + 2 * Real.log 2 := by
    rw [show ((19886207 : ℝ) / 5000000) = ((19886207 : ℝ) / 20000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1846 : RB (Real.log ((133564847 : ℝ) / 100000000)) ((28941691 : ℝ) / 100000000) ((28941693 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133564847 : ℝ) / 200000000)) (t := ((-66435153 : ℝ) / 333564847))
    (lo := ((-40373027 : ℝ) / 100000000)) (hi := ((-20186513 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133564847 : ℝ) / 100000000) = Real.log ((133564847 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133564847 : ℝ) / 100000000) = ((133564847 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1847 : RB (Real.log ((1961603 : ℝ) / 500000)) ((136690917 : ℝ) / 100000000) ((3417273 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((1961603 : ℝ) / 2000000)) (t := ((-38397 : ℝ) / 3961603))
    (lo := ((-1938519 : ℝ) / 100000000)) (hi := ((-969259 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1961603 : ℝ) / 500000) = Real.log ((1961603 : ℝ) / 2000000) + 2 * Real.log 2 := by
    rw [show ((1961603 : ℝ) / 500000) = ((1961603 : ℝ) / 2000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1848 : RB (Real.log ((98080151 : ℝ) / 25000000)) ((68345459 : ℝ) / 50000000) ((136690921 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((98080151 : ℝ) / 100000000)) (t := ((-1919849 : ℝ) / 198080151))
    (lo := ((-969259 : ℝ) / 50000000)) (hi := ((-1938517 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((98080151 : ℝ) / 25000000) = Real.log ((98080151 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((98080151 : ℝ) / 25000000) = ((98080151 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1849 : RB (Real.log ((33546323 : ℝ) / 25000000)) ((29405143 : ℝ) / 100000000) ((5881029 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((33546323 : ℝ) / 50000000)) (t := ((-16453677 : ℝ) / 83546323))
    (lo := ((-1596383 : ℝ) / 4000000)) (hi := ((-19954787 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33546323 : ℝ) / 25000000) = Real.log ((33546323 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((33546323 : ℝ) / 25000000) = ((33546323 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1850 : RB (Real.log ((4258531 : ℝ) / 25000000)) ((-88497579 : ℝ) / 50000000) ((-35399031 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((4258531 : ℝ) / 6250000)) (t := ((-1991469 : ℝ) / 10508531))
    (lo := ((-959143 : ℝ) / 2500000)) (hi := ((-38365719 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4258531 : ℝ) / 25000000) = Real.log ((4258531 : ℝ) / 6250000) - 2 * Real.log 2 := by
    rw [show ((4258531 : ℝ) / 25000000) = ((4258531 : ℝ) / 6250000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1851 : RB (Real.log ((20798833 : ℝ) / 100000000)) ((-157027333 : ℝ) / 100000000) ((-15702733 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((20798833 : ℝ) / 25000000)) (t := ((-4201167 : ℝ) / 45798833))
    (lo := ((-3679579 : ℝ) / 20000000)) (hi := ((-9198947 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20798833 : ℝ) / 100000000) = Real.log ((20798833 : ℝ) / 25000000) - 2 * Real.log 2 := by
    rw [show ((20798833 : ℝ) / 100000000) = ((20798833 : ℝ) / 25000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1852 : RB (Real.log ((2499999 : ℝ) / 50000000)) ((-37446659 : ℝ) / 12500000) ((-299573267 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2499999 : ℝ) / 3125000)) (t := ((-625001 : ℝ) / 5624999))
    (lo := ((-5578599 : ℝ) / 25000000)) (hi := ((-4462879 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2499999 : ℝ) / 50000000) = Real.log ((2499999 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((2499999 : ℝ) / 50000000) = ((2499999 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1853 : RB (Real.log ((5000001 : ℝ) / 100000000)) ((-74893303 : ℝ) / 25000000) ((-299573207 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((5000001 : ℝ) / 6250000)) (t := ((-1249999 : ℝ) / 11250001))
    (lo := ((-697323 : ℝ) / 3125000)) (hi := ((-4462867 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5000001 : ℝ) / 100000000) = Real.log ((5000001 : ℝ) / 6250000) - 4 * Real.log 2 := by
    rw [show ((5000001 : ℝ) / 100000000) = ((5000001 : ℝ) / 6250000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1854 : RB (Real.log ((33644851 : ℝ) / 50000000)) ((-19808149 : ℝ) / 50000000) ((-39616297 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((33644851 : ℝ) / 50000000)) (t := ((-16355149 : ℝ) / 83644851))
    (lo := ((-19808149 : ℝ) / 50000000)) (hi := ((-39616297 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1855 : RB (Real.log ((13457941 : ℝ) / 20000000)) ((-19808147 : ℝ) / 50000000) ((-39616293 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((13457941 : ℝ) / 20000000)) (t := ((-6542059 : ℝ) / 33457941))
    (lo := ((-19808147 : ℝ) / 50000000)) (hi := ((-39616293 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1856 : RB (Real.log ((2516557 : ℝ) / 6250000)) ((-45484489 : ℝ) / 50000000) ((-5685561 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((2516557 : ℝ) / 3125000)) (t := ((-608443 : ℝ) / 5641557))
    (lo := ((-21654259 : ℝ) / 100000000)) (hi := ((-10827129 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2516557 : ℝ) / 6250000) = Real.log ((2516557 : ℝ) / 3125000) - 1 * Real.log 2 := by
    rw [show ((2516557 : ℝ) / 6250000) = ((2516557 : ℝ) / 3125000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1857 : RB (Real.log ((35057207 : ℝ) / 50000000)) ((-1775209 : ℝ) / 5000000) ((-35504179 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35057207 : ℝ) / 50000000)) (t := ((-14942793 : ℝ) / 85057207))
    (lo := ((-1775209 : ℝ) / 5000000)) (hi := ((-35504179 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1858 : RB (Real.log ((70114417 : ℝ) / 100000000)) ((-1420167 : ℝ) / 4000000) ((-17752087 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((70114417 : ℝ) / 100000000)) (t := ((-29885583 : ℝ) / 170114417))
    (lo := ((-1420167 : ℝ) / 4000000)) (hi := ((-17752087 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1859 : RB (Real.log ((51571 : ℝ) / 125000)) ((-3541417 : ℝ) / 4000000) ((-88535423 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((51571 : ℝ) / 62500)) (t := ((-10929 : ℝ) / 114071))
    (lo := ((-9610353 : ℝ) / 50000000)) (hi := ((-3844141 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((51571 : ℝ) / 125000) = Real.log ((51571 : ℝ) / 62500) - 1 * Real.log 2 := by
    rw [show ((51571 : ℝ) / 125000) = ((51571 : ℝ) / 62500) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1860 : RB (Real.log ((395861553 : ℝ) / 100000000)) ((68794717 : ℝ) / 50000000) ((137589437 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((395861553 : ℝ) / 400000000)) (t := ((-4138447 : ℝ) / 795861553))
    (lo := ((-520001 : ℝ) / 50000000)) (hi := ((-1040001 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((395861553 : ℝ) / 100000000) = Real.log ((395861553 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((395861553 : ℝ) / 100000000) = ((395861553 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1861 : RB (Real.log ((395861557 : ℝ) / 100000000)) ((27517887 : ℝ) / 20000000) ((68794719 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((395861557 : ℝ) / 400000000)) (t := ((-4138443 : ℝ) / 795861557))
    (lo := ((-1040001 : ℝ) / 100000000)) (hi := ((-13 : ℝ) / 1250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((395861557 : ℝ) / 100000000) = Real.log ((395861557 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((395861557 : ℝ) / 100000000) = ((395861557 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1862 : RB (Real.log ((133776153 : ℝ) / 100000000)) ((29099771 : ℝ) / 100000000) ((29099773 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133776153 : ℝ) / 200000000)) (t := ((-66223847 : ℝ) / 333776153))
    (lo := ((-40214947 : ℝ) / 100000000)) (hi := ((-20107473 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133776153 : ℝ) / 100000000) = Real.log ((133776153 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133776153 : ℝ) / 100000000) = ((133776153 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1863 : RB (Real.log ((97659667 : ℝ) / 25000000)) ((68130641 : ℝ) / 50000000) ((27252257 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((97659667 : ℝ) / 100000000)) (t := ((-2340333 : ℝ) / 197659667))
    (lo := ((-1184077 : ℝ) / 50000000)) (hi := ((-2368153 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97659667 : ℝ) / 25000000) = Real.log ((97659667 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((97659667 : ℝ) / 25000000) = ((97659667 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1864 : RB (Real.log ((24414917 : ℝ) / 6250000)) ((136261283 : ℝ) / 100000000) ((68130643 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((24414917 : ℝ) / 25000000)) (t := ((-585083 : ℝ) / 49414917))
    (lo := ((-2368153 : ℝ) / 100000000)) (hi := ((-296019 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((24414917 : ℝ) / 6250000) = Real.log ((24414917 : ℝ) / 25000000) + 2 * Real.log 2 := by
    rw [show ((24414917 : ℝ) / 6250000) = ((24414917 : ℝ) / 25000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1865 : RB (Real.log ((134383123 : ℝ) / 100000000)) ((14776233 : ℝ) / 50000000) ((7388117 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((134383123 : ℝ) / 200000000)) (t := ((-65616877 : ℝ) / 334383123))
    (lo := ((-9940563 : ℝ) / 25000000)) (hi := ((-39762251 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((134383123 : ℝ) / 100000000) = Real.log ((134383123 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((134383123 : ℝ) / 100000000) = ((134383123 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1866 : RB (Real.log ((1895639 : ℝ) / 10000000)) ((-166302913 : ℝ) / 100000000) ((-16630291 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((1895639 : ℝ) / 2500000)) (t := ((-604361 : ℝ) / 4395639))
    (lo := ((-1106939 : ℝ) / 4000000)) (hi := ((-13836737 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1895639 : ℝ) / 10000000) = Real.log ((1895639 : ℝ) / 2500000) - 2 * Real.log 2 := by
    rw [show ((1895639 : ℝ) / 10000000) = ((1895639 : ℝ) / 2500000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1867 : RB (Real.log ((22421413 : ℝ) / 100000000)) ((-149515377 : ℝ) / 100000000) ((-74757687 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((22421413 : ℝ) / 25000000)) (t := ((-2578587 : ℝ) / 47421413))
    (lo := ((-10885939 : ℝ) / 100000000)) (hi := ((-5442969 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((22421413 : ℝ) / 100000000) = Real.log ((22421413 : ℝ) / 25000000) - 2 * Real.log 2 := by
    rw [show ((22421413 : ℝ) / 100000000) = ((22421413 : ℝ) / 25000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1868 : RB (Real.log ((1067623 : ℝ) / 1562500)) ((-38085243 : ℝ) / 100000000) ((-19042621 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1067623 : ℝ) / 1562500)) (t := ((-494877 : ℝ) / 2630123))
    (lo := ((-38085243 : ℝ) / 100000000)) (hi := ((-19042621 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1869 : RB (Real.log ((546623 : ℝ) / 800000)) ((-19042619 : ℝ) / 50000000) ((-38085237 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((546623 : ℝ) / 800000)) (t := ((-253377 : ℝ) / 1346623))
    (lo := ((-19042619 : ℝ) / 50000000)) (hi := ((-38085237 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1870 : RB (Real.log ((40633331 : ℝ) / 100000000)) ((-90058151 : ℝ) / 100000000) ((-90058149 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((40633331 : ℝ) / 50000000)) (t := ((-9366669 : ℝ) / 90633331))
    (lo := ((-2592929 : ℝ) / 12500000)) (hi := ((-20743431 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((40633331 : ℝ) / 100000000) = Real.log ((40633331 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((40633331 : ℝ) / 100000000) = ((40633331 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1871 : RB (Real.log ((8857029 : ℝ) / 12500000)) ((-34451727 : ℝ) / 100000000) ((-17225863 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8857029 : ℝ) / 12500000)) (t := ((-3642971 : ℝ) / 21357029))
    (lo := ((-34451727 : ℝ) / 100000000)) (hi := ((-17225863 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1872 : RB (Real.log ((35428117 : ℝ) / 50000000)) ((-8612931 : ℝ) / 25000000) ((-34451723 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((35428117 : ℝ) / 50000000)) (t := ((-14571883 : ℝ) / 85428117))
    (lo := ((-8612931 : ℝ) / 25000000)) (hi := ((-34451723 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1873 : RB (Real.log ((41511849 : ℝ) / 100000000)) ((-8791913 : ℝ) / 10000000) ((-10989891 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((41511849 : ℝ) / 50000000)) (t := ((-8488151 : ℝ) / 91511849))
    (lo := ((-18604411 : ℝ) / 100000000)) (hi := ((-1860441 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41511849 : ℝ) / 100000000) = Real.log ((41511849 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41511849 : ℝ) / 100000000) = ((41511849 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1874 : RB (Real.log ((394062241 : ℝ) / 100000000)) ((34283467 : ℝ) / 25000000) ((137133871 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((394062241 : ℝ) / 400000000)) (t := ((-5937759 : ℝ) / 794062241))
    (lo := ((-93473 : ℝ) / 6250000)) (hi := ((-1495567 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((394062241 : ℝ) / 100000000) = Real.log ((394062241 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((394062241 : ℝ) / 100000000) = ((394062241 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1875 : RB (Real.log ((78812449 : ℝ) / 20000000)) ((137133869 : ℝ) / 100000000) ((8570867 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((78812449 : ℝ) / 80000000)) (t := ((-1187551 : ℝ) / 158812449))
    (lo := ((-1495567 : ℝ) / 100000000)) (hi := ((-747783 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((78812449 : ℝ) / 20000000) = Real.log ((78812449 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((78812449 : ℝ) / 20000000) = ((78812449 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1876 : RB (Real.log ((133982823 : ℝ) / 100000000)) ((29254141 : ℝ) / 100000000) ((29254143 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((133982823 : ℝ) / 200000000)) (t := ((-66017177 : ℝ) / 333982823))
    (lo := ((-40060577 : ℝ) / 100000000)) (hi := ((-1251893 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((133982823 : ℝ) / 100000000) = Real.log ((133982823 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((133982823 : ℝ) / 100000000) = ((133982823 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1877 : RB (Real.log ((38901109 : ℝ) / 10000000)) ((67921883 : ℝ) / 50000000) ((135843769 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((38901109 : ℝ) / 40000000)) (t := ((-1098891 : ℝ) / 78901109))
    (lo := ((-278567 : ℝ) / 10000000)) (hi := ((-2785669 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((38901109 : ℝ) / 10000000) = Real.log ((38901109 : ℝ) / 40000000) + 2 * Real.log 2 := by
    rw [show ((38901109 : ℝ) / 10000000) = ((38901109 : ℝ) / 40000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1878 : RB (Real.log ((194505547 : ℝ) / 50000000)) ((135843767 : ℝ) / 100000000) ((13584377 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((194505547 : ℝ) / 200000000)) (t := ((-5494453 : ℝ) / 394505547))
    (lo := ((-2785669 : ℝ) / 100000000)) (hi := ((-696417 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((194505547 : ℝ) / 50000000) = Real.log ((194505547 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((194505547 : ℝ) / 50000000) = ((194505547 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1879 : RB (Real.log ((134576753 : ℝ) / 100000000)) ((593929 : ℝ) / 2000000) ((7424113 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((134576753 : ℝ) / 200000000)) (t := ((-65423247 : ℝ) / 334576753))
    (lo := ((-9904567 : ℝ) / 25000000)) (hi := ((-39618267 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((134576753 : ℝ) / 100000000) = Real.log ((134576753 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((134576753 : ℝ) / 100000000) = ((134576753 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1880 : RB (Real.log ((20758899 : ℝ) / 100000000)) ((-157219519 : ℝ) / 100000000) ((-39304879 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((20758899 : ℝ) / 25000000)) (t := ((-4241101 : ℝ) / 45758899))
    (lo := ((-18590081 : ℝ) / 100000000)) (hi := ((-29047 : ℝ) / 156250)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((20758899 : ℝ) / 100000000) = Real.log ((20758899 : ℝ) / 25000000) - 2 * Real.log 2 := by
    rw [show ((20758899 : ℝ) / 100000000) = ((20758899 : ℝ) / 25000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1881 : RB (Real.log ((23986459 : ℝ) / 100000000)) ((-5710723 : ℝ) / 4000000) ((-17846009 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((23986459 : ℝ) / 25000000)) (t := ((-1013541 : ℝ) / 48986459))
    (lo := ((-4138637 : ℝ) / 100000000)) (hi := ((-1034659 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((23986459 : ℝ) / 100000000) = Real.log ((23986459 : ℝ) / 25000000) - 2 * Real.log 2 := by
    rw [show ((23986459 : ℝ) / 100000000) = ((23986459 : ℝ) / 25000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1882 : RB (Real.log ((69249973 : ℝ) / 100000000)) ((-4593093 : ℝ) / 12500000) ((-36744743 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((69249973 : ℝ) / 100000000)) (t := ((-30750027 : ℝ) / 169249973))
    (lo := ((-4593093 : ℝ) / 12500000)) (hi := ((-36744743 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1883 : RB (Real.log ((2769999 : ℝ) / 4000000)) ((-36744741 : ℝ) / 100000000) ((-1837237 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((2769999 : ℝ) / 4000000)) (t := ((-1230001 : ℝ) / 6769999))
    (lo := ((-36744741 : ℝ) / 100000000)) (hi := ((-1837237 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1884 : RB (Real.log ((4095677 : ℝ) / 10000000)) ((-22316327 : ℝ) / 25000000) ((-44632653 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((4095677 : ℝ) / 5000000)) (t := ((-904323 : ℝ) / 9095677))
    (lo := ((-19950589 : ℝ) / 100000000)) (hi := ((-4987647 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4095677 : ℝ) / 10000000) = Real.log ((4095677 : ℝ) / 5000000) - 1 * Real.log 2 := by
    rw [show ((4095677 : ℝ) / 10000000) = ((4095677 : ℝ) / 5000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1885 : RB (Real.log ((71535589 : ℝ) / 100000000)) ((-4187189 : ℝ) / 12500000) ((-33497511 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((71535589 : ℝ) / 100000000)) (t := ((-28464411 : ℝ) / 171535589))
    (lo := ((-4187189 : ℝ) / 12500000)) (hi := ((-33497511 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1886 : RB (Real.log ((71535591 : ℝ) / 100000000)) ((-33497509 : ℝ) / 100000000) ((-8374377 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((71535591 : ℝ) / 100000000)) (t := ((-28464409 : ℝ) / 171535591))
    (lo := ((-33497509 : ℝ) / 100000000)) (hi := ((-8374377 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1887 : RB (Real.log ((326121 : ℝ) / 781250)) ((-43681337 : ℝ) / 50000000) ((-5460167 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((326121 : ℝ) / 390625)) (t := ((-32252 : ℝ) / 358373))
    (lo := ((-3609591 : ℝ) / 20000000)) (hi := ((-9023977 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((326121 : ℝ) / 781250) = Real.log ((326121 : ℝ) / 390625) - 1 * Real.log 2 := by
    rw [show ((326121 : ℝ) / 781250) = ((326121 : ℝ) / 390625) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1888 : RB (Real.log ((392323037 : ℝ) / 100000000)) ((68345769 : ℝ) / 50000000) ((136691541 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((392323037 : ℝ) / 400000000)) (t := ((-7676963 : ℝ) / 792323037))
    (lo := ((-968949 : ℝ) / 50000000)) (hi := ((-1937897 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((392323037 : ℝ) / 100000000) = Real.log ((392323037 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((392323037 : ℝ) / 100000000) = ((392323037 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1889 : RB (Real.log ((392323041 : ℝ) / 100000000)) ((136691539 : ℝ) / 100000000) ((68345771 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((392323041 : ℝ) / 400000000)) (t := ((-7676959 : ℝ) / 792323041))
    (lo := ((-1937897 : ℝ) / 100000000)) (hi := ((-242237 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((392323041 : ℝ) / 100000000) = Real.log ((392323041 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((392323041 : ℝ) / 100000000) = ((392323041 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1890 : RB (Real.log ((134185007 : ℝ) / 100000000)) ((29404931 : ℝ) / 100000000) ((29404933 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((134185007 : ℝ) / 200000000)) (t := ((-65814993 : ℝ) / 334185007))
    (lo := ((-39909787 : ℝ) / 100000000)) (hi := ((-19954893 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((134185007 : ℝ) / 100000000) = Real.log ((134185007 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((134185007 : ℝ) / 100000000) = ((134185007 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1891 : RB (Real.log ((77487057 : ℝ) / 20000000)) ((16929733 : ℝ) / 12500000) ((135437867 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((77487057 : ℝ) / 80000000)) (t := ((-2512943 : ℝ) / 157487057))
    (lo := ((-797893 : ℝ) / 25000000)) (hi := ((-3191571 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((77487057 : ℝ) / 20000000) = Real.log ((77487057 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((77487057 : ℝ) / 20000000) = ((77487057 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1892 : RB (Real.log ((387435289 : ℝ) / 100000000)) ((27087573 : ℝ) / 20000000) ((33859467 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((387435289 : ℝ) / 400000000)) (t := ((-12564711 : ℝ) / 787435289))
    (lo := ((-3191571 : ℝ) / 100000000)) (hi := ((-319157 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((387435289 : ℝ) / 100000000) = Real.log ((387435289 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((387435289 : ℝ) / 100000000) = ((387435289 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1893 : RB (Real.log ((134766313 : ℝ) / 100000000)) ((29837207 : ℝ) / 100000000) ((29837209 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((134766313 : ℝ) / 200000000)) (t := ((-65233687 : ℝ) / 334766313))
    (lo := ((-39477511 : ℝ) / 100000000)) (hi := ((-3947751 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((134766313 : ℝ) / 100000000) = Real.log ((134766313 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((134766313 : ℝ) / 100000000) = ((134766313 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1894 : RB (Real.log ((2808453 : ℝ) / 12500000)) ((-149309487 : ℝ) / 100000000) ((-37327371 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2808453 : ℝ) / 3125000)) (t := ((-316547 : ℝ) / 5933453))
    (lo := ((-10680049 : ℝ) / 100000000)) (hi := ((-667503 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2808453 : ℝ) / 12500000) = Real.log ((2808453 : ℝ) / 3125000) - 2 * Real.log 2 := by
    rw [show ((2808453 : ℝ) / 12500000) = ((2808453 : ℝ) / 3125000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1895 : RB (Real.log ((3187713 : ℝ) / 12500000)) ((-68321247 : ℝ) / 50000000) ((-136642491 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((3187713 : ℝ) / 3125000)) (t := ((62713 : ℝ) / 6312713))
    (lo := ((15523 : ℝ) / 781250)) (hi := ((397389 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3187713 : ℝ) / 12500000) = Real.log ((3187713 : ℝ) / 3125000) - 2 * Real.log 2 := by
    rw [show ((3187713 : ℝ) / 12500000) = ((3187713 : ℝ) / 3125000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1896 : RB (Real.log ((34728203 : ℝ) / 50000000)) ((-36447089 : ℝ) / 100000000) ((-2277943 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((34728203 : ℝ) / 50000000)) (t := ((-15271797 : ℝ) / 84728203))
    (lo := ((-36447089 : ℝ) / 100000000)) (hi := ((-2277943 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1897 : RB (Real.log ((69456409 : ℝ) / 100000000)) ((-9111771 : ℝ) / 25000000) ((-36447083 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((69456409 : ℝ) / 100000000)) (t := ((-30543591 : ℝ) / 169456409))
    (lo := ((-9111771 : ℝ) / 25000000)) (hi := ((-36447083 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1898 : RB (Real.log ((41028697 : ℝ) / 100000000)) ((-17817969 : ℝ) / 20000000) ((-89089843 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((41028697 : ℝ) / 50000000)) (t := ((-8971303 : ℝ) / 91028697))
    (lo := ((-9887563 : ℝ) / 50000000)) (hi := ((-158201 : ℝ) / 800000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((41028697 : ℝ) / 100000000) = Real.log ((41028697 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((41028697 : ℝ) / 100000000) = ((41028697 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1899 : RB (Real.log ((18362403 : ℝ) / 25000000)) ((-30857057 : ℝ) / 100000000) ((-964283 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((18362403 : ℝ) / 25000000)) (t := ((-6637597 : ℝ) / 43362403))
    (lo := ((-30857057 : ℝ) / 100000000)) (hi := ((-964283 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1900 : RB (Real.log ((14689923 : ℝ) / 20000000)) ((-30857053 : ℝ) / 100000000) ((-7714263 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((14689923 : ℝ) / 20000000)) (t := ((-5310077 : ℝ) / 34689923))
    (lo := ((-30857053 : ℝ) / 100000000)) (hi := ((-7714263 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1901 : RB (Real.log ((42386351 : ℝ) / 100000000)) ((-4291719 : ℝ) / 5000000) ((-42917189 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((42386351 : ℝ) / 50000000)) (t := ((-7613649 : ℝ) / 92386351))
    (lo := ((-16519661 : ℝ) / 100000000)) (hi := ((-825983 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42386351 : ℝ) / 100000000) = Real.log ((42386351 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42386351 : ℝ) / 100000000) = ((42386351 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1902 : RB (Real.log ((392219613 : ℝ) / 100000000)) ((136665173 : ℝ) / 100000000) ((17083147 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((392219613 : ℝ) / 400000000)) (t := ((-7780387 : ℝ) / 792219613))
    (lo := ((-1964263 : ℝ) / 100000000)) (hi := ((-982131 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((392219613 : ℝ) / 100000000) = Real.log ((392219613 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((392219613 : ℝ) / 100000000) = ((392219613 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1903 : RB (Real.log ((392219617 : ℝ) / 100000000)) ((68332587 : ℝ) / 50000000) ((136665177 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((392219617 : ℝ) / 400000000)) (t := ((-7780383 : ℝ) / 792219617))
    (lo := ((-982131 : ℝ) / 50000000)) (hi := ((-1964261 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((392219617 : ℝ) / 100000000) = Real.log ((392219617 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((392219617 : ℝ) / 100000000) = ((392219617 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1904 : RB (Real.log ((67098553 : ℝ) / 50000000)) ((29413947 : ℝ) / 100000000) ((29413949 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((67098553 : ℝ) / 100000000)) (t := ((-32901447 : ℝ) / 167098553))
    (lo := ((-39900771 : ℝ) / 100000000)) (hi := ((-3990077 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((67098553 : ℝ) / 50000000) = Real.log ((67098553 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((67098553 : ℝ) / 50000000) = ((67098553 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1905 : RB (Real.log ((382901953 : ℝ) / 100000000)) ((134260877 : ℝ) / 100000000) ((1678261 : ℝ) / 1250000) := by
  have hm := log_bounds_of_series (x := ((382901953 : ℝ) / 400000000)) (t := ((-17098047 : ℝ) / 782901953))
    (lo := ((-4368559 : ℝ) / 100000000)) (hi := ((-2184279 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((382901953 : ℝ) / 100000000) = Real.log ((382901953 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((382901953 : ℝ) / 100000000) = ((382901953 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1906 : RB (Real.log ((382901957 : ℝ) / 100000000)) ((67130439 : ℝ) / 50000000) ((134260881 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((382901957 : ℝ) / 400000000)) (t := ((-17098043 : ℝ) / 782901957))
    (lo := ((-2184279 : ℝ) / 50000000)) (hi := ((-4368557 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((382901957 : ℝ) / 100000000) = Real.log ((382901957 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((382901957 : ℝ) / 100000000) = ((382901957 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1907 : RB (Real.log ((67661711 : ℝ) / 50000000)) ((1890609 : ℝ) / 6250000) ((15124873 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((67661711 : ℝ) / 100000000)) (t := ((-32338289 : ℝ) / 167661711))
    (lo := ((-19532487 : ℝ) / 50000000)) (hi := ((-39064973 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((67661711 : ℝ) / 50000000) = Real.log ((67661711 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((67661711 : ℝ) / 50000000) = ((67661711 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1908 : RB (Real.log ((2937227 : ℝ) / 12500000)) ((-144826273 : ℝ) / 100000000) ((-14482627 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((2937227 : ℝ) / 3125000)) (t := ((-187773 : ℝ) / 6062227))
    (lo := ((-1239367 : ℝ) / 20000000)) (hi := ((-3098417 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2937227 : ℝ) / 12500000) = Real.log ((2937227 : ℝ) / 3125000) - 2 * Real.log 2 := by
    rw [show ((2937227 : ℝ) / 12500000) = ((2937227 : ℝ) / 3125000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1909 : RB (Real.log ((5821721 : ℝ) / 20000000)) ((-123413637 : ℝ) / 100000000) ((-61706817 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((5821721 : ℝ) / 5000000)) (t := ((821721 : ℝ) / 10821721))
    (lo := ((15215801 : ℝ) / 100000000)) (hi := ((7607901 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((5821721 : ℝ) / 20000000) = Real.log ((5821721 : ℝ) / 5000000) - 2 * Real.log 2 := by
    rw [show ((5821721 : ℝ) / 20000000) = ((5821721 : ℝ) / 5000000) / (2 : ℝ) ^ 2 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1910 : RB (Real.log ((17745293 : ℝ) / 25000000)) ((-34275553 : ℝ) / 100000000) ((-1071111 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((17745293 : ℝ) / 25000000)) (t := ((-7254707 : ℝ) / 42745293))
    (lo := ((-34275553 : ℝ) / 100000000)) (hi := ((-1071111 : ℝ) / 3125000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1911 : RB (Real.log ((2839247 : ℝ) / 4000000)) ((-34275549 : ℝ) / 100000000) ((-8568887 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2839247 : ℝ) / 4000000)) (t := ((-1160753 : ℝ) / 6839247))
    (lo := ((-34275549 : ℝ) / 100000000)) (hi := ((-8568887 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1912 : RB (Real.log ((10388647 : ℝ) / 25000000)) ((-43908113 : ℝ) / 50000000) ((-2744257 : ℝ) / 3125000) := by
  have hm := log_bounds_of_series (x := ((10388647 : ℝ) / 12500000)) (t := ((-2111353 : ℝ) / 22888647))
    (lo := ((-18501507 : ℝ) / 100000000)) (hi := ((-9250753 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10388647 : ℝ) / 25000000) = Real.log ((10388647 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10388647 : ℝ) / 25000000) = ((10388647 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1913 : RB (Real.log ((9296921 : ℝ) / 12500000)) ((-14802269 : ℝ) / 50000000) ((-29604537 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9296921 : ℝ) / 12500000)) (t := ((-3203079 : ℝ) / 21796921))
    (lo := ((-14802269 : ℝ) / 50000000)) (hi := ((-29604537 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1914 : RB (Real.log ((74375371 : ℝ) / 100000000)) ((-14802267 : ℝ) / 50000000) ((-29604533 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((74375371 : ℝ) / 100000000)) (t := ((-25624629 : ℝ) / 174375371))
    (lo := ((-14802267 : ℝ) / 50000000)) (hi := ((-29604533 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_1915 : RB (Real.log ((42692221 : ℝ) / 100000000)) ((-85115347 : ℝ) / 100000000) ((-17023069 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((42692221 : ℝ) / 50000000)) (t := ((-7307779 : ℝ) / 92692221))
    (lo := ((-3950157 : ℝ) / 25000000)) (hi := ((-15800627 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42692221 : ℝ) / 100000000) = Real.log ((42692221 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42692221 : ℝ) / 100000000) = ((42692221 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1916 : RB (Real.log ((388918349 : ℝ) / 100000000)) ((135819923 : ℝ) / 100000000) ((67909963 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((388918349 : ℝ) / 400000000)) (t := ((-11081651 : ℝ) / 788918349))
    (lo := ((-2809513 : ℝ) / 100000000)) (hi := ((-351189 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((388918349 : ℝ) / 100000000) = Real.log ((388918349 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((388918349 : ℝ) / 100000000) = ((388918349 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1917 : RB (Real.log ((388918353 : ℝ) / 100000000)) ((33954981 : ℝ) / 25000000) ((135819927 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((388918353 : ℝ) / 400000000)) (t := ((-11081647 : ℝ) / 788918353))
    (lo := ((-351189 : ℝ) / 12500000)) (hi := ((-2809511 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((388918353 : ℝ) / 100000000) = Real.log ((388918353 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((388918353 : ℝ) / 100000000) = ((388918353 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1918 : RB (Real.log ((33646963 : ℝ) / 25000000)) ((29704697 : ℝ) / 100000000) ((29704699 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((33646963 : ℝ) / 50000000)) (t := ((-16353037 : ℝ) / 83646963))
    (lo := ((-39610021 : ℝ) / 100000000)) (hi := ((-1980501 : ℝ) / 5000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((33646963 : ℝ) / 25000000) = Real.log ((33646963 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((33646963 : ℝ) / 25000000) = ((33646963 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_1919 : RB (Real.log ((76033401 : ℝ) / 20000000)) ((26708809 : ℝ) / 20000000) ((8346503 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((76033401 : ℝ) / 80000000)) (t := ((-3966599 : ℝ) / 156033401))
    (lo := ((-5085391 : ℝ) / 100000000)) (hi := ((-508539 : ℝ) / 10000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((76033401 : ℝ) / 20000000) = Real.log ((76033401 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((76033401 : ℝ) / 20000000) = ((76033401 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]
end EP1038.ReferenceCert
