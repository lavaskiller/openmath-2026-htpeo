import LeanProject.TerminalGeometry
import LeanProject.COVArcBounds
import LeanProject.COVChunk17
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
set_option linter.unreachableTactic false
set_option linter.unusedTactic false
set_option linter.unnecessarySeqFocus false
theorem cov_signs_105 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((1407 : ℝ) / 2047) ((357 : ℝ) / 517))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((4095677 : ℝ) / 10000000) < 0 ∧ 0 < certE k a ((326121 : ℝ) / 781250) ∧ 0 < certE k a ((134185007 : ℝ) / 100000000) ∧ certE k a ((134766313 : ℝ) / 100000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((4095677 : ℝ) / 10000000)) - (z1)
  have h2 : RB z2 ((40887421 : ℝ) / 100000000) ((20443711 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4095677 : ℝ) / 10000000) ((4095677 : ℝ) / 10000000) ((4095677 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((5904323 : ℝ) / 10000000))
  have h3 : RB z3 ((69249973 : ℝ) / 100000000) ((2769999 : ℝ) / 4000000) := rb_div_signed h2 (show RB ((5904323 : ℝ) / 10000000) ((5904323 : ℝ) / 10000000) ((5904323 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-4593093 : ℝ) / 12500000) ((-1837237 : ℝ) / 5000000) := rb_log h3 (by norm_num) cov_log_1882.1 cov_log_1883.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-3171633 : ℝ) / 12500000) ((-25256399 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((4095677 : ℝ) / 10000000))
  have h6 : RB z6 ((-22316327 : ℝ) / 25000000) ((-44632653 : ℝ) / 50000000) := rb_log (show RB ((4095677 : ℝ) / 10000000) ((4095677 : ℝ) / 10000000) ((4095677 : ℝ) / 10000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1884.1 cov_log_1884.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((31946121 : ℝ) / 50000000) ((64008909 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-8953 : ℝ) / 4000000) ((-53577 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((326121 : ℝ) / 781250)) - (z10)
  have h11 : RB z11 ((41674139 : ℝ) / 100000000) ((2083707 : ℝ) / 5000000) := rb_widen (rb_sub (show RB ((326121 : ℝ) / 781250) ((326121 : ℝ) / 781250) ((326121 : ℝ) / 781250) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((455129 : ℝ) / 781250))
  have h12 : RB z12 ((71535589 : ℝ) / 100000000) ((71535591 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((455129 : ℝ) / 781250) ((455129 : ℝ) / 781250) ((455129 : ℝ) / 781250) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-4187189 : ℝ) / 12500000) ((-8374377 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1885.1 cov_log_1886.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-11565389 : ℝ) / 50000000) ((-11512211 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((326121 : ℝ) / 781250))
  have h15 : RB z15 ((-43681337 : ℝ) / 50000000) ((-5460167 : ℝ) / 6250000) := rb_log (show RB ((326121 : ℝ) / 781250) ((326121 : ℝ) / 781250) ((326121 : ℝ) / 781250) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1887.1 cov_log_1887.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((32115947 : ℝ) / 50000000) ((16084563 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((115827 : ℝ) / 100000000) ((222189 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((134185007 : ℝ) / 100000000)) - (z19)
  have h20 : RB z20 ((67057829 : ℝ) / 50000000) ((134115659 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((134185007 : ℝ) / 100000000) ((134185007 : ℝ) / 100000000) ((134185007 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((34185007 : ℝ) / 100000000))
  have h21 : RB z21 ((392323037 : ℝ) / 100000000) ((392323041 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((34185007 : ℝ) / 100000000) ((34185007 : ℝ) / 100000000) ((34185007 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((68345769 : ℝ) / 50000000) ((68345771 : ℝ) / 50000000) := rb_log h21 (by norm_num) cov_log_1888.1 cov_log_1889.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((23488641 : ℝ) / 25000000) ((94388551 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((134185007 : ℝ) / 100000000))
  have h24 : RB z24 ((29404931 : ℝ) / 100000000) ((29404933 : ℝ) / 100000000) := rb_log (show RB ((134185007 : ℝ) / 100000000) ((134185007 : ℝ) / 100000000) ((134185007 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1890.1 cov_log_1890.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64549631 : ℝ) / 100000000) ((3249181 : ℝ) / 5000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((108391 : ℝ) / 25000000) ((867557 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((134766313 : ℝ) / 100000000)) - (z28)
  have h29 : RB z29 ((33674241 : ℝ) / 25000000) ((26939393 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((134766313 : ℝ) / 100000000) ((134766313 : ℝ) / 100000000) ((134766313 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((34766313 : ℝ) / 100000000))
  have h30 : RB z30 ((77487057 : ℝ) / 20000000) ((387435289 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((34766313 : ℝ) / 100000000) ((34766313 : ℝ) / 100000000) ((34766313 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((16929733 : ℝ) / 12500000) ((33859467 : ℝ) / 25000000) := rb_log h30 (by norm_num) cov_log_1891.1 cov_log_1892.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((18618571 : ℝ) / 20000000) ((93522861 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((134766313 : ℝ) / 100000000))
  have h33 : RB z33 ((29837207 : ℝ) / 100000000) ((29837209 : ℝ) / 100000000) := rb_log (show RB ((134766313 : ℝ) / 100000000) ((134766313 : ℝ) / 100000000) ((134766313 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1893.1 cov_log_1893.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((31627823 : ℝ) / 50000000) ((31842827 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-860421 : ℝ) / 100000000) ((-430409 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((4095677 : ℝ) / 10000000)) ((-8953 : ℝ) / 4000000) ((-53577 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((326121 : ℝ) / 781250)) ((115827 : ℝ) / 100000000) ((222189 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((134185007 : ℝ) / 100000000)) ((108391 : ℝ) / 25000000) ((867557 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((134766313 : ℝ) / 100000000)) ((-860421 : ℝ) / 100000000) ((-430409 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_105 {k A q d vp vm : ℝ}
    (hk : RB k ((1407 : ℝ) / 640) ((357 : ℝ) / 160))
    (hA : RB A ((1407 : ℝ) / 2047) ((357 : ℝ) / 517))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((4095677 : ℝ) / 10000000) ((326121 : ℝ) / 781250))
    (hm : RB vm ((134185007 : ℝ) / 100000000) ((134766313 : ℝ) / 100000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((34343533 : ℝ) / 50000000) ((69004339 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((10383 : ℝ) / 6250000) ((169323 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99830677 : ℝ) / 100000000) ((6239617 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((455129 : ℝ) / 781250) ((5904323 : ℝ) / 10000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((5815787 : ℝ) / 10000000) ((58945143 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((1165271 : ℝ) / 1000000) ((59325023 : ℝ) / 50000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((165271 : ℝ) / 1000000) ((9325023 : ℝ) / 50000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((34343533 : ℝ) / 50000000) ((69004339 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((51457 : ℝ) / 100000000) ((25841 : ℝ) / 50000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((49974159 : ℝ) / 50000000) ((99948543 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((34185007 : ℝ) / 100000000) ((34766313 : ℝ) / 100000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((34167339 : ℝ) / 100000000) ((4343553 : ℝ) / 12500000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((98834793 : ℝ) / 50000000) ((40391989 : ℝ) / 20000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((148834793 : ℝ) / 50000000) ((60391989 : ℝ) / 20000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((268095853 : ℝ) / 50000000) ((60506683 : ℝ) / 10000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((1324679 : ℝ) / 4000000) ((4199287 : ℝ) / 12500000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((1407 : ℝ) / 320) ((357 : ℝ) / 80) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((11578743 : ℝ) / 100000000) ((5875783 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((11281651 : ℝ) / 100000000) ((11450041 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((111281651 : ℝ) / 100000000) ((111450041 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((92441519 : ℝ) / 100000000) ((93809543 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((87758583 : ℝ) / 50000000) ((35622923 : ℝ) / 20000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13739461 : ℝ) / 25000000) ((351601 : ℝ) / 625000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((123271 : ℝ) / 100000000) ((63093 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49936907 : ℝ) / 50000000) ((99876729 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((175295687 : ℝ) / 100000000) ((44473763 : ℝ) / 25000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((2047 : ℝ) / 640) ((517 : ℝ) / 160) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((386847 : ℝ) / 12500000) ((3126527 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((788567 : ℝ) / 12500000) ((6429717 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((13288567 : ℝ) / 12500000) ((106429717 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((35626097 : ℝ) / 6250000) ((128794183 : ℝ) / 20000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1954051 : ℝ) / 100000000) ((981259 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101954051 : ℝ) / 100000000) ((50981259 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33764097 : ℝ) / 100000000) ((34253591 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((603781649 : ℝ) / 100000000) ((339112253 : ℝ) / 50000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((18685689 : ℝ) / 100000000) ((21204873 : ℝ) / 100000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((2047 : ℝ) / 640) ((517 : ℝ) / 160) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((111281651 : ℝ) / 50000000) ((111450041 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((569308681 : ℝ) / 100000000) ((319330563 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1267072199 : ℝ) / 100000000) ((711788087 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((2808453 : ℝ) / 12500000) ((3187713 : ℝ) / 12500000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-149309487 : ℝ) / 100000000) ((-136642491 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1894.1 cov_log_1895.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((140955157 : ℝ) / 100000000) ((5722359 : ℝ) / 4000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-31723623 : ℝ) / 20000000) ((-19564279 : ℝ) / 12500000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((1109599 : ℝ) / 20000000) ((8147361 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((26163773 : ℝ) / 100000000) ((1362567 : ℝ) / 3125000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-66227171 : ℝ) / 50000000) ((-14114011 : ℝ) / 12500000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((111281651 : ℝ) / 100000000) ((111450041 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-149309487 : ℝ) / 100000000) ((-136642491 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-66227171 : ℝ) / 50000000) ((-14114011 : ℝ) / 12500000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((283 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((788567 : ℝ) / 12500000) ((6429717 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((106429717 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((283 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-14467391 : ℝ) / 12500000) ≤ formC0 k A q vp vm + hfun ((283 : ℝ) / 100) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_37, cov_h_24]
  have hP : ((318271147 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((14114011 : ℝ) / 12500000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((14114011 : ℝ) / 12500000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((343 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((343 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((348 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((348 : ℝ) / 125)) (lo := ((343 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((353 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((353 : ℝ) / 125)) (lo := ((348 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((283 : ℝ) / 100)) (lo := ((353 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_105 {k : ℝ} (hk : RB k ((1407 : ℝ) / 640) ((357 : ℝ) / 160)) :
    RB (k / (k + 1)) ((1407 : ℝ) / 2047) ((357 : ℝ) / 517) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((1407 : ℝ) / 2047) ((357 : ℝ) / 517) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_105 {k : ℝ} (hk : RB k ((1407 : ℝ) / 640) ((357 : ℝ) / 160)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_105 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_105 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((4095677 : ℝ) / 10000000)) (ph := ((326121 : ℝ) / 781250)) (ml := ((134185007 : ℝ) / 100000000)) (mh := ((134766313 : ℝ) / 100000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_105 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_106 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((357 : ℝ) / 517) ((147 : ℝ) / 211))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((41028697 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((42386351 : ℝ) / 100000000) ∧ 0 < certE k a ((67098553 : ℝ) / 50000000) ∧ certE k a ((67661711 : ℝ) / 50000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((41028697 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((10239837 : ℝ) / 25000000) ((40959349 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((41028697 : ℝ) / 100000000) ((41028697 : ℝ) / 100000000) ((41028697 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((58971303 : ℝ) / 100000000))
  have h3 : RB z3 ((34728203 : ℝ) / 50000000) ((69456409 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((58971303 : ℝ) / 100000000) ((58971303 : ℝ) / 100000000) ((58971303 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-36447089 : ℝ) / 100000000) ((-36447083 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1896.1 cov_log_1897.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-1587003 : ℝ) / 6250000) ((-25167521 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((41028697 : ℝ) / 100000000))
  have h6 : RB z6 ((-17817969 : ℝ) / 20000000) ((-89089843 : ℝ) / 100000000) := rb_log (show RB ((41028697 : ℝ) / 100000000) ((41028697 : ℝ) / 100000000) ((41028697 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1898.1 cov_log_1898.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((12739559 : ℝ) / 20000000) ((15980581 : ℝ) / 25000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-13071 : ℝ) / 3125000) ((-193739 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42386351 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((21158501 : ℝ) / 50000000) ((42317003 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((42386351 : ℝ) / 100000000) ((42386351 : ℝ) / 100000000) ((42386351 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57613649 : ℝ) / 100000000))
  have h12 : RB z12 ((18362403 : ℝ) / 25000000) ((14689923 : ℝ) / 20000000) := rb_div_signed h11 (show RB ((57613649 : ℝ) / 100000000) ((57613649 : ℝ) / 100000000) ((57613649 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-30857057 : ℝ) / 100000000) ((-7714263 : ℝ) / 25000000) := rb_log h12 (by norm_num) cov_log_1899.1 cov_log_1900.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-21497571 : ℝ) / 100000000) ((-532687 : ℝ) / 2500000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42386351 : ℝ) / 100000000))
  have h15 : RB z15 ((-4291719 : ℝ) / 5000000) ((-42917189 : ℝ) / 50000000) := rb_log (show RB ((42386351 : ℝ) / 100000000) ((42386351 : ℝ) / 100000000) ((42386351 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1901.1 cov_log_1901.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((64336807 : ℝ) / 100000000) ((645269 : ℝ) / 1000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((11037 : ℝ) / 5000000) ((410837 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((67098553 : ℝ) / 50000000)) - (z19)
  have h20 : RB z20 ((134127757 : ℝ) / 100000000) ((67063879 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((67098553 : ℝ) / 50000000) ((67098553 : ℝ) / 50000000) ((67098553 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((17098553 : ℝ) / 50000000))
  have h21 : RB z21 ((392219613 : ℝ) / 100000000) ((392219617 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((17098553 : ℝ) / 50000000) ((17098553 : ℝ) / 50000000) ((17098553 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((136665173 : ℝ) / 100000000) ((136665177 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1902.1 cov_log_1903.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((94370341 : ℝ) / 100000000) ((95212233 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((67098553 : ℝ) / 50000000))
  have h24 : RB z24 ((29413947 : ℝ) / 100000000) ((29413949 : ℝ) / 100000000) := rb_log (show RB ((67098553 : ℝ) / 50000000) ((67098553 : ℝ) / 50000000) ((67098553 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1904.1 cov_log_1904.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((8119549 : ℝ) / 12500000) ((32899143 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((33613 : ℝ) / 4000000) ((1682223 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((67661711 : ℝ) / 50000000)) - (z28)
  have h29 : RB z29 ((135254073 : ℝ) / 100000000) ((67627037 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((67661711 : ℝ) / 50000000) ((67661711 : ℝ) / 50000000) ((67661711 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((17661711 : ℝ) / 50000000))
  have h30 : RB z30 ((382901953 : ℝ) / 100000000) ((382901957 : ℝ) / 100000000) := rb_div_signed h29 (show RB ((17661711 : ℝ) / 50000000) ((17661711 : ℝ) / 50000000) ((17661711 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((134260877 : ℝ) / 100000000) ((134260881 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1905.1 cov_log_1906.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46355061 : ℝ) / 50000000) ((46768601 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((67661711 : ℝ) / 50000000))
  have h33 : RB z33 ((1890609 : ℝ) / 6250000) ((15124873 : ℝ) / 50000000) := rb_log (show RB ((67661711 : ℝ) / 50000000) ((67661711 : ℝ) / 50000000) ((67661711 : ℝ) / 50000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1907.1 cov_log_1907.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((7807547 : ℝ) / 12500000) ((31643729 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-1655691 : ℝ) / 100000000) ((-165721 : ℝ) / 20000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((41028697 : ℝ) / 100000000)) ((-13071 : ℝ) / 3125000) ((-193739 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42386351 : ℝ) / 100000000)) ((11037 : ℝ) / 5000000) ((410837 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((67098553 : ℝ) / 50000000)) ((33613 : ℝ) / 4000000) ((1682223 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((67661711 : ℝ) / 50000000)) ((-1655691 : ℝ) / 100000000) ((-165721 : ℝ) / 20000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_106 {k A q d vp vm : ℝ}
    (hk : RB k ((357 : ℝ) / 160) ((147 : ℝ) / 64))
    (hA : RB A ((357 : ℝ) / 517) ((147 : ℝ) / 211))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((41028697 : ℝ) / 100000000) ((42386351 : ℝ) / 100000000))
    (hm : RB vm ((67098553 : ℝ) / 50000000) ((67661711 : ℝ) / 50000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((69004337 : ℝ) / 100000000) ((69619933 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((163609 : ℝ) / 100000000) ((84513 : ℝ) / 50000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((49915487 : ℝ) / 50000000) ((99836391 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57613649 : ℝ) / 100000000) ((58971303 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((28758133 : ℝ) / 50000000) ((58874821 : ℝ) / 100000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((4688207 : ℝ) / 4000000) ((121043903 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((688207 : ℝ) / 4000000) ((21043903 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((69004337 : ℝ) / 100000000) ((69619933 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((25623 : ℝ) / 50000000) ((51677 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99948323 : ℝ) / 100000000) ((49974377 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((17098553 : ℝ) / 50000000) ((17661711 : ℝ) / 50000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((34179433 : ℝ) / 100000000) ((35305321 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((97725123 : ℝ) / 50000000) ((4073791 : ℝ) / 2000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((147725123 : ℝ) / 50000000) ((6073791 : ℝ) / 2000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((23759851 : ℝ) / 5000000) ((145305119 : ℝ) / 25000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((32928363 : ℝ) / 100000000) ((33846647 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((357 : ℝ) / 80) ((147 : ℝ) / 32) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((293789 : ℝ) / 2500000) ((30243 : ℝ) / 250000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((5725017 : ℝ) / 50000000) ((5893403 : ℝ) / 50000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((55725017 : ℝ) / 50000000) ((55893403 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((18362151 : ℝ) / 20000000) ((3771789 : ℝ) / 4000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((34863909 : ℝ) / 20000000) ((89517911 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((13764831 : ℝ) / 25000000) ((57358661 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((60451 : ℝ) / 50000000) ((62977 : ℝ) / 50000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((49937023 : ℝ) / 50000000) ((49939549 : ℝ) / 50000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((87049991 : ℝ) / 50000000) ((35763873 : ℝ) / 20000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((517 : ℝ) / 160) ((211 : ℝ) / 64) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((1516587 : ℝ) / 50000000) ((1547389 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((776607 : ℝ) / 12500000) ((1283689 : ℝ) / 20000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((13276607 : ℝ) / 12500000) ((21283689 : ℝ) / 20000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((252360163 : ℝ) / 50000000) ((618525793 : ℝ) / 100000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((973003 : ℝ) / 50000000) ((1962341 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((50973003 : ℝ) / 50000000) ((101962341 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((671383 : ℝ) / 2000000) ((17255417 : ℝ) / 50000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((134572369 : ℝ) / 25000000) ((653036627 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((2040907 : ℝ) / 12500000) ((10105017 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((517 : ℝ) / 160) ((211 : ℝ) / 64) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((55725017 : ℝ) / 25000000) ((55893403 : ℝ) / 25000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((508125383 : ℝ) / 100000000) ((615067123 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((70788239 : ℝ) / 6250000) ((171890973 : ℝ) / 12500000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((2937227 : ℝ) / 12500000) ((5821721 : ℝ) / 20000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-144826273 : ℝ) / 100000000) ((-61706817 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1908.1 cov_log_1909.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((28611793 : ℝ) / 20000000) ((4602081 : ℝ) / 3125000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-156514307 : ℝ) / 100000000) ((-30461323 : ℝ) / 20000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((2311841 : ℝ) / 50000000) ((4671533 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((457563 : ℝ) / 2000000) ((57223737 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-133636157 : ℝ) / 100000000) ((-47541439 : ℝ) / 50000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((55725017 : ℝ) / 50000000) ((55893403 : ℝ) / 50000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-144826273 : ℝ) / 100000000) ((-61706817 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-133636157 : ℝ) / 100000000) ((-47541439 : ℝ) / 50000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((141 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((776607 : ℝ) / 12500000) ((1283689 : ℝ) / 20000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((21283689 : ℝ) / 40000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((141 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-444141 : ℝ) / 400000) ≤ formC0 k A q vp vm + hfun ((141 : ℝ) / 50) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_38, cov_h_24]
  have hP : ((267207617 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((47541439 : ℝ) / 50000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((47541439 : ℝ) / 50000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2401 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2401 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2441 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2441 : ℝ) / 1000)) (lo := ((2401 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2481 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2481 : ℝ) / 1000)) (lo := ((2441 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2521 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2521 : ℝ) / 1000)) (lo := ((2481 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2561 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2561 : ℝ) / 1000)) (lo := ((2521 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2601 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2601 : ℝ) / 1000)) (lo := ((2561 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2641 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2641 : ℝ) / 1000)) (lo := ((2601 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2681 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2681 : ℝ) / 1000)) (lo := ((2641 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2721 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2721 : ℝ) / 1000)) (lo := ((2681 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2761 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2761 : ℝ) / 1000)) (lo := ((2721 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2801 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2801 : ℝ) / 1000)) (lo := ((2761 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((141 : ℝ) / 50)) (lo := ((2801 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_106 {k : ℝ} (hk : RB k ((357 : ℝ) / 160) ((147 : ℝ) / 64)) :
    RB (k / (k + 1)) ((357 : ℝ) / 517) ((147 : ℝ) / 211) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((357 : ℝ) / 517) ((147 : ℝ) / 211) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_106 {k : ℝ} (hk : RB k ((357 : ℝ) / 160) ((147 : ℝ) / 64)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_106 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_106 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((41028697 : ℝ) / 100000000)) (ph := ((42386351 : ℝ) / 100000000)) (ml := ((67098553 : ℝ) / 50000000)) (mh := ((67661711 : ℝ) / 50000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_106 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_107 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((147 : ℝ) / 211) ((189 : ℝ) / 269))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((10388647 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((42692221 : ℝ) / 100000000) ∧ 0 < certE k a ((33646963 : ℝ) / 25000000) ∧ certE k a ((33917061 : ℝ) / 25000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((10388647 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((41485239 : ℝ) / 100000000) ((1037131 : ℝ) / 2500000) := rb_widen (rb_sub (show RB ((10388647 : ℝ) / 25000000) ((10388647 : ℝ) / 25000000) ((10388647 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((14611353 : ℝ) / 25000000))
  have h3 : RB z3 ((17745293 : ℝ) / 25000000) ((2839247 : ℝ) / 4000000) := rb_div_signed h2 (show RB ((14611353 : ℝ) / 25000000) ((14611353 : ℝ) / 25000000) ((14611353 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-34275553 : ℝ) / 100000000) ((-8568887 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_1910.1 cov_log_1911.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-150513 : ℝ) / 625000) ((-23879173 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((10388647 : ℝ) / 25000000))
  have h6 : RB z6 ((-43908113 : ℝ) / 50000000) ((-2744257 : ℝ) / 3125000) := rb_log (show RB ((10388647 : ℝ) / 25000000) ((10388647 : ℝ) / 25000000) ((10388647 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1912.1 cov_log_1912.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((497923 : ℝ) / 781250) ((63937053 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-381923 : ℝ) / 100000000) ((-17901 : ℝ) / 10000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42692221 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((5327859 : ℝ) / 12500000) ((42622873 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((42692221 : ℝ) / 100000000) ((42692221 : ℝ) / 100000000) ((42692221 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57307779 : ℝ) / 100000000))
  have h12 : RB z12 ((9296921 : ℝ) / 12500000) ((74375371 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((57307779 : ℝ) / 100000000) ((57307779 : ℝ) / 100000000) ((57307779 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-14802269 : ℝ) / 50000000) ((-29604533 : ℝ) / 100000000) := rb_log h12 (by norm_num) cov_log_1913.1 cov_log_1914.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-4160043 : ℝ) / 20000000) ((-20624959 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42692221 : ℝ) / 100000000))
  have h15 : RB z15 ((-85115347 : ℝ) / 100000000) ((-17023069 : ℝ) / 20000000) := rb_log (show RB ((42692221 : ℝ) / 100000000) ((42692221 : ℝ) / 100000000) ((42692221 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1915.1 cov_log_1915.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((6431513 : ℝ) / 10000000) ((16122597 : ℝ) / 25000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((199063 : ℝ) / 100000000) ((14973 : ℝ) / 4000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((33646963 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((134518503 : ℝ) / 100000000) ((16814813 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((33646963 : ℝ) / 25000000) ((33646963 : ℝ) / 25000000) ((33646963 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((8646963 : ℝ) / 25000000))
  have h21 : RB z21 ((388918349 : ℝ) / 100000000) ((388918353 : ℝ) / 100000000) := rb_div_signed h20 (show RB ((8646963 : ℝ) / 25000000) ((8646963 : ℝ) / 25000000) ((8646963 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((135819923 : ℝ) / 100000000) ((135819927 : ℝ) / 100000000) := rb_log h21 (by norm_num) cov_log_1916.1 cov_log_1917.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((47311679 : ℝ) / 50000000) ((11928423 : ℝ) / 12500000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((33646963 : ℝ) / 25000000))
  have h24 : RB z24 ((29704697 : ℝ) / 100000000) ((29704699 : ℝ) / 100000000) := rb_log (show RB ((33646963 : ℝ) / 25000000) ((33646963 : ℝ) / 25000000) ((33646963 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1918.1 cov_log_1918.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((64918659 : ℝ) / 100000000) ((65722687 : ℝ) / 100000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((25081 : ℝ) / 3125000) ((50207 : ℝ) / 3125000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((33917061 : ℝ) / 25000000)) - (z28)
  have h29 : RB z29 ((27119779 : ℝ) / 20000000) ((8474931 : ℝ) / 6250000) := rb_widen (rb_sub (show RB ((33917061 : ℝ) / 25000000) ((33917061 : ℝ) / 25000000) ((33917061 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((8917061 : ℝ) / 25000000))
  have h30 : RB z30 ((76033401 : ℝ) / 20000000) ((11880219 : ℝ) / 3125000) := rb_div_signed h29 (show RB ((8917061 : ℝ) / 25000000) ((8917061 : ℝ) / 25000000) ((8917061 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((26708809 : ℝ) / 20000000) ((133544049 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1919.1 cov_log_1920.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((46518897 : ℝ) / 50000000) ((93828347 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((33917061 : ℝ) / 25000000))
  have h33 : RB z33 ((30504233 : ℝ) / 100000000) ((6100847 : ℝ) / 20000000) := rb_log (show RB ((33917061 : ℝ) / 25000000) ((33917061 : ℝ) / 25000000) ((33917061 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1921.1 cov_log_1921.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((62533559 : ℝ) / 100000000) ((31662057 : ℝ) / 50000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-395627 : ℝ) / 25000000) ((-791949 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((10388647 : ℝ) / 25000000)) ((-381923 : ℝ) / 100000000) ((-17901 : ℝ) / 10000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42692221 : ℝ) / 100000000)) ((199063 : ℝ) / 100000000) ((14973 : ℝ) / 4000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((33646963 : ℝ) / 25000000)) ((25081 : ℝ) / 3125000) ((50207 : ℝ) / 3125000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((33917061 : ℝ) / 25000000)) ((-395627 : ℝ) / 25000000) ((-791949 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_107 {k A q d vp vm : ℝ}
    (hk : RB k ((147 : ℝ) / 64) ((189 : ℝ) / 80))
    (hA : RB A ((147 : ℝ) / 211) ((189 : ℝ) / 269))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((10388647 : ℝ) / 25000000) ((42692221 : ℝ) / 100000000))
    (hm : RB vm ((33646963 : ℝ) / 25000000) ((33917061 : ℝ) / 25000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((17404983 : ℝ) / 25000000) ((70211499 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((162437 : ℝ) / 100000000) ((166887 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99833113 : ℝ) / 100000000) ((99837563 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57307779 : ℝ) / 100000000) ((14611353 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((57212139 : ℝ) / 100000000) ((14587619 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((119313391 : ℝ) / 100000000) ((30680333 : ℝ) / 25000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((19313391 : ℝ) / 100000000) ((5680333 : ℝ) / 25000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((17404983 : ℝ) / 25000000) ((70211499 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((10223 : ℝ) / 20000000) ((51527 : ℝ) / 100000000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((99948473 : ℝ) / 100000000) ((19989777 : ℝ) / 20000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((8646963 : ℝ) / 25000000) ((8917061 : ℝ) / 25000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((34570029 : ℝ) / 100000000) ((35650013 : ℝ) / 100000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((39057451 : ℝ) / 20000000) ((40619867 : ℝ) / 20000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((59057451 : ℝ) / 20000000) ((60619867 : ℝ) / 20000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((220057521 : ℝ) / 50000000) ((103555093 : ℝ) / 20000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((8248121 : ℝ) / 25000000) ((33865329 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((147 : ℝ) / 32) ((189 : ℝ) / 40) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((2419439 : ℝ) / 20000000) ((6221417 : ℝ) / 50000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((29467 : ℝ) / 250000) ((3030893 : ℝ) / 25000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((279467 : ℝ) / 250000) ((28030893 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((91895631 : ℝ) / 100000000) ((11764207 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((87240349 : ℝ) / 50000000) ((178692029 : ℝ) / 100000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((55927427 : ℝ) / 100000000) ((57919787 : ℝ) / 100000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((119731 : ℝ) / 100000000) ((123999 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99876001 : ℝ) / 100000000) ((99880269 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((174264343 : ℝ) / 100000000) ((139436 : ℝ) / 78125) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((211 : ℝ) / 64) ((269 : ℝ) / 80) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((371747 : ℝ) / 12500000) ((379147 : ℝ) / 12500000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((6168343 : ℝ) / 100000000) ((6337217 : ℝ) / 100000000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((106168343 : ℝ) / 100000000) ((106337217 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((467262847 : ℝ) / 100000000) ((27529401 : ℝ) / 5000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((97053 : ℝ) / 5000000) ((489161 : ℝ) / 25000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((5097053 : ℝ) / 5000000) ((25489161 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33632887 : ℝ) / 100000000) ((34527953 : ℝ) / 100000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((250447867 : ℝ) / 50000000) ((585115973 : ℝ) / 100000000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((7448259 : ℝ) / 50000000) ((8873799 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((211 : ℝ) / 64) ((269 : ℝ) / 80) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((279467 : ℝ) / 125000) ((28030893 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((236553763 : ℝ) / 50000000) ((275820397 : ℝ) / 50000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((1057743527 : ℝ) / 100000000) ((618519363 : ℝ) / 50000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((6662837 : ℝ) / 25000000) ((3178937 : ℝ) / 10000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-16529131 : ℝ) / 12500000) ((-57301911 : ℝ) / 50000000) := rb_log h47 (by norm_num) cov_log_1922.1 cov_log_1923.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((73633291 : ℝ) / 50000000) ((151474209 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-15230669 : ℝ) / 10000000) ((-74049499 : ℝ) / 50000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((4964967 : ℝ) / 100000000) ((1835741 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((2797543 : ℝ) / 10000000) ((61616447 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-6216563 : ℝ) / 5000000) ((-86482551 : ℝ) / 100000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((279467 : ℝ) / 250000) ((28030893 : ℝ) / 25000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-16529131 : ℝ) / 12500000) ((-57301911 : ℝ) / 50000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-6216563 : ℝ) / 5000000) ((-86482551 : ℝ) / 100000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((141 : ℝ) / 50) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((6168343 : ℝ) / 100000000) ((6337217 : ℝ) / 100000000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((42 : ℝ) / 25) := by
    have hu : (1 + q / vp) / 2 ≤ ((106337217 : ℝ) / 200000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((141 : ℝ) / 50) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((42 : ℝ) / 25) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-3937681 : ℝ) / 4000000) ≤ formC0 k A q vp vm + hfun ((141 : ℝ) / 50) + hfun ((42 : ℝ) / 25) := by
    linarith [hc0.1, cov_h_38, cov_h_24]
  have hP : ((242308489 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((86482551 : ℝ) / 100000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((86482551 : ℝ) / 100000000))
    linarith [hap.2]
  have hS : ((7396073 : ℝ) / 12500000) ≤ EP1038.Arc.sinc ((42 : ℝ) / 25) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((437 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((307 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((307 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((312 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((312 : ℝ) / 125)) (lo := ((307 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((317 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((317 : ℝ) / 125)) (lo := ((312 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((322 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((322 : ℝ) / 125)) (lo := ((317 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((327 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((327 : ℝ) / 125)) (lo := ((322 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((332 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((332 : ℝ) / 125)) (lo := ((327 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((337 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((337 : ℝ) / 125)) (lo := ((332 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((342 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((342 : ℝ) / 125)) (lo := ((337 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((347 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((347 : ℝ) / 125)) (lo := ((342 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((352 : ℝ) / 125) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((352 : ℝ) / 125)) (lo := ((347 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((141 : ℝ) / 50)) (lo := ((352 : ℝ) / 125)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_107 {k : ℝ} (hk : RB k ((147 : ℝ) / 64) ((189 : ℝ) / 80)) :
    RB (k / (k + 1)) ((147 : ℝ) / 211) ((189 : ℝ) / 269) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((147 : ℝ) / 211) ((189 : ℝ) / 269) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_107 {k : ℝ} (hk : RB k ((147 : ℝ) / 64) ((189 : ℝ) / 80)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_107 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_107 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((10388647 : ℝ) / 25000000)) (ph := ((42692221 : ℝ) / 100000000)) (ml := ((33646963 : ℝ) / 25000000)) (mh := ((33917061 : ℝ) / 25000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_107 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_108 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((189 : ℝ) / 269) ((777 : ℝ) / 1097))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((10497217 : ℝ) / 25000000) < 0 ∧ 0 < certE k a ((42961293 : ℝ) / 100000000) ∧ 0 < certE k a ((33740593 : ℝ) / 25000000) ∧ certE k a ((33999899 : ℝ) / 25000000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((10497217 : ℝ) / 25000000)) - (z1)
  have h2 : RB z2 ((41919519 : ℝ) / 100000000) ((261997 : ℝ) / 625000) := rb_widen (rb_sub (show RB ((10497217 : ℝ) / 25000000) ((10497217 : ℝ) / 25000000) ((10497217 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((14502783 : ℝ) / 25000000))
  have h3 : RB z3 ((72261163 : ℝ) / 100000000) ((36130583 : ℝ) / 50000000) := rb_div_signed h2 (show RB ((14502783 : ℝ) / 25000000) ((14502783 : ℝ) / 25000000) ((14502783 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-32488337 : ℝ) / 100000000) ((-8122083 : ℝ) / 25000000) := rb_log h3 (by norm_num) cov_log_1924.1 cov_log_1925.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-23011339 : ℝ) / 100000000) ((-11413187 : ℝ) / 50000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((10497217 : ℝ) / 25000000))
  have h6 : RB z6 ((-43388283 : ℝ) / 50000000) ((-21694141 : ℝ) / 25000000) := rb_log (show RB ((10497217 : ℝ) / 25000000) ((10497217 : ℝ) / 25000000) ((10497217 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1926.1 cov_log_1926.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((2550609 : ℝ) / 4000000) ((3996887 : ℝ) / 6250000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-175421 : ℝ) / 50000000) ((-165871 : ℝ) / 100000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((42961293 : ℝ) / 100000000)) - (z10)
  have h11 : RB z11 ((5361493 : ℝ) / 12500000) ((8578389 : ℝ) / 20000000) := rb_widen (rb_sub (show RB ((42961293 : ℝ) / 100000000) ((42961293 : ℝ) / 100000000) ((42961293 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((57038707 : ℝ) / 100000000))
  have h12 : RB z12 ((75197959 : ℝ) / 100000000) ((37598981 : ℝ) / 50000000) := rb_div_signed h11 (show RB ((57038707 : ℝ) / 100000000) ((57038707 : ℝ) / 100000000) ((57038707 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-2850461 : ℝ) / 10000000) ((-5700921 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_1927.1 cov_log_1928.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-20189683 : ℝ) / 100000000) ((-20027399 : ℝ) / 100000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((42961293 : ℝ) / 100000000))
  have h15 : RB z15 ((-16897413 : ℝ) / 20000000) ((-84487063 : ℝ) / 100000000) := rb_log (show RB ((42961293 : ℝ) / 100000000) ((42961293 : ℝ) / 100000000) ((42961293 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1929.1 cov_log_1929.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((3214869 : ℝ) / 5000000) ((32229833 : ℝ) / 50000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((181313 : ℝ) / 100000000) ((343603 : ℝ) / 100000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((33740593 : ℝ) / 25000000)) - (z19)
  have h20 : RB z20 ((134893023 : ℝ) / 100000000) ((4215407 : ℝ) / 3125000) := rb_widen (rb_sub (show RB ((33740593 : ℝ) / 25000000) ((33740593 : ℝ) / 25000000) ((33740593 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((8740593 : ℝ) / 25000000))
  have h21 : RB z21 ((38582343 : ℝ) / 10000000) ((192911717 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((8740593 : ℝ) / 25000000) ((8740593 : ℝ) / 25000000) ((8740593 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((33755241 : ℝ) / 25000000) ((16877621 : ℝ) / 12500000) := rb_log h21 (by norm_num) cov_log_1930.1 cov_log_1931.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((9486603 : ℝ) / 10000000) ((23908681 : ℝ) / 25000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((33740593 : ℝ) / 25000000))
  have h24 : RB z24 ((14991291 : ℝ) / 50000000) ((3747823 : ℝ) / 12500000) := rb_log (show RB ((33740593 : ℝ) / 25000000) ((33740593 : ℝ) / 25000000) ((33740593 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1932.1 cov_log_1932.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((32441723 : ℝ) / 50000000) ((32826071 : ℝ) / 50000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((767379 : ℝ) / 100000000) ((1536079 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((33999899 : ℝ) / 25000000)) - (z28)
  have h29 : RB z29 ((135930247 : ℝ) / 100000000) ((16991281 : ℝ) / 12500000) := rb_widen (rb_sub (show RB ((33999899 : ℝ) / 25000000) ((33999899 : ℝ) / 25000000) ((33999899 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((8999899 : ℝ) / 25000000))
  have h30 : RB z30 ((11799633 : ℝ) / 3125000) ((18879413 : ℝ) / 5000000) := rb_div_signed h29 (show RB ((8999899 : ℝ) / 25000000) ((8999899 : ℝ) / 25000000) ((8999899 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((66431707 : ℝ) / 50000000) ((66431709 : ℝ) / 50000000) := rb_log h30 (by norm_num) cov_log_1933.1 cov_log_1934.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((93350131 : ℝ) / 100000000) ((47053271 : ℝ) / 50000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((33999899 : ℝ) / 25000000))
  have h33 : RB z33 ((7687043 : ℝ) / 25000000) ((15374087 : ℝ) / 50000000) := rb_log (show RB ((33999899 : ℝ) / 25000000) ((33999899 : ℝ) / 25000000) ((33999899 : ℝ) / 25000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1935.1 cov_log_1935.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((62601957 : ℝ) / 100000000) ((6335837 : ℝ) / 10000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-151411 : ℝ) / 10000000) ((-757693 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((10497217 : ℝ) / 25000000)) ((-175421 : ℝ) / 50000000) ((-165871 : ℝ) / 100000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((42961293 : ℝ) / 100000000)) ((181313 : ℝ) / 100000000) ((343603 : ℝ) / 100000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((33740593 : ℝ) / 25000000)) ((767379 : ℝ) / 100000000) ((1536079 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((33999899 : ℝ) / 25000000)) ((-151411 : ℝ) / 10000000) ((-757693 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_108 {k A q d vp vm : ℝ}
    (hk : RB k ((189 : ℝ) / 80) ((777 : ℝ) / 320))
    (hA : RB A ((189 : ℝ) / 269) ((777 : ℝ) / 1097))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((10497217 : ℝ) / 25000000) ((42961293 : ℝ) / 100000000))
    (hm : RB vm ((33740593 : ℝ) / 25000000) ((33999899 : ℝ) / 25000000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((35105749 : ℝ) / 50000000) ((70780417 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((161419 : ℝ) / 100000000) ((165161 : ℝ) / 100000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((99834839 : ℝ) / 100000000) ((99838581 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((57038707 : ℝ) / 100000000) ((14502783 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((56944501 : ℝ) / 100000000) ((14479373 : ℝ) / 25000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((60613379 : ℝ) / 50000000) ((24859439 : ℝ) / 20000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((10613379 : ℝ) / 50000000) ((4859439 : ℝ) / 20000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((35105749 : ℝ) / 50000000) ((70780417 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((50991 : ℝ) / 100000000) ((6423 : ℝ) / 12500000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((12493577 : ℝ) / 12500000) ((99949009 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((8740593 : ℝ) / 25000000) ((8999899 : ℝ) / 25000000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((17472203 : ℝ) / 50000000) ((899531 : ℝ) / 2500000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((1561069 : ℝ) / 800000) ((25318937 : ℝ) / 12500000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((2361069 : ℝ) / 800000) ((37818937 : ℝ) / 12500000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((205785071 : ℝ) / 50000000) ((471103501 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((516441 : ℝ) / 1562500) ((16941479 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((189 : ℝ) / 40) ((777 : ℝ) / 160) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((12442829 : ℝ) / 100000000) ((12788469 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((6061783 : ℝ) / 50000000) ((12460339 : ℝ) / 100000000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((56061783 : ℝ) / 50000000) ((112460339 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((92001079 : ℝ) / 100000000) ((11751341 : ℝ) / 12500000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((17468091 : ℝ) / 10000000) ((89248301 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((14167293 : ℝ) / 25000000) ((11685437 : ℝ) / 20000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((118691 : ℝ) / 100000000) ((15297 : ℝ) / 12500000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((12484703 : ℝ) / 12500000) ((99881309 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((87233571 : ℝ) / 50000000) ((178284743 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((269 : ℝ) / 80) ((1097 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((583409 : ℝ) / 20000000) ((1486989 : ℝ) / 50000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((612971 : ℝ) / 10000000) ((783959 : ℝ) / 12500000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((10612971 : ℝ) / 10000000) ((13283959 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((218399099 : ℝ) / 50000000) ((15645299 : ℝ) / 3125000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((1936331 : ℝ) / 100000000) ((975607 : ℝ) / 50000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((101936331 : ℝ) / 100000000) ((50975607 : ℝ) / 50000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((526441 : ℝ) / 1562500) ((4318011 : ℝ) / 12500000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((235245211 : ℝ) / 50000000) ((66899207 : ℝ) / 12500000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((13724417 : ℝ) / 100000000) ((7958271 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((269 : ℝ) / 80) ((1097 : ℝ) / 320) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((56061783 : ℝ) / 25000000) ((112460339 : ℝ) / 50000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((222311183 : ℝ) / 50000000) ((504986459 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((997052903 : ℝ) / 100000000) ((141977371 : ℝ) / 12500000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((29604189 : ℝ) / 100000000) ((34382579 : ℝ) / 100000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-60862717 : ℝ) / 50000000) ((-106762017 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1936.1 cov_log_1937.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((75737099 : ℝ) / 50000000) ((77840913 : ℝ) / 50000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-74049537 : ℝ) / 50000000) ((-143891381 : ℝ) / 100000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((161197 : ℝ) / 3125000) ((4487953 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((16204223 : ℝ) / 50000000) ((65401001 : ℝ) / 100000000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-28922657 : ℝ) / 25000000) ((-3924519 : ℝ) / 5000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((56061783 : ℝ) / 50000000) ((112460339 : ℝ) / 100000000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-60862717 : ℝ) / 50000000) ((-106762017 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-28922657 : ℝ) / 25000000) ((-3924519 : ℝ) / 5000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((281 : ℝ) / 100) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((612971 : ℝ) / 10000000) ((783959 : ℝ) / 12500000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((13283959 : ℝ) / 25000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((281 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-17522931 : ℝ) / 20000000) ≤ formC0 k A q vp vm + hfun ((281 : ℝ) / 100) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_39, cov_h_25]
  have hP : ((219257323 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((3924519 : ℝ) / 5000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((3924519 : ℝ) / 5000000))
    linarith [hap.2]
  have hS : ((1862041 : ℝ) / 3125000) ≤ EP1038.Arc.sinc ((167 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((397 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((2497 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2497 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((2537 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2537 : ℝ) / 1000)) (lo := ((2497 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2577 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2577 : ℝ) / 1000)) (lo := ((2537 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2617 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2617 : ℝ) / 1000)) (lo := ((2577 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2657 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2657 : ℝ) / 1000)) (lo := ((2617 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2697 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2697 : ℝ) / 1000)) (lo := ((2657 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2737 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2737 : ℝ) / 1000)) (lo := ((2697 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((2777 : ℝ) / 1000) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((2777 : ℝ) / 1000)) (lo := ((2737 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((281 : ℝ) / 100)) (lo := ((2777 : ℝ) / 1000)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_108 {k : ℝ} (hk : RB k ((189 : ℝ) / 80) ((777 : ℝ) / 320)) :
    RB (k / (k + 1)) ((189 : ℝ) / 269) ((777 : ℝ) / 1097) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((189 : ℝ) / 269) ((777 : ℝ) / 1097) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_108 {k : ℝ} (hk : RB k ((189 : ℝ) / 80) ((777 : ℝ) / 320)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_108 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_108 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((10497217 : ℝ) / 25000000)) (ph := ((42961293 : ℝ) / 100000000)) (ml := ((33740593 : ℝ) / 25000000)) (mh := ((33999899 : ℝ) / 25000000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_108 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩

theorem cov_signs_109 {k a : ℝ}
    (hA : RB (k / (k + 1)) ((777 : ℝ) / 1097) ((399 : ℝ) / 559))
    (hq : RB (qa a) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB (D0a a) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    : certE k a ((42355827 : ℝ) / 100000000) < 0 ∧ 0 < certE k a ((215999 : ℝ) / 500000) ∧ 0 < certE k a ((16915207 : ℝ) / 12500000) ∧ certE k a ((545273 : ℝ) / 400000) < 0 := by
  let z1 : ℝ := (qa a) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := (((42355827 : ℝ) / 100000000)) - (z1)
  have h2 : RB z2 ((21143239 : ℝ) / 50000000) ((42286479 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((42355827 : ℝ) / 100000000) ((42355827 : ℝ) / 100000000) ((42355827 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (z2) / (((57644173 : ℝ) / 100000000))
  have h3 : RB z3 ((36678883 : ℝ) / 50000000) ((73357769 : ℝ) / 100000000) := rb_div_signed h2 (show RB ((57644173 : ℝ) / 100000000) ((57644173 : ℝ) / 100000000) ((57644173 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z4 : ℝ := Real.log (z3)
  have h4 : RB z4 ((-15491091 : ℝ) / 50000000) ((-30982177 : ℝ) / 100000000) := rb_log h3 (by norm_num) cov_log_1938.1 cov_log_1939.2
  let z5 : ℝ := (z4) * (k / (k + 1))
  have h5 : RB z5 ((-4422859 : ℝ) / 20000000) ((-21944531 : ℝ) / 100000000) := rb_mul_signed h4 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z6 : ℝ := Real.log (((42355827 : ℝ) / 100000000))
  have h6 : RB z6 ((-4295321 : ℝ) / 5000000) ((-42953209 : ℝ) / 50000000) := rb_log (show RB ((42355827 : ℝ) / 100000000) ((42355827 : ℝ) / 100000000) ((42355827 : ℝ) / 100000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1940.1 cov_log_1940.2
  let z7 : ℝ := (z5) - (z6)
  have h7 : RB z7 ((63792123 : ℝ) / 100000000) ((63961889 : ℝ) / 100000000) := rb_widen (rb_sub h5 h6) (by norm_num) (by norm_num)
  let z8 : ℝ := Real.log (D0a a)
  have h8 : RB z8 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z9 : ℝ := (z7) - (z8)
  have h9 : RB z9 ((-40493 : ℝ) / 12500000) ((-77087 : ℝ) / 50000000) := rb_widen (rb_sub h7 h8) (by norm_num) (by norm_num)
  let z10 : ℝ := (qa a) ^ 2
  have h10 : RB z10 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z11 : ℝ := (((215999 : ℝ) / 500000)) - (z10)
  have h11 : RB z11 ((43130451 : ℝ) / 100000000) ((10782613 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((215999 : ℝ) / 500000) ((215999 : ℝ) / 500000) ((215999 : ℝ) / 500000) from ⟨le_rfl, le_rfl⟩) h10) (by norm_num) (by norm_num)
  let z12 : ℝ := (z11) / (((284001 : ℝ) / 500000))
  have h12 : RB z12 ((607469 : ℝ) / 800000) ((75933627 : ℝ) / 100000000) := rb_div_signed h11 (show RB ((284001 : ℝ) / 500000) ((284001 : ℝ) / 500000) ((284001 : ℝ) / 500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := Real.log (z12)
  have h13 : RB z13 ((-27531059 : ℝ) / 100000000) ((-5506211 : ℝ) / 20000000) := rb_log h12 (by norm_num) cov_log_1941.1 cov_log_1942.2
  let z14 : ℝ := (z13) * (k / (k + 1))
  have h14 : RB z14 ((-19650971 : ℝ) / 100000000) ((-9750059 : ℝ) / 50000000) := rb_mul_signed h13 hA (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z15 : ℝ := Real.log (((215999 : ℝ) / 500000))
  have h15 : RB z15 ((-83933433 : ℝ) / 100000000) ((-83933431 : ℝ) / 100000000) := rb_log (show RB ((215999 : ℝ) / 500000) ((215999 : ℝ) / 500000) ((215999 : ℝ) / 500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1943.1 cov_log_1943.2
  let z16 : ℝ := (z14) - (z15)
  have h16 : RB z16 ((3214123 : ℝ) / 5000000) ((12886663 : ℝ) / 20000000) := rb_widen (rb_sub h14 h15) (by norm_num) (by norm_num)
  let z17 : ℝ := Real.log (D0a a)
  have h17 : RB z17 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z18 : ℝ := (z16) - (z17)
  have h18 : RB z18 ((166393 : ℝ) / 100000000) ((79313 : ℝ) / 25000000) := rb_widen (rb_sub h16 h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (qa a) ^ 2
  have h19 : RB z19 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z20 : ℝ := (((16915207 : ℝ) / 12500000)) - (z19)
  have h20 : RB z20 ((135252307 : ℝ) / 100000000) ((33813077 : ℝ) / 25000000) := rb_widen (rb_sub (show RB ((16915207 : ℝ) / 12500000) ((16915207 : ℝ) / 12500000) ((16915207 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) h19) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) / (((4415207 : ℝ) / 12500000))
  have h21 : RB z21 ((191458049 : ℝ) / 50000000) ((191458051 : ℝ) / 50000000) := rb_div_signed h20 (show RB ((4415207 : ℝ) / 12500000) ((4415207 : ℝ) / 12500000) ((4415207 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (z21)
  have h22 : RB z22 ((134264571 : ℝ) / 100000000) ((5370583 : ℝ) / 4000000) := rb_log h21 (by norm_num) cov_log_1944.1 cov_log_1945.2
  let z23 : ℝ := (k / (k + 1)) * (z22)
  have h23 : RB z23 ((95098971 : ℝ) / 100000000) ((95834643 : ℝ) / 100000000) := rb_widen (rb_mul hA h22 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z24 : ℝ := Real.log (((16915207 : ℝ) / 12500000))
  have h24 : RB z24 ((30248439 : ℝ) / 100000000) ((30248441 : ℝ) / 100000000) := rb_log (show RB ((16915207 : ℝ) / 12500000) ((16915207 : ℝ) / 12500000) ((16915207 : ℝ) / 12500000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1946.1 cov_log_1946.2
  let z25 : ℝ := (z23) - (z24)
  have h25 : RB z25 ((6485053 : ℝ) / 10000000) ((16396551 : ℝ) / 25000000) := rb_widen (rb_sub h23 h24) (by norm_num) (by norm_num)
  let z26 : ℝ := Real.log (D0a a)
  have h26 : RB z26 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z27 : ℝ := (z25) - (z26)
  have h27 : RB z27 ((734463 : ℝ) / 100000000) ((1470141 : ℝ) / 100000000) := rb_widen (rb_sub h25 h26) (by norm_num) (by norm_num)
  let z28 : ℝ := (qa a) ^ 2
  have h28 : RB z28 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (((545273 : ℝ) / 400000)) - (z28)
  have h29 : RB z29 ((136248901 : ℝ) / 100000000) ((68124451 : ℝ) / 50000000) := rb_widen (rb_sub (show RB ((545273 : ℝ) / 400000) ((545273 : ℝ) / 400000) ((545273 : ℝ) / 400000) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((145273 : ℝ) / 400000))
  have h30 : RB z30 ((75030543 : ℝ) / 20000000) ((187576359 : ℝ) / 50000000) := rb_div_signed h29 (show RB ((145273 : ℝ) / 400000) ((145273 : ℝ) / 400000) ((145273 : ℝ) / 400000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := Real.log (z30)
  have h31 : RB z31 ((132216299 : ℝ) / 100000000) ((132216303 : ℝ) / 100000000) := rb_log h30 (by norm_num) cov_log_1947.1 cov_log_1948.2
  let z32 : ℝ := (k / (k + 1)) * (z31)
  have h32 : RB z32 ((93648189 : ℝ) / 100000000) ((94372639 : ℝ) / 100000000) := rb_widen (rb_mul hA h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := Real.log (((545273 : ℝ) / 400000))
  have h33 : RB z33 ((30982203 : ℝ) / 100000000) ((6196441 : ℝ) / 20000000) := rb_log (show RB ((545273 : ℝ) / 400000) ((545273 : ℝ) / 400000) ((545273 : ℝ) / 400000) from ⟨le_rfl, le_rfl⟩) (by norm_num) cov_log_1949.1 cov_log_1949.2
  let z34 : ℝ := (z32) - (z33)
  have h34 : RB z34 ((244789 : ℝ) / 390625) ((15847609 : ℝ) / 25000000) := rb_widen (rb_sub h32 h33) (by norm_num) (by norm_num)
  let z35 : ℝ := Real.log (D0a a)
  have h35 : RB z35 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z36 : ℝ := (z34) - (z35)
  have h36 : RB z36 ((-1450083 : ℝ) / 100000000) ((-725627 : ℝ) / 100000000) := rb_widen (rb_sub h34 h35) (by norm_num) (by norm_num)
  have e0 : RB (certE k a ((42355827 : ℝ) / 100000000)) ((-40493 : ℝ) / 12500000) ((-77087 : ℝ) / 50000000) := by
    have hh := h9
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e1 : RB (certE k a ((215999 : ℝ) / 500000)) ((166393 : ℝ) / 100000000) ((79313 : ℝ) / 25000000) := by
    have hh := h18
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e2 : RB (certE k a ((16915207 : ℝ) / 12500000)) ((734463 : ℝ) / 100000000) ((1470141 : ℝ) / 100000000) := by
    have hh := h27
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  have e3 : RB (certE k a ((545273 : ℝ) / 400000)) ((-1450083 : ℝ) / 100000000) ((-725627 : ℝ) / 100000000) := by
    have hh := h36
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, certE] <;> norm_num <;> ring
  refine ⟨?_, ?_, ?_, ?_⟩ <;> linarith [e0.1, e0.2, e1.1, e1.2, e2.1, e2.2, e3.1, e3.2]
theorem cov_numeric_109 {k A q d vp vm : ℝ}
    (hk : RB k ((777 : ℝ) / 320) ((399 : ℝ) / 160))
    (hA : RB A ((777 : ℝ) / 1097) ((399 : ℝ) / 559))
    (hq : RB q ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000))
    (hd : RB d ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000))
    (hp : RB vp ((42355827 : ℝ) / 100000000) ((215999 : ℝ) / 500000))
    (hm : RB vm ((16915207 : ℝ) / 12500000) ((545273 : ℝ) / 400000))
    : FormulaPositive k A q d vp vm ((4586076189407 : ℝ) / 2500000000000) := by
  let z1 : ℝ := (q) ^ 2
  have h1 : RB z1 ((17337 : ℝ) / 25000000) ((69349 : ℝ) / 100000000) := rb_widen (rb_sq hq (by norm_num)) (by norm_num) (by norm_num)
  let z2 : ℝ := ((1 : ℝ)) - (z1)
  have h2 : RB z2 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z3 : ℝ := (A) * (z2)
  have h3 : RB z3 ((14156083 : ℝ) / 20000000) ((71327961 : ℝ) / 100000000) := rb_widen (rb_mul hA h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (z1) / (vp)
  have h4 : RB z4 ((10033 : ℝ) / 6250000) ((16373 : ℝ) / 10000000) := rb_div_signed h1 hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := ((1 : ℝ)) - (z4)
  have h5 : RB z5 ((9983627 : ℝ) / 10000000) ((6239967 : ℝ) / 6250000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h4) (by norm_num) (by norm_num)
  let z6 : ℝ := ((1 : ℝ)) - (vp)
  have h6 : RB z6 ((284001 : ℝ) / 500000) ((57644173 : ℝ) / 100000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hp) (by norm_num) (by norm_num)
  let z7 : ℝ := (z5) * (z6)
  have h7 : RB z7 ((56707201 : ℝ) / 100000000) ((28775819 : ℝ) / 50000000) := rb_widen (rb_mul h5 h6 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z8 : ℝ := (z3) / (z7)
  have h8 : RB z8 ((61492963 : ℝ) / 50000000) ((125782899 : ℝ) / 100000000) := rb_div_signed h3 h7 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z9 : ℝ := (z8) - ((1 : ℝ))
  have h9 : RB z9 ((11492963 : ℝ) / 50000000) ((25782899 : ℝ) / 100000000) := rb_widen (rb_sub h8 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z10 : ℝ := ((1 : ℝ)) - (z1)
  have h10 : RB z10 ((99930651 : ℝ) / 100000000) ((24982663 : ℝ) / 25000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h1) (by norm_num) (by norm_num)
  let z11 : ℝ := (A) * (z10)
  have h11 : RB z11 ((14156083 : ℝ) / 20000000) ((71327961 : ℝ) / 100000000) := rb_widen (rb_mul hA h10 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z12 : ℝ := (z1) / (vm)
  have h12 : RB z12 ((6359 : ℝ) / 12500000) ((3203 : ℝ) / 6250000) := rb_div_signed h1 hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z13 : ℝ := ((1 : ℝ)) - (z12)
  have h13 : RB z13 ((6246797 : ℝ) / 6250000) ((12493641 : ℝ) / 12500000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h12) (by norm_num) (by norm_num)
  let z14 : ℝ := (vm) - ((1 : ℝ))
  have h14 : RB z14 ((4415207 : ℝ) / 12500000) ((145273 : ℝ) / 400000) := rb_widen (rb_sub hm (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z15 : ℝ := (z13) * (z14)
  have h15 : RB z15 ((17651777 : ℝ) / 50000000) ((1451991 : ℝ) / 4000000) := rb_widen (rb_mul h13 h14 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z16 : ℝ := (z11) / (z15)
  have h16 : RB z16 ((194988577 : ℝ) / 100000000) ((202041871 : ℝ) / 100000000) := rb_div_signed h11 h15 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z17 : ℝ := (z16) + ((1 : ℝ))
  have h17 : RB z17 ((294988577 : ℝ) / 100000000) ((302041871 : ℝ) / 100000000) := rb_widen (rb_add h16 (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z18 : ℝ := ((1 : ℝ)) / (z9)
  have h18 : RB z18 ((19392699 : ℝ) / 5000000) ((435048821 : ℝ) / 100000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h9 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z19 : ℝ := ((1 : ℝ)) / (z17)
  have h19 : RB z19 ((4138499 : ℝ) / 12500000) ((16949809 : ℝ) / 50000000) := rb_div_signed (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h17 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := ((2 : ℝ)) * (k)
  have h20 : RB z20 ((777 : ℝ) / 160) ((399 : ℝ) / 80) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hk (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z21 : ℝ := (z20) * (q)
  have h21 : RB z21 ((12788463 : ℝ) / 100000000) ((13134103 : ℝ) / 100000000) := rb_widen (rb_mul h20 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := ((1 : ℝ)) + (q)
  have h22 : RB z22 ((102633403 : ℝ) / 100000000) ((25658351 : ℝ) / 25000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hq) (by norm_num) (by norm_num)
  let z23 : ℝ := (z21) / (z22)
  have h23 : RB z23 ((3115083 : ℝ) / 25000000) ((799819 : ℝ) / 6250000) := rb_div_signed h21 h22 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z24 : ℝ := ((1 : ℝ)) + (z23)
  have h24 : RB z24 ((28115083 : ℝ) / 25000000) ((7049819 : ℝ) / 6250000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h23) (by norm_num) (by norm_num)
  let z25 : ℝ := (vm) - (vp)
  have h25 : RB z25 ((359851 : ℝ) / 390625) ((93962423 : ℝ) / 100000000) := rb_widen (rb_sub hm hp) (by norm_num) (by norm_num)
  let z26 : ℝ := (d) * (z25)
  have h26 : RB z26 ((174910227 : ℝ) / 100000000) ((89202443 : ℝ) / 50000000) := rb_widen (rb_mul hd h25 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := (vp) * (vm)
  have h27 : RB z27 ((28658303 : ℝ) / 50000000) ((14722303 : ℝ) / 25000000) := rb_widen (rb_mul hp hm (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z28 : ℝ := (z1) / (z27)
  have h28 : RB z28 ((92 : ℝ) / 78125) ((120993 : ℝ) / 100000000) := rb_div_signed h1 h27 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z29 : ℝ := ((1 : ℝ)) - (z28)
  have h29 : RB z29 ((99879007 : ℝ) / 100000000) ((78033 : ℝ) / 78125) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h28) (by norm_num) (by norm_num)
  let z30 : ℝ := (z26) * (z29)
  have h30 : RB z30 ((174698597 : ℝ) / 100000000) ((178194797 : ℝ) / 100000000) := rb_widen (rb_mul h26 h29 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z31 : ℝ := ((2 : ℝ)) * (d)
  have h31 : RB z31 ((23733541 : ℝ) / 6250000) ((47467083 : ℝ) / 12500000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) hd (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z32 : ℝ := (z31) * (q)
  have h32 : RB z32 ((2499999 : ℝ) / 25000000) ((10000001 : ℝ) / 100000000) := rb_widen (rb_mul h31 hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z33 : ℝ := (k) + ((1 : ℝ))
  have h33 : RB z33 ((1097 : ℝ) / 320) ((559 : ℝ) / 160) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z34 : ℝ := (z32) / (z33)
  have h34 : RB z34 ((715563 : ℝ) / 25000000) ((2917047 : ℝ) / 100000000) := rb_div_signed h32 h33 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z35 : ℝ := (q) / (vp)
  have h35 : RB z35 ((1523967 : ℝ) / 25000000) ((777167 : ℝ) / 12500000) := rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z36 : ℝ := ((1 : ℝ)) + (z35)
  have h36 : RB z36 ((26523967 : ℝ) / 25000000) ((13277167 : ℝ) / 12500000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h35) (by norm_num) (by norm_num)
  let z37 : ℝ := (z36) * (z18)
  have h37 : RB z37 ((205748523 : ℝ) / 50000000) ((115524317 : ℝ) / 25000000) := rb_widen (rb_mul h36 h18 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z38 : ℝ := (q) / (vm)
  have h38 : RB z38 ((386361 : ℝ) / 20000000) ((1946033 : ℝ) / 100000000) := rb_div_signed hq hm (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z39 : ℝ := ((1 : ℝ)) + (z38)
  have h39 : RB z39 ((20386361 : ℝ) / 20000000) ((101946033 : ℝ) / 100000000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h38) (by norm_num) (by norm_num)
  let z40 : ℝ := (z39) * (z19)
  have h40 : RB z40 ((33747573 : ℝ) / 100000000) ((8639829 : ℝ) / 25000000) := rb_widen (rb_mul h39 h19 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z41 : ℝ := (z37) + (z40)
  have h41 : RB z41 ((445244619 : ℝ) / 100000000) ((62082073 : ℝ) / 12500000) := rb_widen (rb_add h37 h40) (by norm_num) (by norm_num)
  let z42 : ℝ := (z34) * (z41)
  have h42 : RB z42 ((12744023 : ℝ) / 100000000) ((7243853 : ℝ) / 50000000) := rb_widen (rb_mul h34 h41 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z43 : ℝ := (k) + ((1 : ℝ))
  have h43 : RB z43 ((1097 : ℝ) / 320) ((559 : ℝ) / 160) := rb_widen (rb_add hk (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z44 : ℝ := ((2 : ℝ)) * (z24)
  have h44 : RB z44 ((28115083 : ℝ) / 12500000) ((7049819 : ℝ) / 3125000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h24 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z45 : ℝ := (z18) + (z19)
  have h45 : RB z45 ((105240493 : ℝ) / 25000000) ((468948439 : ℝ) / 100000000) := rb_widen (rb_add h18 h19) (by norm_num) (by norm_num)
  let z46 : ℝ := (z44) * (z45)
  have h46 : RB z46 ((473415231 : ℝ) / 50000000) ((1057920517 : ℝ) / 100000000) := rb_widen (rb_mul h44 h45 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z47 : ℝ := (z43) / (z46)
  have h47 : RB z47 ((8101093 : ℝ) / 25000000) ((18449713 : ℝ) / 50000000) := rb_div_signed h43 h46 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z48 : ℝ := Real.log (z47)
  have h48 : RB z48 ((-56343843 : ℝ) / 50000000) ((-99697419 : ℝ) / 100000000) := rb_log h47 (by norm_num) cov_log_1950.1 cov_log_1951.2
  let z49 : ℝ := (d) * (q)
  have h49 : RB z49 ((2499999 : ℝ) / 50000000) ((5000001 : ℝ) / 100000000) := rb_widen (rb_mul hd hq (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z50 : ℝ := Real.log (z49)
  have h50 : RB z50 ((-37446659 : ℝ) / 12500000) ((-299573207 : ℝ) / 100000000) := rb_log h49 (by norm_num) cov_log_1852.1 cov_log_1853.2
  let z51 : ℝ := Real.log (d)
  have h51 : RB z51 ((64116063 : ℝ) / 100000000) ((64116067 : ℝ) / 100000000) := rb_log hd (by norm_num) cov_log_1839.1 cov_log_1840.2
  let z52 : ℝ := (k) * (z51)
  have h52 : RB z52 ((31136363 : ℝ) / 20000000) ((159889443 : ℝ) / 100000000) := rb_widen (rb_mul hk h51 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z53 : ℝ := (z50) + (z52)
  have h53 : RB z53 ((-143891457 : ℝ) / 100000000) ((-34920941 : ℝ) / 25000000) := rb_widen (rb_add h50 h52) (by norm_num) (by norm_num)
  let z54 : ℝ := (((4586076189407 : ℝ) / 2500000000000)) - (z30)
  have h54 : RB z54 ((20993 : ℝ) / 400000) ((8744451 : ℝ) / 100000000) := rb_widen (rb_sub (show RB ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) ((4586076189407 : ℝ) / 2500000000000) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z55 : ℝ := (z54) / (z42)
  have h55 : RB z55 ((36225541 : ℝ) / 100000000) ((2144253 : ℝ) / 3125000) := rb_div_signed h54 h42 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z56 : ℝ := (z53) + (z55)
  have h56 : RB z56 ((-26916479 : ℝ) / 25000000) ((-17766917 : ℝ) / 25000000) := rb_widen (rb_add h53 h55) (by norm_num) (by norm_num)
  have hap : RB (formApi k q) ((28115083 : ℝ) / 25000000) ((7049819 : ℝ) / 6250000) := by
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hc0 : RB (formC0 k A q vp vm) ((-56343843 : ℝ) / 50000000) ((-99697419 : ℝ) / 100000000) := by
    have hh := h48
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hce : RB (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) ((-26916479 : ℝ) / 25000000) ((-17766917 : ℝ) / 25000000) := by
    have hh := h56
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, z33, z34, z35, z36, z37, z38, z39, z40, z41, z42, z43, z44, z45, z46, z47, z48, z49, z50, z51, z52, z53, z54, z55, z56, formDp, formDm, formWp, formWm, formApi, formWidth, formXi, formC0, formCeff] <;> ring
  have hap0 : 0 < formApi k q := by linarith [hap.1]
  have hQm : π / formApi k q ≤ ((14 : ℝ) / 5) := by
    apply (div_le_iff₀ hap0).mpr
    linarith [hap.1, Real.pi_lt_d4]
  have hr : RB (q / vp) ((1523967 : ℝ) / 25000000) ((777167 : ℝ) / 12500000) :=
    rb_div_signed hq hp (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have hRm : π * ((1 + q / vp) / 2) ≤ ((167 : ℝ) / 100) := by
    have hu : (1 + q / vp) / 2 ≤ ((13277167 : ℝ) / 25000000) := by linarith [hr.2]
    have hz : 0 ≤ (1 + q / vp) / 2 := by linarith [hr.1]
    have hh := mul_le_mul_of_nonneg_right Real.pi_lt_d4.le hz
    linarith [mul_le_mul_of_nonneg_left hu (by norm_num : (0 : ℝ) ≤ 3.1416)]
  have hQπ : ((14 : ℝ) / 5) ≤ π := by linarith [Real.pi_gt_d4]
  have hRπ : ((167 : ℝ) / 100) ≤ π := by linarith [Real.pi_gt_d4]
  have hB : ((-78360181 : ℝ) / 100000000) ≤ formC0 k A q vp vm + hfun ((14 : ℝ) / 5) + hfun ((167 : ℝ) / 100) := by
    linarith [hc0.1, cov_h_40, cov_h_25]
  have hP : ((197929797 : ℝ) / 100000000) ≤ -(π * (formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) / formApi k q) := by
    rw [← neg_div, neg_mul_eq_mul_neg]
    apply (le_div_iff₀ hap0).mpr
    have hz : 0 ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) := by linarith [hce.2]
    have hh := mul_le_mul_of_nonneg_left (show ((17766917 : ℝ) / 25000000) ≤ -(formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) by linarith [hce.2]) Real.pi_pos.le
    have hh' := mul_le_mul_of_nonneg_right Real.pi_gt_d4.le (by norm_num : (0 : ℝ) ≤ ((17766917 : ℝ) / 25000000))
    linarith [hap.2]
  have hS : ((1862041 : ℝ) / 3125000) ≤ EP1038.Arc.sinc ((167 : ℝ) / 100) := by
    apply sinc_lower_near_half_pi (by norm_num) (show (0 : ℝ) ≤ ((397 : ℝ) / 4000) by norm_num)
    · rw [abs_le]; constructor <;> linarith [Real.pi_gt_d4, Real.pi_lt_d4]
    · norm_num
  intro Q V hQ hV
  have hQQ := hQ.2.trans hQm
  have hVV := hV.2.trans hRm
  rcases le_or_gt Q ((63 : ℝ) / 25) with hcell | hnext
  · exact scalar_cell_simple (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((63 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hQ.1 hQQ hV.1 hVV hcell (by norm_num)
  rcases le_or_gt Q ((64 : ℝ) / 25) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((64 : ℝ) / 25)) (lo := ((63 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((13 : ℝ) / 5) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((13 : ℝ) / 5)) (lo := ((64 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((66 : ℝ) / 25) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((66 : ℝ) / 25)) (lo := ((13 : ℝ) / 5)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((67 : ℝ) / 25) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((67 : ℝ) / 25)) (lo := ((66 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((68 : ℝ) / 25) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((68 : ℝ) / 25)) (lo := ((67 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  rcases le_or_gt Q ((69 : ℝ) / 25) with hcell | hnext
  · exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((69 : ℝ) / 25)) (lo := ((68 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
  have hcell := hQQ
  exact scalar_cell_square (c0 := formC0 k A q vp vm) (Ceff := formCeff k A q d vp vm ((4586076189407 : ℝ) / 2500000000000)) (hi := ((14 : ℝ) / 5)) (lo := ((69 : ℝ) / 25)) hap0 hQπ hRπ hB hP (by norm_num) hS (by norm_num) (by norm_num) hQ.1 hQQ hV.1 hVV (by linarith) hcell (by norm_num)
theorem cov_params_109 {k : ℝ} (hk : RB k ((777 : ℝ) / 320) ((399 : ℝ) / 160)) :
    RB (k / (k + 1)) ((777 : ℝ) / 1097) ((399 : ℝ) / 559) ∧
    RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) ∧ RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
  let z1 : ℝ := Real.sqrt (((9 : ℝ) / 5))
  have h1 : RB z1 ((67082039 : ℝ) / 50000000) ((134164079 : ℝ) / 100000000) := rb_sqrt (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.sqrt ((2 : ℝ))
  have h2 : RB z2 ((35355339 : ℝ) / 25000000) ((141421357 : ℝ) / 100000000) := rb_sqrt (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by linarith [(show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩).1]) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z3 : ℝ := (z1) + (z2)
  have h3 : RB z3 ((137792717 : ℝ) / 50000000) ((68896359 : ℝ) / 25000000) := rb_widen (rb_add h1 h2) (by norm_num) (by norm_num)
  let z4 : ℝ := (z3) / ((2 : ℝ))
  have h4 : RB z4 ((137792717 : ℝ) / 100000000) ((68896359 : ℝ) / 50000000) := rb_div_signed h3 (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z5 : ℝ := (z4) ^ 2
  have h5 : RB z5 ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := rb_widen (rb_sq h4 (by norm_num)) (by norm_num) (by norm_num)
  let z6 : ℝ := ((2 : ℝ)) - (((9 : ℝ) / 5))
  have h6 : RB z6 ((1 : ℝ) / 5) ((1 : ℝ) / 5) := rb_widen (rb_sub (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) (show RB ((9 : ℝ) / 5) ((9 : ℝ) / 5) ((9 : ℝ) / 5) from ⟨le_rfl, le_rfl⟩)) (by norm_num) (by norm_num)
  let z7 : ℝ := (z6) / ((4 : ℝ))
  have h7 : RB z7 ((1 : ℝ) / 20) ((1 : ℝ) / 20) := rb_div_signed h6 (show RB (4 : ℝ) (4 : ℝ) (4 : ℝ) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := (z7) / (z5)
  have h8 : RB z8 ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := rb_div_signed h7 h5 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  have ha : 0 < ((9 : ℝ) / 5) := by  linarith [hk.2]
  have ha2 : ((9 : ℝ) / 5) < 2 := by  linarith [hk.1]
  have hd : RB (D0a (((9 : ℝ) / 5))) ((23733541 : ℝ) / 12500000) ((47467083 : ℝ) / 25000000) := by
    have hh := h5
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hq : RB (qa (((9 : ℝ) / 5))) ((2633403 : ℝ) / 100000000) ((658351 : ℝ) / 25000000) := by
    have hh := h8
    rw [show qa (((9 : ℝ) / 5)) = ((2 - ((9 : ℝ) / 5)) / 4) / D0a (((9 : ℝ) / 5)) by
      apply (eq_div_iff (D0a_pos ha).ne').mpr
      rw [mul_comm]; exact D0a_mul_qa ha]
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, r1A, D0a] <;> norm_num <;> ring
  have hkp : 0 < k + 1 := by linarith [hk.1]
  have hA : RB (k / (k + 1)) ((777 : ℝ) / 1097) ((399 : ℝ) / 559) := by
    constructor
    · apply (le_div_iff₀ hkp).mpr; linarith [hk.1]
    · apply (div_le_iff₀ hkp).mpr; linarith [hk.2]
  exact ⟨hA, hq, hd⟩
theorem cov_affine_109 {k : ℝ} (hk : RB k ((777 : ℝ) / 320) ((399 : ℝ) / 160)) : RatioCertified k := by
  obtain ⟨hA, hq, hd⟩ := cov_params_109 hk
  obtain ⟨epl, eph, eml, emh⟩ := cov_signs_109 hA hq hd
  have hk0 : 0 < k := by linarith [hk.1]
  have ha : 0 < ((9 : ℝ) / 5) := by norm_num
  have ha2 : ((9 : ℝ) / 5) < 2 := by norm_num
  have hAz : 0 ≤ k / (k + 1) := by positivity
  have hH : 2 * (k / (k + 1)) ^ 2 ≤ ((9 : ℝ) / 5) := by nlinarith [hA.2]
  apply ratio_certified_of_box hk0 ha ha2 hH (pl := ((42355827 : ℝ) / 100000000)) (ph := ((215999 : ℝ) / 500000)) (ml := ((16915207 : ℝ) / 12500000)) (mh := ((545273 : ℝ) / 400000)) (L := ((4586076189407 : ℝ) / 2500000000000))
  · linarith [hq.2]
  · norm_num
  · norm_num
  · norm_num
  · norm_num
  · exact epl
  · exact eph
  · exact eml
  · exact emh
  · convert Dval_lt_pilotTarget.le using 1 <;> norm_num [pilotTarget]
  · intro vp hp vm hm
    exact cov_numeric_109 hk hA hq hd ⟨hp.1.le, hp.2.le⟩ ⟨hm.1.le, hm.2.le⟩
end EP1038.ReferenceCert
