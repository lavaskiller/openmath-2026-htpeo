import LeanProject.Leaf

/-!
# EP-1038: symmetries of the sublevel measure and the degree-one case (proof.md Lemma 1.2, Lemma 2.1)

* `sublevel r` — `{x : |∏ (x - r_i)| < 1}` for `r : Fin n → ℝ`.
* `volume_sublevel_perm` — invariance under permutations of the roots (Lemma 1.2).
* `volume_sublevel_neg` — invariance under `r ↦ -r` (Lemma 1.2).
* `volume_sublevel_translate` — invariance under translation `r ↦ r + t` (Definitions, [M-01]).
* `volume_deg1` — for one root, the measure is `2` (Lemma 2.1, `m₁ = 2`).
-/

open Real MeasureTheory Finset

namespace EP1038

/-- The sublevel set `S(r) = {x : |∏ (x - r_i)| < 1}`. -/
def sublevel {n : ℕ} (r : Fin n → ℝ) : Set ℝ := {x : ℝ | |∏ i, (x - r i)| < 1}

theorem sublevel_perm {n : ℕ} (r : Fin n → ℝ) (σ : Equiv.Perm (Fin n)) :
    sublevel (r ∘ σ) = sublevel r := by
  ext x
  simp only [sublevel, Set.mem_setOf_eq, Function.comp]
  rw [Equiv.prod_comp σ (fun i => x - r i)]

theorem volume_sublevel_perm {n : ℕ} (r : Fin n → ℝ) (σ : Equiv.Perm (Fin n)) :
    volume (sublevel (r ∘ σ)) = volume (sublevel r) := by
  rw [sublevel_perm]

theorem sublevel_neg {n : ℕ} (r : Fin n → ℝ) :
    sublevel (fun i => -r i) = -sublevel r := by
  ext x
  simp only [sublevel, Set.mem_setOf_eq, Set.mem_neg]
  have : ∏ i, (x - -r i) = (-1) ^ n * ∏ i, (-x - r i) := by
    rw [show ((-1 : ℝ) ^ n) = ∏ _i : Fin n, (-1 : ℝ) by simp, ← Finset.prod_mul_distrib]
    congr 1; ext i; ring
  rw [this, abs_mul, abs_pow, abs_neg, abs_one, one_pow, one_mul]

theorem volume_sublevel_neg {n : ℕ} (r : Fin n → ℝ) :
    volume (sublevel (fun i => -r i)) = volume (sublevel r) := by
  rw [sublevel_neg]
  have : -sublevel r = (fun x : ℝ => (-1) * x) ⁻¹' sublevel r := by
    ext x; simp [Set.mem_neg]
  rw [this, Real.volume_preimage_mul_left (by norm_num : (-1 : ℝ) ≠ 0)]
  simp

theorem sublevel_translate {n : ℕ} (r : Fin n → ℝ) (t : ℝ) :
    sublevel (fun i => r i + t) = (fun x => x + t) '' sublevel r := by
  ext x
  simp only [sublevel, Set.mem_setOf_eq, Set.mem_image]
  constructor
  · intro h
    refine ⟨x - t, ?_, by ring⟩
    have : ∏ i, (x - t - r i) = ∏ i, (x - (r i + t)) := by congr 1; ext i; ring
    rw [this]; exact h
  · rintro ⟨y, hy, rfl⟩
    have : ∏ i, (y + t - (r i + t)) = ∏ i, (y - r i) := by congr 1; ext i; ring
    rw [this]; exact hy

theorem volume_sublevel_translate {n : ℕ} (r : Fin n → ℝ) (t : ℝ) :
    volume (sublevel (fun i => r i + t)) = volume (sublevel r) := by
  rw [sublevel_translate, Set.image_add_right, measure_preimage_add_right]

/-- Lemma 2.1: `m₁ = 2`. -/
theorem volume_deg1 (c : ℝ) : volume (sublevel (fun _ : Fin 1 => c)) = ENNReal.ofReal 2 := by
  have : sublevel (fun _ : Fin 1 => c) = Set.Ioo (c - 1) (c + 1) := by
    ext x
    simp only [sublevel, Set.mem_setOf_eq, Finset.univ_unique, Finset.prod_singleton,
      Set.mem_Ioo, abs_lt]
    constructor <;> rintro ⟨h1, h2⟩ <;> constructor <;> linarith
  rw [this, Real.volume_Ioo]; congr 1; ring

end EP1038
