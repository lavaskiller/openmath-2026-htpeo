import LeanProject.DLowerLogs
import LeanProject.DLowerTSChunk01
open Real Set Finset
namespace EP1038.DLowerCert
open EP1038.Stage9 EP1038.ReferenceCert
-- Large rational arithmetic checks of the finite logarithm remainder.
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem dlower_S_0 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((259614842926741381426524816461005 : ℝ) / 5192296858534827628530496329220096) ((262602036213167199442600599958323 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((1 : ℝ) / 20) ((161841 : ℝ) / 3200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((21 : ℝ) / 20) ((3361841 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((48790164169 : ℝ) / 1000000000000) ((9867586157 : ℝ) / 200000000000) := rb_log h1 (by norm_num) dlower_log_159.1 dlower_log_160.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((48790164169 : ℝ) / 500000000000) ((9867586157 : ℝ) / 100000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((594471318989 : ℝ) / 1000000000000) ((297783426111 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-599146454711 : ℝ) / 200000000000) ((-746072929251 : ℝ) / 250000000000) := rb_log hqr (by norm_num) dlower_log_161.1 dlower_log_162.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((746072929251 : ℝ) / 250000000000) ((599146454711 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((49609850339 : ℝ) / 250000000000) ((199567236953 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((800432763047 : ℝ) / 1000000000000) ((200390149661 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1 : ℝ) / 400) ((511572447 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((82660435639 : ℝ) / 200000000000)) - (z9)
  have h10 : RB z10 ((10268607899 : ℝ) / 25000000000) ((82160435639 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB ((82660435639 : ℝ) / 200000000000) ((82660435639 : ℝ) / 200000000000) ((82660435639 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((117339564361 : ℝ) / 200000000000))
  have h11 : RB z11 ((14001903559 : ℝ) / 20000000000) ((175048450381 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((117339564361 : ℝ) / 200000000000) ((117339564361 : ℝ) / 200000000000) ((117339564361 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-178269492341 : ℝ) / 500000000000) ((-44549765367 : ℝ) / 125000000000) := rb_log h11 (by norm_num) dlower_log_163.1 dlower_log_164.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-142893801001 : ℝ) / 500000000000) ((-142636367143 : ℝ) / 500000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((82660435639 : ℝ) / 200000000000))
  have h14 : RB z14 ((-883576287227 : ℝ) / 1000000000000) ((-35343051489 : ℝ) / 40000000000) := rb_log (show RB ((82660435639 : ℝ) / 200000000000) ((82660435639 : ℝ) / 200000000000) ((82660435639 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_165.1 dlower_log_165.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((597788685223 : ℝ) / 1000000000000) ((598303552941 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2221833001 : ℝ) / 1000000000000) ((119757311 : ℝ) / 31250000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1 : ℝ) / 400) ((511572447 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((716098533079 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((1429639203923 : ℝ) / 1000000000000) ((714848533079 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((716098533079 : ℝ) / 500000000000) ((716098533079 : ℝ) / 500000000000) ((716098533079 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((216098533079 : ℝ) / 500000000000))
  have h19 : RB z19 ((826960266431 : ℝ) / 250000000000) ((826993736253 : ℝ) / 250000000000) := rb_div_signed h18 (show RB ((216098533079 : ℝ) / 500000000000) ((216098533079 : ℝ) / 500000000000) ((216098533079 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((598147865289 : ℝ) / 500000000000) ((598168101537 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_166.1 dlower_log_167.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((957554297047 : ℝ) / 1000000000000) ((239733990779 : ℝ) / 250000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((716098533079 : ℝ) / 500000000000))
  have h22 : RB z22 ((359209675101 : ℝ) / 1000000000000) ((359209675103 : ℝ) / 1000000000000) := rb_log (show RB ((716098533079 : ℝ) / 500000000000) ((716098533079 : ℝ) / 500000000000) ((716098533079 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_168.1 dlower_log_168.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((74793077743 : ℝ) / 125000000000) ((119945257603 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1388884861 : ℝ) / 500000000000) ((2627484513 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((21 : ℝ) / 20) ((3361841 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((441 : ℝ) / 400) ((220741697447 : ℝ) / 200000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1812072683259 : ℝ) / 1000000000000) ((1814058956917 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1018894887963 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1846311593589 : ℝ) / 1000000000000) ((1848335397667 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((1018894887963 : ℝ) / 1000000000000) ((1018894887963 : ℝ) / 1000000000000) ((1018894887963 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1 : ℝ) / 400) ((511572447 : ℝ) / 200000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((59193016704758992002481 : ℝ) / 100000000000000000000000))
  have h30 : RB z30 ((2111735589 : ℝ) / 500000000000) ((4321222971 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((59193016704758992002481 : ℝ) / 100000000000000000000000) ((59193016704758992002481 : ℝ) / 100000000000000000000000) ((59193016704758992002481 : ℝ) / 100000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((995678777029 : ℝ) / 1000000000000) ((497888264411 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1838333269519 : ℝ) / 1000000000000) ((460132251597 : ℝ) / 250000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((82660435639 : ℝ) / 200000000000)) ((2221833001 : ℝ) / 1000000000000) ((119757311 : ℝ) / 31250000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((716098533079 : ℝ) / 500000000000)) ((1388884861 : ℝ) / 500000000000) ((2627484513 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((82660435639 : ℝ) / 200000000000)) (wl := ((716098533079 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1838333269519 : ℝ) / 1000000000000) ≤ D0q (q) * (((716098533079 : ℝ) / 500000000000) - ((82660435639 : ℝ) / 200000000000)) * (1 - (q) ^ 2 / (((716098533079 : ℝ) / 500000000000) * ((82660435639 : ℝ) / 200000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_1 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((262602036213167199442600599958323 : ℝ) / 5192296858534827628530496329220096) ((265589229499593017458676383455641 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((50575312499 : ℝ) / 1000000000000) ((81841 : ℝ) / 1600000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1050575312499 : ℝ) / 1000000000000) ((1681841 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((49337930783 : ℝ) / 1000000000000) ((12471349379 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_169.1 dlower_log_170.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((49337930783 : ℝ) / 500000000000) ((12471349379 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((593376385527 : ℝ) / 1000000000000) ((297235659497 : ℝ) / 500000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-1492145858513 : ℝ) / 500000000000) ((-1486490283847 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_171.1 dlower_log_172.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1486490283847 : ℝ) / 500000000000) ((1492145858513 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((99416619049 : ℝ) / 500000000000) ((199958023761 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((800041976239 : ℝ) / 1000000000000) ((400583380951 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((1278931117 : ℝ) / 500000000000) ((1308193219 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((412054410327 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((409438023889 : ℝ) / 1000000000000) ((409496548093 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((412054410327 : ℝ) / 1000000000000) ((412054410327 : ℝ) / 1000000000000) ((412054410327 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((587945589673 : ℝ) / 1000000000000))
  have h11 : RB z11 ((696387609807 : ℝ) / 1000000000000) ((348243574989 : ℝ) / 500000000000) := rb_div_signed h10 (show RB ((587945589673 : ℝ) / 1000000000000) ((587945589673 : ℝ) / 1000000000000) ((587945589673 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-22615553939 : ℝ) / 62500000000) ((-361705935353 : ℝ) / 1000000000000) := rb_log h11 (by norm_num) dlower_log_173.1 dlower_log_174.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-289901281887 : ℝ) / 1000000000000) ((-289379931337 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((412054410327 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-221649968613 : ℝ) / 250000000000) ((-17731997489 : ℝ) / 20000000000) := rb_log (show RB ((412054410327 : ℝ) / 1000000000000) ((412054410327 : ℝ) / 1000000000000) ((412054410327 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_175.1 dlower_log_175.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((596698592563 : ℝ) / 1000000000000) ((119443988623 : ℝ) / 200000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2227273569 : ℝ) / 1000000000000) ((960889397 : ℝ) / 250000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((1278931117 : ℝ) / 500000000000) ((1308193219 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((17906214431 : ℝ) / 12500000000)) - (z17)
  have h18 : RB z18 ((714940384021 : ℝ) / 500000000000) ((714969646123 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((17906214431 : ℝ) / 12500000000) ((17906214431 : ℝ) / 12500000000) ((17906214431 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((5406214431 : ℝ) / 12500000000))
  have h19 : RB z19 ((3306104452319 : ℝ) / 1000000000000) ((3306239769289 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((5406214431 : ℝ) / 12500000000) ((5406214431 : ℝ) / 12500000000) ((5406214431 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1195770593671 : ℝ) / 1000000000000) ((239162304453 : ℝ) / 200000000000) := rb_log h19 (by norm_num) dlower_log_176.1 dlower_log_177.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((956666668889 : ℝ) / 1000000000000) ((958044445139 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((17906214431 : ℝ) / 12500000000))
  have h22 : RB z22 ((179709591601 : ℝ) / 500000000000) ((89854795801 : ℝ) / 250000000000) := rb_log (show RB ((17906214431 : ℝ) / 12500000000) ((17906214431 : ℝ) / 12500000000) ((17906214431 : ℝ) / 12500000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_178.1 dlower_log_178.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((119449497137 : ℝ) / 200000000000) ((598625261937 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2776166691 : ℝ) / 1000000000000) ((524887641 : ℝ) / 100000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1050575312499 : ℝ) / 1000000000000) ((1681841 : ℝ) / 1600000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((17245445113 : ℝ) / 15625000000) ((552458818219 : ℝ) / 500000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((905044835037 : ℝ) / 500000000000) ((362414536653 : ℝ) / 200000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1020442744153 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1847092870093 : ℝ) / 1000000000000) ((462279105379 : ℝ) / 250000000000) := rb_widen (rb_mul h27 (show RB ((1020442744153 : ℝ) / 1000000000000) ((1020442744153 : ℝ) / 1000000000000) ((1020442744153 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((1278931117 : ℝ) / 500000000000) ((1308193219 : ℝ) / 500000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((7378334628554522828937 : ℝ) / 12500000000000000000000))
  have h30 : RB z30 ((2166700179 : ℝ) / 500000000000) ((886509819 : ℝ) / 200000000000) := rb_div_signed h29 (show RB ((7378334628554522828937 : ℝ) / 12500000000000000000000) ((7378334628554522828937 : ℝ) / 12500000000000000000000) ((7378334628554522828937 : ℝ) / 12500000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((199113490181 : ℝ) / 200000000000) ((497833299821 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1838905540263 : ℝ) / 1000000000000) ((920551729877 : ℝ) / 500000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((412054410327 : ℝ) / 1000000000000)) ((2227273569 : ℝ) / 1000000000000) ((960889397 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((17906214431 : ℝ) / 12500000000)) ((2776166691 : ℝ) / 1000000000000) ((524887641 : ℝ) / 100000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((412054410327 : ℝ) / 1000000000000)) (wl := ((17906214431 : ℝ) / 12500000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1838905540263 : ℝ) / 1000000000000) ≤ D0q (q) * (((17906214431 : ℝ) / 12500000000) - ((412054410327 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((17906214431 : ℝ) / 12500000000) * ((412054410327 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_2 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((265589229499593017458676383455641 : ℝ) / 5192296858534827628530496329220096) ((268576422786018835474752166952959 : ℝ) / 5192296858534827628530496329220096)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((51150624999 : ℝ) / 1000000000000) ((165523 : ℝ) / 3200000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1051150624999 : ℝ) / 1000000000000) ((3365523 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((24942698757 : ℝ) / 500000000000) ((12608141173 : ℝ) / 250000000000) := rb_log h1 (by norm_num) dlower_log_179.1 dlower_log_180.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((24942698757 : ℝ) / 250000000000) ((12608141173 : ℝ) / 125000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((23691282047 : ℝ) / 40000000000) ((148344096383 : ℝ) / 250000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-743245141929 : ℝ) / 250000000000) ((-46278061419 : ℝ) / 15625000000) := rb_log hqr (by norm_num) dlower_log_181.1 dlower_log_182.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((46278061419 : ℝ) / 15625000000) ((743245141929 : ℝ) / 250000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((39844327111 : ℝ) / 200000000000) ((200343440059 : ℝ) / 1000000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((799656559941 : ℝ) / 1000000000000) ((160155672889 : ℝ) / 200000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((2616386437 : ℝ) / 1000000000000) ((2675572611 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((205400574353 : ℝ) / 500000000000)) - (z9)
  have h10 : RB z10 ((81625115219 : ℝ) / 200000000000) ((408184762269 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((205400574353 : ℝ) / 500000000000) ((205400574353 : ℝ) / 500000000000) ((205400574353 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((294599425647 : ℝ) / 500000000000))
  have h11 : RB z11 ((692678838729 : ℝ) / 1000000000000) ((692779290681 : ℝ) / 1000000000000) := rb_div_signed h10 (show RB ((294599425647 : ℝ) / 500000000000) ((294599425647 : ℝ) / 500000000000) ((294599425647 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-36718882339 : ℝ) / 100000000000) ((-22940238399 : ℝ) / 62500000000) := rb_log h11 (by norm_num) dlower_log_183.1 dlower_log_184.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-294036865437 : ℝ) / 1000000000000) ((-293508993957 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((205400574353 : ℝ) / 500000000000))
  have h14 : RB z14 ((-444823002333 : ℝ) / 500000000000) ((-111205750583 : ℝ) / 125000000000) := rb_log (show RB ((205400574353 : ℝ) / 500000000000) ((205400574353 : ℝ) / 500000000000) ((205400574353 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_185.1 dlower_log_185.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((595609139227 : ℝ) / 1000000000000) ((596137010709 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((446550739 : ℝ) / 200000000000) ((1927479767 : ℝ) / 500000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((2616386437 : ℝ) / 1000000000000) ((2675572611 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((1432800382103 : ℝ) / 1000000000000)) - (z17)
  have h18 : RB z18 ((357531202373 : ℝ) / 250000000000) ((715091997833 : ℝ) / 500000000000) := rb_widen (rb_sub (show RB ((1432800382103 : ℝ) / 1000000000000) ((1432800382103 : ℝ) / 1000000000000) ((1432800382103 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((432800382103 : ℝ) / 1000000000000))
  have h19 : RB z19 ((1652176001489 : ℝ) / 500000000000) ((3304488754647 : ℝ) / 1000000000000) := rb_div_signed h18 (show RB ((432800382103 : ℝ) / 1000000000000) ((432800382103 : ℝ) / 1000000000000) ((432800382103 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((597620194207 : ℝ) / 500000000000) ((1195281772881 : ℝ) / 1000000000000) := rb_log h19 (by norm_num) dlower_log_186.1 dlower_log_187.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((955781817301 : ℝ) / 1000000000000) ((957155783139 : ℝ) / 1000000000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((1432800382103 : ℝ) / 1000000000000))
  have h22 : RB z22 ((179815419223 : ℝ) / 500000000000) ((22476927403 : ℝ) / 62500000000) := rb_log (show RB ((1432800382103 : ℝ) / 1000000000000) ((1432800382103 : ℝ) / 1000000000000) ((1432800382103 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_188.1 dlower_log_188.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((596150978853 : ℝ) / 1000000000000) ((597524944693 : ℝ) / 1000000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((2774593321 : ℝ) / 1000000000000) ((2621446759 : ℝ) / 500000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1051150624999 : ℝ) / 1000000000000) ((3365523 : ℝ) / 3200000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((220983527287 : ℝ) / 200000000000) ((1106127447611 : ℝ) / 1000000000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1808109910227 : ℝ) / 1000000000000) ((5656530219 : ℝ) / 3125000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((1021999233397 : ℝ) / 1000000000000))
  have h28 : RB z28 ((1847886942149 : ℝ) / 1000000000000) ((924955127601 : ℝ) / 500000000000) := rb_widen (rb_mul h27 (show RB ((1021999233397 : ℝ) / 1000000000000) ((1021999233397 : ℝ) / 1000000000000) ((1021999233397 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((2616386437 : ℝ) / 1000000000000) ((2675572611 : ℝ) / 1000000000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((294298021417154062004359 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((277820679 : ℝ) / 62500000000) ((2272842847 : ℝ) / 500000000000) := rb_div_signed h29 (show RB ((294298021417154062004359 : ℝ) / 500000000000000000000000) ((294298021417154062004359 : ℝ) / 500000000000000000000000) ((294298021417154062004359 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((497727157153 : ℝ) / 500000000000) ((62222179321 : ℝ) / 62500000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((1839487028911 : ℝ) / 1000000000000) ((1841687162031 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((205400574353 : ℝ) / 500000000000)) ((446550739 : ℝ) / 200000000000) ((1927479767 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((1432800382103 : ℝ) / 1000000000000)) ((2774593321 : ℝ) / 1000000000000) ((2621446759 : ℝ) / 500000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((205400574353 : ℝ) / 500000000000)) (wl := ((1432800382103 : ℝ) / 1000000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((1839487028911 : ℝ) / 1000000000000) ≤ D0q (q) * (((1432800382103 : ℝ) / 1000000000000) - ((205400574353 : ℝ) / 500000000000)) * (1 - (q) ^ 2 / (((1432800382103 : ℝ) / 1000000000000) * ((205400574353 : ℝ) / 500000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

theorem dlower_S_3 {q : ℝ} (hqa : q ∈ Qadm)
    (hq : RB q ((268576422786018835474752166952959 : ℝ) / 5192296858534827628530496329220096) ((135781808036222326745413975225139 : ℝ) / 2596148429267413814265248164610048)) : lowerTarget ≤ Lam q := by
  have hqr : RB q ((51725937499 : ℝ) / 1000000000000) ((41841 : ℝ) / 800000) := rb_widen hq (by norm_num) (by norm_num)
  let z1 : ℝ := ((1 : ℝ)) + (q)
  have h1 : RB z1 ((1051725937499 : ℝ) / 1000000000000) ((841841 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z2 : ℝ := Real.log (z1)
  have h2 : RB z2 ((5043256469 : ℝ) / 100000000000) ((50979432639 : ℝ) / 1000000000000) := rb_log h1 (by norm_num) dlower_log_189.1 dlower_log_190.2
  let z3 : ℝ := ((2 : ℝ)) * (z2)
  have h3 : RB z3 ((5043256469 : ℝ) / 50000000000) ((50979432639 : ℝ) / 500000000000) := rb_widen (rb_mul (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h2 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z4 : ℝ := (Real.log 2) - (z3)
  have h4 : RB z4 ((591188315281 : ℝ) / 1000000000000) ((29614102559 : ℝ) / 50000000000) := rb_widen (rb_sub witness_log_two h3) (by norm_num) (by norm_num)
  let z5 : ℝ := Real.log (q)
  have h5 : RB z5 ((-2961795930837 : ℝ) / 1000000000000) ((-1475367503811 : ℝ) / 500000000000) := rb_log hqr (by norm_num) dlower_log_191.1 dlower_log_192.2
  let z6 : ℝ := ((0 : ℝ)) - (z5)
  have h6 : RB z6 ((1475367503811 : ℝ) / 500000000000) ((2961795930837 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB (0 : ℝ) (0 : ℝ) (0 : ℝ) from ⟨le_rfl, le_rfl⟩) h5) (by norm_num) (by norm_num)
  let z7 : ℝ := (z4) / (z6)
  have h7 : RB z7 ((24950584421 : ℝ) / 125000000000) ((100361782683 : ℝ) / 500000000000) := rb_div_signed h4 h6 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z8 : ℝ := ((1 : ℝ)) - (z7)
  have h8 : RB z8 ((399638217317 : ℝ) / 500000000000) ((100049415579 : ℝ) / 125000000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h7) (by norm_num) (by norm_num)
  let z9 : ℝ := (q) ^ 2
  have h9 : RB z9 ((267557261 : ℝ) / 100000000000) ((170963797 : ℝ) / 62500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z10 : ℝ := (((409542370767 : ℝ) / 1000000000000)) - (z9)
  have h10 : RB z10 ((81361390003 : ℝ) / 200000000000) ((406866798157 : ℝ) / 1000000000000) := rb_widen (rb_sub (show RB ((409542370767 : ℝ) / 1000000000000) ((409542370767 : ℝ) / 1000000000000) ((409542370767 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) h9) (by norm_num) (by norm_num)
  let z11 : ℝ := (z10) / (((590457629233 : ℝ) / 1000000000000))
  have h11 : RB z11 ((172242227839 : ℝ) / 250000000000) ((172267567567 : ℝ) / 250000000000) := rb_div_signed h10 (show RB ((590457629233 : ℝ) / 1000000000000) ((590457629233 : ℝ) / 1000000000000) ((590457629233 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z12 : ℝ := Real.log (z11)
  have h12 : RB z12 ((-372559130387 : ℝ) / 1000000000000) ((-37241202439 : ℝ) / 100000000000) := rb_log h11 (by norm_num) dlower_log_193.1 dlower_log_194.2
  let z13 : ℝ := (z12) * (z8)
  have h13 : RB z13 ((-298194586111 : ℝ) / 1000000000000) ((-297660155069 : ℝ) / 1000000000000) := rb_mul_signed h12 h8 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z14 : ℝ := Real.log (((409542370767 : ℝ) / 1000000000000))
  have h14 : RB z14 ((-446357455763 : ℝ) / 500000000000) ((-223178727881 : ℝ) / 250000000000) := rb_log (show RB ((409542370767 : ℝ) / 1000000000000) ((409542370767 : ℝ) / 1000000000000) ((409542370767 : ℝ) / 1000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_195.1 dlower_log_195.2
  let z15 : ℝ := (z13) - (z14)
  have h15 : RB z15 ((594520325413 : ℝ) / 1000000000000) ((595054756457 : ℝ) / 1000000000000) := rb_widen (rb_sub h13 h14) (by norm_num) (by norm_num)
  let z16 : ℝ := (z15) - (z4)
  have h16 : RB z16 ((2238274233 : ℝ) / 1000000000000) ((483305147 : ℝ) / 125000000000) := rb_widen (rb_sub h15 h4) (by norm_num) (by norm_num)
  let z17 : ℝ := (q) ^ 2
  have h17 : RB z17 ((267557261 : ℝ) / 100000000000) ((170963797 : ℝ) / 62500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z18 : ℝ := (((716553353441 : ℝ) / 500000000000)) - (z17)
  have h18 : RB z18 ((143037128613 : ℝ) / 100000000000) ((22350486473 : ℝ) / 15625000000) := rb_widen (rb_sub (show RB ((716553353441 : ℝ) / 500000000000) ((716553353441 : ℝ) / 500000000000) ((716553353441 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) h17) (by norm_num) (by norm_num)
  let z19 : ℝ := (z18) / (((216553353441 : ℝ) / 500000000000))
  have h19 : RB z19 ((1651292006567 : ℝ) / 500000000000) ((6605444393 : ℝ) / 2000000000) := rb_div_signed h18 (show RB ((216553353441 : ℝ) / 500000000000) ((216553353441 : ℝ) / 500000000000) ((216553353441 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z20 : ℝ := Real.log (z19)
  have h20 : RB z20 ((1194705196343 : ℝ) / 1000000000000) ((597373518227 : ℝ) / 500000000000) := rb_log h19 (by norm_num) dlower_log_196.1 dlower_log_197.2
  let z21 : ℝ := (z8) * (z20)
  have h21 : RB z21 ((954899709771 : ℝ) / 1000000000000) ((59766871381 : ℝ) / 62500000000) := rb_widen (rb_mul h8 h20 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z22 : ℝ := Real.log (((716553353441 : ℝ) / 500000000000))
  have h22 : RB z22 ((359844610051 : ℝ) / 1000000000000) ((359844610053 : ℝ) / 1000000000000) := rb_log (show RB ((716553353441 : ℝ) / 500000000000) ((716553353441 : ℝ) / 500000000000) ((716553353441 : ℝ) / 500000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) dlower_log_198.1 dlower_log_198.2
  let z23 : ℝ := (z21) - (z22)
  have h23 : RB z23 ((297527549859 : ℝ) / 500000000000) ((119285066409 : ℝ) / 200000000000) := rb_widen (rb_sub h21 h22) (by norm_num) (by norm_num)
  let z24 : ℝ := (z23) - (z4)
  have h24 : RB z24 ((1386524269 : ℝ) / 500000000000) ((1309254191 : ℝ) / 250000000000) := rb_widen (rb_sub h23 h4) (by norm_num) (by norm_num)
  let z25 : ℝ := ((1 : ℝ)) + (q)
  have h25 : RB z25 ((1051725937499 : ℝ) / 1000000000000) ((841841 : ℝ) / 800000) := rb_widen (rb_add (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) hqr) (by norm_num) (by norm_num)
  let z26 : ℝ := (z25) ^ 2
  have h26 : RB z26 ((138265930951 : ℝ) / 125000000000) ((69208620047 : ℝ) / 62500000000) := rb_widen (rb_sq h25 (by norm_num)) (by norm_num) (by norm_num)
  let z27 : ℝ := ((2 : ℝ)) / (z26)
  have h27 : RB z27 ((1806133396607 : ℝ) / 1000000000000) ((1808109910233 : ℝ) / 1000000000000) := rb_div_signed (show RB (2 : ℝ) (2 : ℝ) (2 : ℝ) from ⟨le_rfl, le_rfl⟩) h26 (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z28 : ℝ := (z27) * (((204712867223 : ℝ) / 200000000000))
  have h28 : RB z28 ((1848693731033 : ℝ) / 1000000000000) ((1850716819891 : ℝ) / 1000000000000) := rb_widen (rb_mul h27 (show RB ((204712867223 : ℝ) / 200000000000) ((204712867223 : ℝ) / 200000000000) ((204712867223 : ℝ) / 200000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  let z29 : ℝ := (q) ^ 2
  have h29 : RB z29 ((267557261 : ℝ) / 100000000000) ((170963797 : ℝ) / 62500000000) := rb_widen (rb_sq hqr (by norm_num)) (by norm_num) (by norm_num)
  let z30 : ℝ := (z29) / (((293458959149271217259247 : ℝ) / 500000000000000000000000))
  have h30 : RB z30 ((142458837 : ℝ) / 31250000000) ((4660652993 : ℝ) / 1000000000000) := rb_div_signed h29 (show RB ((293458959149271217259247 : ℝ) / 500000000000000000000000) ((293458959149271217259247 : ℝ) / 500000000000000000000000) ((293458959149271217259247 : ℝ) / 500000000000000000000000) from ⟨le_rfl, le_rfl⟩) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)
  let z31 : ℝ := ((1 : ℝ)) - (z30)
  have h31 : RB z31 ((995339347007 : ℝ) / 1000000000000) ((31107541163 : ℝ) / 31250000000) := rb_widen (rb_sub (show RB (1 : ℝ) (1 : ℝ) (1 : ℝ) from ⟨le_rfl, le_rfl⟩) h30) (by norm_num) (by norm_num)
  let z32 : ℝ := (z28) * (z31)
  have h32 : RB z32 ((920038805531 : ℝ) / 500000000000) ((1842279988987 : ℝ) / 1000000000000) := rb_widen (rb_mul h28 h31 (by norm_num) (by norm_num)) (by norm_num) (by norm_num)
  have ha : aval q = 1 - (Real.log 2 - 2 * Real.log (1 + q)) / (-Real.log q) := by
    unfold aval delta
    ring
  have es0 : RB (E (q) ((409542370767 : ℝ) / 1000000000000)) ((2238274233 : ℝ) / 1000000000000) ((483305147 : ℝ) / 125000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h16
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  have es1 : RB (E (q) ((716553353441 : ℝ) / 500000000000)) ((1386524269 : ℝ) / 500000000000) ((1309254191 : ℝ) / 250000000000) := by
    rw [E_eq_log_ratio (by nlinarith [hqr.1, hqr.2]) (by norm_num), ha]
    have hh := h24
    convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, delta] <;> norm_num <;> ring
  apply width_lower_of_positive_signs hqa (vh := ((409542370767 : ℝ) / 1000000000000)) (wl := ((716553353441 : ℝ) / 500000000000))
  · linarith [hqr.2]
  · norm_num
  · norm_num
  · linarith [es0.1]
  · linarith [es1.1]
  · have hh := h32.1
    have hb : ((920038805531 : ℝ) / 500000000000) ≤ D0q (q) * (((716553353441 : ℝ) / 500000000000) - ((409542370767 : ℝ) / 1000000000000)) * (1 - (q) ^ 2 / (((716553353441 : ℝ) / 500000000000) * ((409542370767 : ℝ) / 1000000000000))) := by
      convert hh using 1 <;> dsimp only [z1, z2, z3, z4, z5, z6, z7, z8, z9, z10, z11, z12, z13, z14, z15, z16, z17, z18, z19, z20, z21, z22, z23, z24, z25, z26, z27, z28, z29, z30, z31, z32, D0q] <;> ring
    dsimp [lowerTarget]
    linarith [hb]

end EP1038.DLowerCert
