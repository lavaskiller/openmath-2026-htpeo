import LeanProject.CertificateFormula

/-! The terminal certificates concern the actual Stage 9 zero-platform reference. -/
open Real Set
namespace EP1038.ReferenceCert
open EP1038.Stage9 EP1038.Arc EP1038.Stage11 EP1038.Stage12

noncomputable def terminalA (q : ℝ) : ℝ := 2 * ((1 - q) / (1 + q)) ^ 2

theorem terminal_a_pos {q : ℝ} (hq : q ∈ terminalDomain) : 0 < terminalA q := by
  have hq1 : q < 1 := (terminal_admissible hq).2.1
  have hp : 0 < (1 - q) / (1 + q) := div_pos (sub_pos.mpr hq1) (by linarith [hq.1])
  unfold terminalA
  exact mul_pos (by norm_num) (sq_pos_of_pos hp)

theorem terminal_a_lt_two {q : ℝ} (hq : q ∈ terminalDomain) : terminalA q < 2 := by
  have hp : 0 < (1 - q) / (1 + q) := div_pos (sub_pos.mpr (terminal_admissible hq).2.1) (by linarith [hq.1])
  have hlt : (1 - q) / (1 + q) < 1 := (div_lt_one (by linarith [hq.1])).mpr (by linarith [hq.1])
  unfold terminalA
  nlinarith

theorem terminal_sqrt_a {q : ℝ} (hq : q ∈ terminalDomain) :
    Real.sqrt (terminalA q) = Real.sqrt 2 * ((1 - q) / (1 + q)) := by
  have ha := terminal_a_pos hq
  have hs : 0 ≤ (1 - q) / (1 + q) := div_nonneg (by linarith [(terminal_admissible hq).2.1]) (by linarith [hq.1])
  have hr := Real.sqrt_nonneg (2 : ℝ)
  have he : (Real.sqrt 2 * ((1 - q) / (1 + q))) ^ 2 = terminalA q := by
    rw [mul_pow, Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)]
    rfl
  have hp := mul_nonneg hr hs
  nlinarith [Real.sqrt_nonneg (terminalA q), Real.sq_sqrt ha.le]

theorem terminal_qa {q : ℝ} (hq : q ∈ terminalDomain) : qa (terminalA q) = q := by
  have hn : 1 + q ≠ 0 := by linarith [hq.1]
  have hs : Real.sqrt 2 ≠ 0 := (Real.sqrt_pos.mpr (by norm_num : (0 : ℝ) < 2)).ne'
  unfold qa
  rw [terminal_sqrt_a hq]
  have he : Real.sqrt 2 + Real.sqrt 2 * ((1 - q) / (1 + q)) = Real.sqrt 2 * (2 / (1 + q)) := by
    field_simp [hn]
    <;> ring
  rw [he]
  field_simp [hn, hs]
  <;> ring

theorem terminal_D0 {q : ℝ} (hq : q ∈ terminalDomain) : D0a (terminalA q) = D0q q := by
  have hn : 1 + q ≠ 0 := by linarith [hq.1]
  unfold D0a D0q
  rw [terminal_sqrt_a hq]
  have he : Real.sqrt 2 * ((1 - q) / (1 + q)) + Real.sqrt 2 = Real.sqrt 2 * (2 / (1 + q)) := by
    field_simp [hn]
    <;> ring
  rw [he]
  rw [div_pow, mul_pow, div_pow, Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)]
  field_simp [hn]
  <;> ring

theorem terminal_H1 {q : ℝ} (hq : q ∈ terminalDomain) :
    2 * (terminalK q / (terminalK q + 1)) ^ 2 ≤ terminalA q := by
  have hk := terminalK_pos hq
  have hkp : 0 < terminalK q + 1 := by linarith
  have hA : 0 ≤ terminalK q / (terminalK q + 1) := (div_pos hk hkp).le
  have hs : 0 ≤ (1 - q) / (1 + q) := div_nonneg (by linarith [(terminal_admissible hq).2.1]) (by linarith [hq.1])
  have hlt : terminalK q / (terminalK q + 1) < (1 - q) / (1 + q) :=
    (lt_div_iff₀ (by linarith [hq.1])).mpr (terminal_density_strict hq)
  unfold terminalA
  nlinarith

theorem terminal_constant_zero {q : ℝ} (hq : q ∈ terminalDomain) :
    Real.log (D0q q * q) + terminalK q * Real.log (D0q q) = 0 := by
  rw [log_H_eq hq.1]
  change Real.log (D0q q) + Real.log q + terminalK q * Real.log (D0q q) = 0
  unfold terminalK
  field_simp [(terminal_log_D0_pos hq).ne']
  <;> ring

theorem terminal_GA_eq_E {q v : ℝ} (hq : q ∈ terminalDomain) (hvq : q < v) (hv1 : v ≠ 1) :
    GA (Aq q) q (q / v) = certE (terminalK q) (terminalA q) v := by
  have hq0 := hq.1
  have hv0 := hq0.trans hvq
  have hq1 := (terminal_admissible hq).2.1
  have hq2 : q ^ 2 < v := by nlinarith
  have hnum : 0 < v - q ^ 2 := sub_pos.mpr hq2
  have hden : 0 < |1 - v| := abs_pos.mpr (sub_ne_zero.mpr (Ne.symm hv1))
  have hqv : q / v ≠ 0 := (div_pos hq0 hv0).ne'
  have hratio : (1 - q * (q / v)) / |q / v - q| = ((v - q ^ 2) / |1 - v|) / q := by
    have hab : |q / v - q| = (q / v) * |1 - v| := by
      rw [show q / v - q = (q / v) * (1 - v) by field_simp <;> ring,
        abs_mul, abs_of_pos (div_pos hq0 hv0)]
    rw [hab]
    field_simp [hq0.ne', hv0.ne', hden.ne']
    <;> ring
  unfold GA certE
  rw [terminal_qa hq, terminal_D0 hq, ← terminal_mass_ratio hq, hratio,
    Real.log_div (div_pos hnum hden).ne' hq0.ne', Real.log_div hq0.ne' hv0.ne']
  have hCA := CA_Aq hq0 hq1
  unfold CA at hCA
  rw [← terminal_mass_ratio hq] at hCA
  rw [log_H_eq hq0] at hCA
  change Real.log (D0q q) + Real.log q - terminalK q / (terminalK q + 1) * Real.log q = 0 at hCA
  linear_combination hCA

theorem terminal_Lam_of_roots {q pm pp : ℝ} (hq : q ∈ terminalDomain)
    (hm0 : 0 < pm) (hmq : pm < q) (hqp : q < pp) (hp1 : pp < 1)
    (hGm : GA (Aq q) q pm = 0) (hGp : GA (Aq q) q pp = 0) :
    Stage9.Lam q = D0q q * q * (pm + 1 / pm - pp - 1 / pp) := by
  have hqa := terminal_admissible hq
  have hA := Aq_pos hqa.1 hqa.2.1
  have hAs := (Aq_lt_s_iff hqa.1 hqa.2.1).mpr hqa.2.2
  obtain ⟨m, p, hm0', hmq', hqp', hp1', hGm', hGp', hw⟩ := Lam_eq hqa
  obtain ⟨m0, hm00, hm0q, hmG, hmpos, hmneg⟩ := exists_pminus hqa.1 hqa.2.1 hA hAs 0
  have uniqueM : ∀ z, 0 < z → z < q → GA (Aq q) q z = 0 → z = m0 := by
    intro z hz hzq he
    apply le_antisymm
    · apply le_of_not_gt; intro hh
      have h := (hmpos z hz hzq).mpr hh
      rw [he] at h; exact (lt_irrefl 0) h
    · apply le_of_not_gt; intro hh
      have h := (hmneg z hz hzq).mpr hh
      rw [he] at h; exact (lt_irrefl 0) h
  obtain ⟨p0, hqp0, hp01, hpG, hppos, hpneg⟩ := exists_pplus hqa.1 hqa.2.1 hA hAs (C := 0) le_rfl
  have uniqueP : ∀ z, q < z → z < 1 → GA (Aq q) q z = 0 → z = p0 := by
    intro z hqz hz1 he
    apply le_antisymm
    · apply le_of_not_gt; intro hh
      have h := (hpneg z hqz hz1).mpr hh
      rw [he] at h; exact (lt_irrefl 0) h
    · apply le_of_not_gt; intro hh
      have h := (hppos z hqz hz1).mpr hh
      rw [he] at h; exact (lt_irrefl 0) h
  have em : m = pm := (uniqueM m hm0' hmq' hGm').trans (uniqueM pm hm0 hmq hGm).symm
  have ep : p = pp := (uniqueP p hqp' hp1' hGp').trans (uniqueP pp hqp hp1 hGp).symm
  rwa [em, ep] at hw

theorem terminal_formWidth_eq_Lam {q vp vm : ℝ} (hq : q ∈ terminalDomain)
    (hpq : q < vp) (hp1 : vp < 1) (hm1 : 1 < vm)
    (hEp : certE (terminalK q) (terminalA q) vp = 0)
    (hEm : certE (terminalK q) (terminalA q) vm = 0) :
    formWidth (D0q q) q vp vm = Stage9.Lam q := by
  have hp0 := hq.1.trans hpq
  have hm0 := zero_lt_one.trans hm1
  have hp : q / vp ∈ Ioo q 1 :=
    ⟨(lt_div_iff₀ hp0).mpr (by nlinarith [mul_pos hq.1 (sub_pos.mpr hp1)]),
      (div_lt_one hp0).mpr hpq⟩
  have hm : q / vm ∈ Ioo 0 q :=
    ⟨div_pos hq.1 hm0, (div_lt_iff₀ hm0).mpr (by nlinarith [mul_pos hq.1 (sub_pos.mpr hm1)])⟩
  have hGm : GA (Aq q) q (q / vm) = 0 := by
    rw [terminal_GA_eq_E hq ((terminal_admissible hq).2.1.trans hm1) hm1.ne', hEm]
  have hGp : GA (Aq q) q (q / vp) = 0 := by
    rw [terminal_GA_eq_E hq hpq hp1.ne, hEp]
  rw [terminal_Lam_of_roots hq hm.1 hm.2 hp.1 hp.2 hGm hGp]
  unfold formWidth
  field_simp [hq.1.ne', hp0.ne', hm0.ne']
  <;> ring

theorem scalarPositive_zero_of_formula {k a v0 vp vm : ℝ}
    (hk : 0 < k) (ha : 0 < a) (ha2 : a < 2) (hH : 2 * (k / (k + 1)) ^ 2 ≤ a)
    (hvq : qa a < v0) (hv1 : v0 < 1) (hE0 : certE k a v0 < 0)
    (hp0 : v0 < vp) (hp1 : vp < 1) (hEp : certE k a vp = 0)
    (hm1 : 1 < vm) (hEm : certE k a vm = 0)
    (hf : FormulaPositiveZero k (k / (k + 1)) (qa a) vp vm) :
    let R := referenceOfCertificate hk ha ha2 hH hvq hv1 hE0
    ScalarPositive R 0 := by
  let R := referenceOfCertificate hk ha ha2 hH hvq hv1 hE0
  obtain ⟨hrp, hrm, hap, hw, hx, hc, he⟩ :=
    certificate_formula_dictionary hk ha ha2 hH hvq hv1 hE0 hp0 hp1 hEp hm1 hEm
  have hq := qa_pos ha ha2
  have hvp : 0 < vp := hq.trans (hvq.trans hp0)
  have hm : R.rhoMinus ≤ qa a / vp := by
    rw [hrm]
    exact div_le_div_of_nonneg_left hq.le hvp (hp1.trans hm1).le
  have hr := Rmax_le_rho_bound R (by rw [hrp]) hm
  dsimp only
  intro Q V hQ hV
  have hQ' : Q ∈ Ioc 0 (π / formApi k (qa a)) := by rwa [← hap]
  have hV' : V ∈ Ioc 0 (π * ((1 + qa a / vp) / 2)) := ⟨hV.1, hV.2.trans hr⟩
  have hh := hf Q V hQ' hV'
  rwa [← hc, ← hap] at hh

theorem terminal_ratio_certified_of_box {q pl ph ml mh : ℝ}
    (hq : q ∈ terminalDomain)
    (hql : q < pl) (hph : ph < 1) (hplph : pl < ph) (hml : 1 < ml) (hmlmh : ml < mh)
    (hpl : certE (terminalK q) (terminalA q) pl < 0)
    (hphE : 0 < certE (terminalK q) (terminalA q) ph)
    (hmlE : 0 < certE (terminalK q) (terminalA q) ml)
    (hmhE : certE (terminalK q) (terminalA q) mh < 0)
    (hf : ∀ vp ∈ Ioo pl ph, ∀ vm ∈ Ioo ml mh,
      FormulaPositiveZero (terminalK q) (terminalK q / (terminalK q + 1)) q vp vm) :
    RatioCertified (terminalK q) := by
  have hk := terminalK_pos hq
  have ha := terminal_a_pos hq
  have ha2 := terminal_a_lt_two hq
  have hH := terminal_H1 hq
  have hql' : qa (terminalA q) < pl := by rwa [terminal_qa hq]
  have hpl1 := hplph.trans hph
  let R := referenceOfCertificate hk ha ha2 hH hql' hpl1 hpl
  obtain ⟨vp, hp, he⟩ := certificate_plus_from_separator hk ha ha2 hH hql' hplph hph hpl hphE
  obtain ⟨vm, hm, hem, _⟩ := certificate_minus_bracket hk ha ha2 hH hql' hpl1 hpl hml hmlmh hmlE hmhE
  have hpf : FormulaPositiveZero (terminalK q) (terminalK q / (terminalK q + 1)) (qa (terminalA q)) vp vm := by
    rw [terminal_qa hq]
    exact hf vp hp vm hm
  have hs := scalarPositive_zero_of_formula hk ha ha2 hH hql' hpl1 hpl hp.1 (hp.2.trans hph) he
    (hml.trans hm.1) hem hpf
  obtain ⟨_, _, _, hw, hx, _, hce⟩ :=
    certificate_formula_dictionary hk ha ha2 hH hql' hpl1 hpl hp.1 (hp.2.trans hph) he (hml.trans hm.1) hem
  have hw' : referenceWidth R = Stage9.Lam q := by
    rw [hw, terminal_D0 hq, terminal_qa hq]
    exact terminal_formWidth_eq_Lam hq (hql.trans hp.1) (hp.2.trans hph) (hml.trans hm.1) he hem
  have hc : refConstant R = 0 := by
    change Real.log (R.r / 2) + R.angles.k * Real.log (refD0 R) = 0
    have hr : R.r / 2 = D0a (terminalA q) * qa (terminalA q) := by
      change ((2 - terminalA q) / 2) / 2 = _
      linear_combination -D0a_mul_qa ha
    have hd : refD0 R = D0a (terminalA q) := by
      change ((2 - terminalA q) / 2) / (2 * qa (terminalA q)) = _
      apply (div_eq_iff (mul_pos (by norm_num) (qa_pos ha ha2)).ne').mpr
      linear_combination -2 * D0a_mul_qa ha
    rw [hr, hd, terminal_D0 hq, terminal_qa hq]
    exact terminal_constant_zero hq
  have hC : calibratedCeff R Stage9.Dval ≤ 0 := by
    unfold calibratedCeff
    rw [hc, hw']
    simpa using div_nonpos_of_nonpos_of_nonneg (sub_nonpos.mpr (terminal_width_ge_D hq)) (totalXi_pos R).le
  exact ⟨R, rfl, referenceOfCertificate_platform hk ha ha2 hH hql' hpl1 hpl,
    scalarPositive_mono R hC hs⟩

end EP1038.ReferenceCert
