import LeanProject.COVLogTwo
import LeanProject.COVLogBounds02
open Real Set Finset
namespace EP1038.ReferenceCert
open EP1038.Arc EP1038.Stage11 EP1038.Stage12
set_option maxHeartbeats 4000000
set_option linter.style.longLine false
set_option linter.style.header false
theorem cov_log_480 : RB (Real.log ((226374733 : ℝ) / 50000000)) ((151016873 : ℝ) / 100000000) ((37754219 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((226374733 : ℝ) / 200000000)) (t := ((26374733 : ℝ) / 426374733))
    (lo := ((12387437 : ℝ) / 100000000)) (hi := ((6193719 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((226374733 : ℝ) / 50000000) = Real.log ((226374733 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((226374733 : ℝ) / 50000000) = ((226374733 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_481 : RB (Real.log ((128345599 : ℝ) / 100000000)) ((24955643 : ℝ) / 100000000) ((6238911 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((128345599 : ℝ) / 100000000)) (t := ((28345599 : ℝ) / 228345599))
    (lo := ((24955643 : ℝ) / 100000000)) (hi := ((6238911 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_482 : RB (Real.log ((932597 : ℝ) / 12500000)) ((-6488777 : ℝ) / 2500000) ((-10382043 : ℝ) / 4000000) := by
  have hm := log_bounds_of_series (x := ((932597 : ℝ) / 781250)) (t := ((151347 : ℝ) / 1713847))
    (lo := ((4426949 : ℝ) / 25000000)) (hi := ((17707797 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((932597 : ℝ) / 12500000) = Real.log ((932597 : ℝ) / 781250) - 4 * Real.log 2 := by
    rw [show ((932597 : ℝ) / 12500000) = ((932597 : ℝ) / 781250) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_483 : RB (Real.log ((4297579 : ℝ) / 50000000)) ((-383433 : ℝ) / 156250) ((-61349279 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((4297579 : ℝ) / 6250000)) (t := ((-1952421 : ℝ) / 10547579))
    (lo := ((-37452963 : ℝ) / 100000000)) (hi := ((-18726481 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4297579 : ℝ) / 50000000) = Real.log ((4297579 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4297579 : ℝ) / 50000000) = ((4297579 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_484 : RB (Real.log ((2058297 : ℝ) / 100000000)) ((-388329131 : ℝ) / 100000000) ((-97082281 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2058297 : ℝ) / 1562500)) (t := ((495797 : ℝ) / 3620797))
    (lo := ((27559183 : ℝ) / 100000000)) (hi := ((1722449 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2058297 : ℝ) / 100000000) = Real.log ((2058297 : ℝ) / 1562500) - 6 * Real.log 2 := by
    rw [show ((2058297 : ℝ) / 100000000) = ((2058297 : ℝ) / 1562500) / (2 : ℝ) ^ 6 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_485 : RB (Real.log ((2091909 : ℝ) / 100000000)) ((-386709319 : ℝ) / 100000000) ((-386709313 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2091909 : ℝ) / 3125000)) (t := ((-1033091 : ℝ) / 5216909))
    (lo := ((-10033931 : ℝ) / 25000000)) (hi := ((-40135723 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2091909 : ℝ) / 100000000) = Real.log ((2091909 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2091909 : ℝ) / 100000000) = ((2091909 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_486 : RB (Real.log ((37127641 : ℝ) / 50000000)) ((-1860383 : ℝ) / 6250000) ((-29766127 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37127641 : ℝ) / 50000000)) (t := ((-12872359 : ℝ) / 87127641))
    (lo := ((-1860383 : ℝ) / 6250000)) (hi := ((-29766127 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_487 : RB (Real.log ((18563979 : ℝ) / 25000000)) ((-14882637 : ℝ) / 50000000) ((-29765273 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((18563979 : ℝ) / 25000000)) (t := ((-6436021 : ℝ) / 43563979))
    (lo := ((-14882637 : ℝ) / 50000000)) (hi := ((-29765273 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_488 : RB (Real.log ((8523937 : ℝ) / 20000000)) ((-21321349 : ℝ) / 25000000) ((-42642697 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((8523937 : ℝ) / 10000000)) (t := ((-1476063 : ℝ) / 18523937))
    (lo := ((-15970677 : ℝ) / 100000000)) (hi := ((-3992669 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((8523937 : ℝ) / 20000000) = Real.log ((8523937 : ℝ) / 10000000) - 1 * Real.log 2 := by
    rw [show ((8523937 : ℝ) / 20000000) = ((8523937 : ℝ) / 10000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_489 : RB (Real.log ((97865043 : ℝ) / 50000000)) ((67156641 : ℝ) / 100000000) ((67156643 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((97865043 : ℝ) / 100000000)) (t := ((-2134957 : ℝ) / 197865043))
    (lo := ((-2158077 : ℝ) / 100000000)) (hi := ((-539519 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97865043 : ℝ) / 50000000) = Real.log ((97865043 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97865043 : ℝ) / 50000000) = ((97865043 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_490 : RB (Real.log ((39159049 : ℝ) / 20000000)) ((2687597 : ℝ) / 4000000) ((67189927 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((39159049 : ℝ) / 40000000)) (t := ((-840951 : ℝ) / 79159049))
    (lo := ((-2124793 : ℝ) / 100000000)) (hi := ((-265599 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39159049 : ℝ) / 20000000) = Real.log ((39159049 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39159049 : ℝ) / 20000000) = ((39159049 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_491 : RB (Real.log ((37770881 : ℝ) / 50000000)) ((-5609691 : ℝ) / 20000000) ((-14024227 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((37770881 : ℝ) / 50000000)) (t := ((-12229119 : ℝ) / 87770881))
    (lo := ((-5609691 : ℝ) / 20000000)) (hi := ((-14024227 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_492 : RB (Real.log ((75542401 : ℝ) / 100000000)) ((-28047609 : ℝ) / 100000000) ((-3505951 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((75542401 : ℝ) / 100000000)) (t := ((-24457599 : ℝ) / 175542401))
    (lo := ((-28047609 : ℝ) / 100000000)) (hi := ((-3505951 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_493 : RB (Real.log ((10760051 : ℝ) / 25000000)) ((-42151777 : ℝ) / 50000000) ((-1317243 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((10760051 : ℝ) / 12500000)) (t := ((-1739949 : ℝ) / 23260051))
    (lo := ((-2997767 : ℝ) / 20000000)) (hi := ((-7494417 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10760051 : ℝ) / 25000000) = Real.log ((10760051 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10760051 : ℝ) / 25000000) = ((10760051 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_494 : RB (Real.log ((227147221 : ℝ) / 50000000)) ((30271507 : ℝ) / 20000000) ((75678769 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((227147221 : ℝ) / 200000000)) (t := ((27147221 : ℝ) / 427147221))
    (lo := ((12728099 : ℝ) / 100000000)) (hi := ((127281 : ℝ) / 1000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((227147221 : ℝ) / 50000000) = Real.log ((227147221 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((227147221 : ℝ) / 50000000) = ((227147221 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_495 : RB (Real.log ((454295729 : ℝ) / 100000000)) ((75678909 : ℝ) / 50000000) ((151357821 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((454295729 : ℝ) / 400000000)) (t := ((54295729 : ℝ) / 854295729))
    (lo := ((6364191 : ℝ) / 50000000)) (hi := ((12728383 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((454295729 : ℝ) / 100000000) = Real.log ((454295729 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((454295729 : ℝ) / 100000000) = ((454295729 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_496 : RB (Real.log ((128221789 : ℝ) / 100000000)) ((2485913 : ℝ) / 10000000) ((24859131 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((128221789 : ℝ) / 100000000)) (t := ((28221789 : ℝ) / 228221789))
    (lo := ((2485913 : ℝ) / 10000000)) (hi := ((24859131 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_497 : RB (Real.log ((225990757 : ℝ) / 50000000)) ((150847109 : ℝ) / 100000000) ((18855889 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((225990757 : ℝ) / 200000000)) (t := ((25990757 : ℝ) / 425990757))
    (lo := ((12217673 : ℝ) / 100000000)) (hi := ((6108837 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((225990757 : ℝ) / 50000000) = Real.log ((225990757 : ℝ) / 200000000) + 2 * Real.log 2 := by
    rw [show ((225990757 : ℝ) / 50000000) = ((225990757 : ℝ) / 200000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_498 : RB (Real.log ((451982793 : ℝ) / 100000000)) ((4713981 : ℝ) / 3125000) ((30169479 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((451982793 : ℝ) / 400000000)) (t := ((51982793 : ℝ) / 851982793))
    (lo := ((3054489 : ℝ) / 25000000)) (hi := ((12217957 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((451982793 : ℝ) / 100000000) = Real.log ((451982793 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((451982793 : ℝ) / 100000000) = ((451982793 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_499 : RB (Real.log ((128407239 : ℝ) / 100000000)) ((12501829 : ℝ) / 50000000) ((25003659 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((128407239 : ℝ) / 100000000)) (t := ((28407239 : ℝ) / 228407239))
    (lo := ((12501829 : ℝ) / 50000000)) (hi := ((25003659 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_500 : RB (Real.log ((3749443 : ℝ) / 50000000)) ((-10361663 : ℝ) / 4000000) ((-25904157 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((3749443 : ℝ) / 3125000)) (t := ((624443 : ℝ) / 6874443))
    (lo := ((18217301 : ℝ) / 100000000)) (hi := ((9108651 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((3749443 : ℝ) / 50000000) = Real.log ((3749443 : ℝ) / 3125000) - 4 * Real.log 2 := by
    rw [show ((3749443 : ℝ) / 50000000) = ((3749443 : ℝ) / 3125000) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_501 : RB (Real.log ((269337 : ℝ) / 3125000)) ((-245122621 : ℝ) / 100000000) ((-245122617 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((269337 : ℝ) / 390625)) (t := ((-60644 : ℝ) / 329981))
    (lo := ((-1161827 : ℝ) / 3125000)) (hi := ((-37178463 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((269337 : ℝ) / 3125000) = Real.log ((269337 : ℝ) / 390625) - 3 * Real.log 2 := by
    rw [show ((269337 : ℝ) / 3125000) = ((269337 : ℝ) / 390625) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_502 : RB (Real.log ((130657 : ℝ) / 6250000)) ((-386776123 : ℝ) / 100000000) ((-386776117 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((261314 : ℝ) / 390625)) (t := ((-129311 : ℝ) / 651939))
    (lo := ((-1256329 : ℝ) / 3125000)) (hi := ((-40202527 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((130657 : ℝ) / 6250000) = Real.log ((261314 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((130657 : ℝ) / 6250000) = ((261314 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_503 : RB (Real.log ((1062073 : ℝ) / 50000000)) ((-9629501 : ℝ) / 2500000) ((-192590017 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1062073 : ℝ) / 1562500)) (t := ((-500427 : ℝ) / 2624573))
    (lo := ((-7721289 : ℝ) / 20000000)) (hi := ((-9651611 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1062073 : ℝ) / 50000000) = Real.log ((1062073 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1062073 : ℝ) / 50000000) = ((1062073 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_504 : RB (Real.log ((18517249 : ℝ) / 25000000)) ((-6003463 : ℝ) / 20000000) ((-15008657 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((18517249 : ℝ) / 25000000)) (t := ((-6482751 : ℝ) / 43517249))
    (lo := ((-6003463 : ℝ) / 20000000)) (hi := ((-15008657 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_505 : RB (Real.log ((1851741 : ℝ) / 2500000)) ((-15008223 : ℝ) / 50000000) ((-6003289 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((1851741 : ℝ) / 2500000)) (t := ((-648259 : ℝ) / 4351741))
    (lo := ((-15008223 : ℝ) / 50000000)) (hi := ((-6003289 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_506 : RB (Real.log ((42558489 : ℝ) / 100000000)) ((-42714543 : ℝ) / 50000000) ((-21357271 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((42558489 : ℝ) / 50000000)) (t := ((-7441511 : ℝ) / 92558489))
    (lo := ((-16114367 : ℝ) / 100000000)) (hi := ((-8057183 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42558489 : ℝ) / 100000000) = Real.log ((42558489 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42558489 : ℝ) / 100000000) = ((42558489 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_507 : RB (Real.log ((195664921 : ℝ) / 100000000)) ((33561671 : ℝ) / 50000000) ((4195209 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((195664921 : ℝ) / 200000000)) (t := ((-4335079 : ℝ) / 395664921))
    (lo := ((-136961 : ℝ) / 6250000)) (hi := ((-17531 : ℝ) / 800000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195664921 : ℝ) / 100000000) = Real.log ((195664921 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195664921 : ℝ) / 100000000) = ((195664921 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_508 : RB (Real.log ((48932523 : ℝ) / 25000000)) ((16789161 : ℝ) / 25000000) ((33578323 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((48932523 : ℝ) / 50000000)) (t := ((-1067477 : ℝ) / 98932523))
    (lo := ((-1079037 : ℝ) / 50000000)) (hi := ((-2158073 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((48932523 : ℝ) / 25000000) = Real.log ((48932523 : ℝ) / 50000000) + 1 * Real.log 2 := by
    rw [show ((48932523 : ℝ) / 25000000) = ((48932523 : ℝ) / 50000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_509 : RB (Real.log ((235417 : ℝ) / 312500)) ((-14162303 : ℝ) / 50000000) ((-5664921 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((235417 : ℝ) / 312500)) (t := ((-77083 : ℝ) / 547917))
    (lo := ((-14162303 : ℝ) / 50000000)) (hi := ((-5664921 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_510 : RB (Real.log ((9416761 : ℝ) / 12500000)) ((-14161873 : ℝ) / 50000000) ((-5664749 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((9416761 : ℝ) / 12500000)) (t := ((-3083239 : ℝ) / 21916761))
    (lo := ((-14161873 : ℝ) / 50000000)) (hi := ((-5664749 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_511 : RB (Real.log ((42972737 : ℝ) / 100000000)) ((-84460431 : ℝ) / 100000000) ((-84460429 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((42972737 : ℝ) / 50000000)) (t := ((-7027263 : ℝ) / 92972737))
    (lo := ((-946607 : ℝ) / 6250000)) (hi := ((-15145711 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42972737 : ℝ) / 100000000) = Real.log ((42972737 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42972737 : ℝ) / 100000000) = ((42972737 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_512 : RB (Real.log ((453516603 : ℝ) / 100000000)) ((151186169 : ℝ) / 100000000) ((37796543 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((453516603 : ℝ) / 400000000)) (t := ((53516603 : ℝ) / 853516603))
    (lo := ((12556733 : ℝ) / 100000000)) (hi := ((6278367 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((453516603 : ℝ) / 100000000) = Real.log ((453516603 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((453516603 : ℝ) / 100000000) = ((453516603 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_513 : RB (Real.log ((453517909 : ℝ) / 100000000)) ((151186457 : ℝ) / 100000000) ((7559323 : ℝ) / 5000000) := by
  have hm := log_bounds_of_series (x := ((453517909 : ℝ) / 400000000)) (t := ((53517909 : ℝ) / 853517909))
    (lo := ((12557021 : ℝ) / 100000000)) (hi := ((6278511 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((453517909 : ℝ) / 100000000) = Real.log ((453517909 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((453517909 : ℝ) / 100000000) = ((453517909 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_514 : RB (Real.log ((128283781 : ℝ) / 100000000)) ((12453733 : ℝ) / 50000000) ((24907467 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((128283781 : ℝ) / 100000000)) (t := ((28283781 : ℝ) / 228283781))
    (lo := ((12453733 : ℝ) / 50000000)) (hi := ((24907467 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_515 : RB (Real.log ((112805067 : ℝ) / 25000000)) ((150678543 : ℝ) / 100000000) ((75339273 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((112805067 : ℝ) / 100000000)) (t := ((12805067 : ℝ) / 212805067))
    (lo := ((12049107 : ℝ) / 100000000)) (hi := ((3012277 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((112805067 : ℝ) / 25000000) = Real.log ((112805067 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((112805067 : ℝ) / 25000000) = ((112805067 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_516 : RB (Real.log ((90244313 : ℝ) / 20000000)) ((15067883 : ℝ) / 10000000) ((150678833 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((90244313 : ℝ) / 80000000)) (t := ((10244313 : ℝ) / 170244313))
    (lo := ((6024697 : ℝ) / 50000000)) (hi := ((2409879 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((90244313 : ℝ) / 20000000) = Real.log ((90244313 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((90244313 : ℝ) / 20000000) = ((90244313 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_517 : RB (Real.log ((25693741 : ℝ) / 20000000)) ((12525757 : ℝ) / 50000000) ((5010303 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((25693741 : ℝ) / 20000000)) (t := ((5693741 : ℝ) / 45693741))
    (lo := ((12525757 : ℝ) / 50000000)) (hi := ((5010303 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_518 : RB (Real.log ((1884579 : ℝ) / 25000000)) ((-258517141 : ℝ) / 100000000) ((-16157321 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((1884579 : ℝ) / 1562500)) (t := ((322079 : ℝ) / 3447079))
    (lo := ((3748347 : ℝ) / 20000000)) (hi := ((2342717 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1884579 : ℝ) / 25000000) = Real.log ((1884579 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((1884579 : ℝ) / 25000000) = ((1884579 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_519 : RB (Real.log ((4322039 : ℝ) / 50000000)) ((-30603697 : ℝ) / 12500000) ((-61207393 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((4322039 : ℝ) / 6250000)) (t := ((-1927961 : ℝ) / 10572039))
    (lo := ((-36885419 : ℝ) / 100000000)) (hi := ((-18442709 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((4322039 : ℝ) / 50000000) = Real.log ((4322039 : ℝ) / 6250000) - 3 * Real.log 2 := by
    rw [show ((4322039 : ℝ) / 50000000) = ((4322039 : ℝ) / 6250000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_520 : RB (Real.log ((2122729 : ℝ) / 100000000)) ((-385246771 : ℝ) / 100000000) ((-77049353 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((2122729 : ℝ) / 3125000)) (t := ((-1002271 : ℝ) / 5247729))
    (lo := ((-4834147 : ℝ) / 12500000)) (hi := ((-1546927 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2122729 : ℝ) / 100000000) = Real.log ((2122729 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2122729 : ℝ) / 100000000) = ((2122729 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_521 : RB (Real.log ((67387 : ℝ) / 3125000)) ((-383673749 : ℝ) / 100000000) ((-383673743 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((269548 : ℝ) / 390625)) (t := ((-121077 : ℝ) / 660173))
    (lo := ((-18550077 : ℝ) / 50000000)) (hi := ((-37100153 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((67387 : ℝ) / 3125000) = Real.log ((269548 : ℝ) / 390625) - 5 * Real.log 2 := by
    rw [show ((67387 : ℝ) / 3125000) = ((269548 : ℝ) / 390625) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_522 : RB (Real.log ((73885761 : ℝ) / 100000000)) ((-15132503 : ℝ) / 50000000) ((-6053001 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((73885761 : ℝ) / 100000000)) (t := ((-26114239 : ℝ) / 173885761))
    (lo := ((-15132503 : ℝ) / 50000000)) (hi := ((-6053001 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_523 : RB (Real.log ((36943207 : ℝ) / 50000000)) ((-15132061 : ℝ) / 50000000) ((-30264121 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36943207 : ℝ) / 50000000)) (t := ((-13056793 : ℝ) / 86943207))
    (lo := ((-15132061 : ℝ) / 50000000)) (hi := ((-30264121 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_524 : RB (Real.log ((21249087 : ℝ) / 50000000)) ((-85570909 : ℝ) / 100000000) ((-85570907 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((21249087 : ℝ) / 25000000)) (t := ((-3750913 : ℝ) / 46249087))
    (lo := ((-1625619 : ℝ) / 10000000)) (hi := ((-16256189 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((21249087 : ℝ) / 50000000) = Real.log ((21249087 : ℝ) / 25000000) - 1 * Real.log 2 := by
    rw [show ((21249087 : ℝ) / 50000000) = ((21249087 : ℝ) / 25000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_525 : RB (Real.log ((97799871 : ℝ) / 50000000)) ((2683601 : ℝ) / 4000000) ((67090027 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((97799871 : ℝ) / 100000000)) (t := ((-2200129 : ℝ) / 197799871))
    (lo := ((-2224693 : ℝ) / 100000000)) (hi := ((-556173 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((97799871 : ℝ) / 50000000) = Real.log ((97799871 : ℝ) / 100000000) + 1 * Real.log 2 := by
    rw [show ((97799871 : ℝ) / 50000000) = ((97799871 : ℝ) / 100000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_526 : RB (Real.log ((7826597 : ℝ) / 4000000)) ((4195209 : ℝ) / 6250000) ((33561673 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((7826597 : ℝ) / 8000000)) (t := ((-173403 : ℝ) / 15826597))
    (lo := ((-1095687 : ℝ) / 50000000)) (hi := ((-2191373 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((7826597 : ℝ) / 4000000) = Real.log ((7826597 : ℝ) / 8000000) + 1 * Real.log 2 := by
    rw [show ((7826597 : ℝ) / 4000000) = ((7826597 : ℝ) / 8000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_527 : RB (Real.log ((37564379 : ℝ) / 50000000)) ((-14298339 : ℝ) / 50000000) ((-28596677 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((37564379 : ℝ) / 50000000)) (t := ((-12435621 : ℝ) / 87564379))
    (lo := ((-14298339 : ℝ) / 50000000)) (hi := ((-28596677 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_528 : RB (Real.log ((9391177 : ℝ) / 12500000)) ((-14297901 : ℝ) / 50000000) ((-28595801 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((9391177 : ℝ) / 12500000)) (t := ((-3108823 : ℝ) / 21891177))
    (lo := ((-14297901 : ℝ) / 50000000)) (hi := ((-28595801 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_529 : RB (Real.log ((429063 : ℝ) / 1000000)) ((-84615153 : ℝ) / 100000000) ((-84615151 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((429063 : ℝ) / 500000)) (t := ((-70937 : ℝ) / 929063))
    (lo := ((-7650217 : ℝ) / 50000000)) (hi := ((-15300433 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((429063 : ℝ) / 1000000) = Real.log ((429063 : ℝ) / 500000) - 1 * Real.log 2 := by
    rw [show ((429063 : ℝ) / 1000000) = ((429063 : ℝ) / 500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_530 : RB (Real.log ((113186087 : ℝ) / 25000000)) ((75507871 : ℝ) / 50000000) ((30203149 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((113186087 : ℝ) / 100000000)) (t := ((13186087 : ℝ) / 213186087))
    (lo := ((6193153 : ℝ) / 50000000)) (hi := ((12386307 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((113186087 : ℝ) / 25000000) = Real.log ((113186087 : ℝ) / 100000000) + 2 * Real.log 2 := by
    rw [show ((113186087 : ℝ) / 25000000) = ((113186087 : ℝ) / 100000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_531 : RB (Real.log ((56593209 : ℝ) / 12500000)) ((30203207 : ℝ) / 20000000) ((75508019 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((56593209 : ℝ) / 50000000)) (t := ((6593209 : ℝ) / 106593209))
    (lo := ((12386599 : ℝ) / 100000000)) (hi := ((61933 : ℝ) / 500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((56593209 : ℝ) / 12500000) = Real.log ((56593209 : ℝ) / 50000000) + 2 * Real.log 2 := by
    rw [show ((56593209 : ℝ) / 12500000) = ((56593209 : ℝ) / 50000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_532 : RB (Real.log ((32086399 : ℝ) / 25000000)) ((623891 : ℝ) / 2500000) ((24955641 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((32086399 : ℝ) / 25000000)) (t := ((7086399 : ℝ) / 57086399))
    (lo := ((623891 : ℝ) / 2500000)) (hi := ((24955641 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_533 : RB (Real.log ((90092881 : ℝ) / 20000000)) ((150510887 : ℝ) / 100000000) ((15051089 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((90092881 : ℝ) / 80000000)) (t := ((10092881 : ℝ) / 170092881))
    (lo := ((11881451 : ℝ) / 100000000)) (hi := ((2970363 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((90092881 : ℝ) / 20000000) = Real.log ((90092881 : ℝ) / 80000000) + 2 * Real.log 2 := by
    rw [show ((90092881 : ℝ) / 20000000) = ((90092881 : ℝ) / 80000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_534 : RB (Real.log ((450465721 : ℝ) / 100000000)) ((150511179 : ℝ) / 100000000) ((75255591 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((450465721 : ℝ) / 400000000)) (t := ((50465721 : ℝ) / 850465721))
    (lo := ((11881743 : ℝ) / 100000000)) (hi := ((742609 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((450465721 : ℝ) / 100000000) = Real.log ((450465721 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((450465721 : ℝ) / 100000000) = ((450465721 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_535 : RB (Real.log ((64264999 : ℝ) / 50000000)) ((25099213 : ℝ) / 100000000) ((12549607 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((64264999 : ℝ) / 50000000)) (t := ((14264999 : ℝ) / 114264999))
    (lo := ((25099213 : ℝ) / 100000000)) (hi := ((12549607 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_536 : RB (Real.log ((378951 : ℝ) / 5000000)) ((-257978633 : ℝ) / 100000000) ((-64494657 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((378951 : ℝ) / 312500)) (t := ((66451 : ℝ) / 691451))
    (lo := ((19280243 : ℝ) / 100000000)) (hi := ((4820061 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((378951 : ℝ) / 5000000) = Real.log ((378951 : ℝ) / 312500) - 4 * Real.log 2 := by
    rw [show ((378951 : ℝ) / 5000000) = ((378951 : ℝ) / 312500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_537 : RB (Real.log ((2167749 : ℝ) / 25000000)) ((-955151 : ℝ) / 390625) ((-61129663 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2167749 : ℝ) / 3125000)) (t := ((-957251 : ℝ) / 5292749))
    (lo := ((-36574499 : ℝ) / 100000000)) (hi := ((-18287249 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2167749 : ℝ) / 25000000) = Real.log ((2167749 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((2167749 : ℝ) / 25000000) = ((2167749 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_538 : RB (Real.log ((430989 : ℝ) / 20000000)) ((-47967563 : ℝ) / 12500000) ((-191870249 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((430989 : ℝ) / 625000)) (t := ((-194011 : ℝ) / 1055989))
    (lo := ((-37166909 : ℝ) / 100000000)) (hi := ((-9291727 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((430989 : ℝ) / 20000000) = Real.log ((430989 : ℝ) / 625000) - 5 * Real.log 2 := by
    rw [show ((430989 : ℝ) / 20000000) = ((430989 : ℝ) / 625000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_539 : RB (Real.log ((1094311 : ℝ) / 50000000)) ((-95547453 : ℝ) / 25000000) ((-191094903 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((1094311 : ℝ) / 1562500)) (t := ((-468189 : ℝ) / 2656811))
    (lo := ((-35616217 : ℝ) / 100000000)) (hi := ((-4452027 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1094311 : ℝ) / 50000000) = Real.log ((1094311 : ℝ) / 1562500) - 5 * Real.log 2 := by
    rw [show ((1094311 : ℝ) / 50000000) = ((1094311 : ℝ) / 1562500) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_540 : RB (Real.log ((14741097 : ℝ) / 20000000)) ((-30509297 : ℝ) / 100000000) ((-1906831 : ℝ) / 6250000) := by
  have hm := log_bounds_of_series (x := ((14741097 : ℝ) / 20000000)) (t := ((-5258903 : ℝ) / 34741097))
    (lo := ((-30509297 : ℝ) / 100000000)) (hi := ((-1906831 : ℝ) / 6250000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_541 : RB (Real.log ((18426537 : ℝ) / 25000000)) ((-15254199 : ℝ) / 50000000) ((-30508397 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((18426537 : ℝ) / 25000000)) (t := ((-6573463 : ℝ) / 43426537))
    (lo := ((-15254199 : ℝ) / 50000000)) (hi := ((-30508397 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_542 : RB (Real.log ((10609679 : ℝ) / 25000000)) ((-42855457 : ℝ) / 50000000) ((-1339233 : ℝ) / 1562500) := by
  have hm := log_bounds_of_series (x := ((10609679 : ℝ) / 12500000)) (t := ((-1890321 : ℝ) / 23109679))
    (lo := ((-3279239 : ℝ) / 20000000)) (hi := ((-8198097 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((10609679 : ℝ) / 25000000) = Real.log ((10609679 : ℝ) / 12500000) - 1 * Real.log 2 := by
    rw [show ((10609679 : ℝ) / 25000000) = ((10609679 : ℝ) / 12500000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_543 : RB (Real.log ((39106911 : ℝ) / 20000000)) ((16764173 : ℝ) / 25000000) ((33528347 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((39106911 : ℝ) / 40000000)) (t := ((-893089 : ℝ) / 79106911))
    (lo := ((-1129013 : ℝ) / 50000000)) (hi := ((-90321 : ℝ) / 4000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((39106911 : ℝ) / 20000000) = Real.log ((39106911 : ℝ) / 40000000) + 1 * Real.log 2 := by
    rw [show ((39106911 : ℝ) / 20000000) = ((39106911 : ℝ) / 40000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_544 : RB (Real.log ((195599749 : ℝ) / 100000000)) ((16772507 : ℝ) / 25000000) ((6709003 : ℝ) / 10000000) := by
  have hm := log_bounds_of_series (x := ((195599749 : ℝ) / 200000000)) (t := ((-4400251 : ℝ) / 395599749))
    (lo := ((-222469 : ℝ) / 10000000)) (hi := ((-2224689 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((195599749 : ℝ) / 100000000) = Real.log ((195599749 : ℝ) / 200000000) + 1 * Real.log 2 := by
    rw [show ((195599749 : ℝ) / 100000000) = ((195599749 : ℝ) / 200000000) * (2 : ℝ) ^ 1 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_545 : RB (Real.log ((3746381 : ℝ) / 5000000)) ((-28864761 : ℝ) / 100000000) ((-721619 : ℝ) / 2500000) := by
  have hm := log_bounds_of_series (x := ((3746381 : ℝ) / 5000000)) (t := ((-1253619 : ℝ) / 8746381))
    (lo := ((-28864761 : ℝ) / 100000000)) (hi := ((-721619 : ℝ) / 2500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_546 : RB (Real.log ((2341509 : ℝ) / 3125000)) ((-28863869 : ℝ) / 100000000) ((-7215967 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((2341509 : ℝ) / 3125000)) (t := ((-783491 : ℝ) / 5466509))
    (lo := ((-28863869 : ℝ) / 100000000)) (hi := ((-7215967 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_547 : RB (Real.log ((42840869 : ℝ) / 100000000)) ((-84767767 : ℝ) / 100000000) ((-16953553 : ℝ) / 20000000) := by
  have hm := log_bounds_of_series (x := ((42840869 : ℝ) / 50000000)) (t := ((-7159131 : ℝ) / 92840869))
    (lo := ((-1931631 : ℝ) / 12500000)) (hi := ((-15453047 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((42840869 : ℝ) / 100000000) = Real.log ((42840869 : ℝ) / 50000000) - 1 * Real.log 2 := by
    rw [show ((42840869 : ℝ) / 100000000) = ((42840869 : ℝ) / 50000000) / (2 : ℝ) ^ 1 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_548 : RB (Real.log ((451977601 : ℝ) / 100000000)) ((150846243 : ℝ) / 100000000) ((75423123 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((451977601 : ℝ) / 400000000)) (t := ((51977601 : ℝ) / 851977601))
    (lo := ((12216807 : ℝ) / 100000000)) (hi := ((1527101 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((451977601 : ℝ) / 100000000) = Real.log ((451977601 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((451977601 : ℝ) / 100000000) = ((451977601 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_549 : RB (Real.log ((451978943 : ℝ) / 100000000)) ((7542327 : ℝ) / 5000000) ((150846543 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((451978943 : ℝ) / 400000000)) (t := ((51978943 : ℝ) / 851978943))
    (lo := ((763569 : ℝ) / 6250000)) (hi := ((2443421 : ℝ) / 20000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((451978943 : ℝ) / 100000000) = Real.log ((451978943 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((451978943 : ℝ) / 100000000) = ((451978943 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_550 : RB (Real.log ((32101809 : ℝ) / 25000000)) ((5000731 : ℝ) / 20000000) ((3125457 : ℝ) / 12500000) := by
  have hm := log_bounds_of_series (x := ((32101809 : ℝ) / 25000000)) (t := ((7101809 : ℝ) / 57101809))
    (lo := ((5000731 : ℝ) / 20000000)) (hi := ((3125457 : ℝ) / 12500000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_551 : RB (Real.log ((449713879 : ℝ) / 100000000)) ((18793017 : ℝ) / 12500000) ((150344139 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((449713879 : ℝ) / 400000000)) (t := ((49713879 : ℝ) / 849713879))
    (lo := ((117147 : ℝ) / 1000000)) (hi := ((11714701 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((449713879 : ℝ) / 100000000) = Real.log ((449713879 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((449713879 : ℝ) / 100000000) = ((449713879 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_552 : RB (Real.log ((449715213 : ℝ) / 100000000)) ((150344433 : ℝ) / 100000000) ((37586109 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((449715213 : ℝ) / 400000000)) (t := ((49715213 : ℝ) / 849715213))
    (lo := ((11714997 : ℝ) / 100000000)) (hi := ((5857499 : ℝ) / 50000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((449715213 : ℝ) / 100000000) = Real.log ((449715213 : ℝ) / 400000000) + 2 * Real.log 2 := by
    rw [show ((449715213 : ℝ) / 100000000) = ((449715213 : ℝ) / 400000000) * (2 : ℝ) ^ 2 by norm_num, Real.log_mul (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_553 : RB (Real.log ((64295559 : ℝ) / 50000000)) ((5029351 : ℝ) / 20000000) ((6286689 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((64295559 : ℝ) / 50000000)) (t := ((14295559 : ℝ) / 114295559))
    (lo := ((5029351 : ℝ) / 20000000)) (hi := ((6286689 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_554 : RB (Real.log ((1905239 : ℝ) / 25000000)) ((-257426841 : ℝ) / 100000000) ((-64356709 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((1905239 : ℝ) / 1562500)) (t := ((342739 : ℝ) / 3467739))
    (lo := ((3966407 : ℝ) / 20000000)) (hi := ((4958009 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((1905239 : ℝ) / 25000000) = Real.log ((1905239 : ℝ) / 1562500) - 4 * Real.log 2 := by
    rw [show ((1905239 : ℝ) / 25000000) = ((1905239 : ℝ) / 1562500) / (2 : ℝ) ^ 4 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_555 : RB (Real.log ((2174871 : ℝ) / 25000000)) ((-244190651 : ℝ) / 100000000) ((-244190647 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((2174871 : ℝ) / 3125000)) (t := ((-950129 : ℝ) / 5299871))
    (lo := ((-18123247 : ℝ) / 50000000)) (hi := ((-36246493 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2174871 : ℝ) / 25000000) = Real.log ((2174871 : ℝ) / 3125000) - 3 * Real.log 2 := by
    rw [show ((2174871 : ℝ) / 25000000) = ((2174871 : ℝ) / 3125000) / (2 : ℝ) ^ 3 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_556 : RB (Real.log ((2187159 : ℝ) / 100000000)) ((-9556417 : ℝ) / 2500000) ((-191128337 : ℝ) / 50000000) := by
  have hm := log_bounds_of_series (x := ((2187159 : ℝ) / 3125000)) (t := ((-937841 : ℝ) / 5312159))
    (lo := ((-7136617 : ℝ) / 20000000)) (hi := ((-8920771 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((2187159 : ℝ) / 100000000) = Real.log ((2187159 : ℝ) / 3125000) - 5 * Real.log 2 := by
    rw [show ((2187159 : ℝ) / 100000000) = ((2187159 : ℝ) / 3125000) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_557 : RB (Real.log ((111043 : ℝ) / 5000000)) ((-380727573 : ℝ) / 100000000) ((-380727567 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((111043 : ℝ) / 156250)) (t := ((-45207 : ℝ) / 267293))
    (lo := ((-17076989 : ℝ) / 50000000)) (hi := ((-34153977 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  have he : Real.log ((111043 : ℝ) / 5000000) = Real.log ((111043 : ℝ) / 156250) - 5 * Real.log 2 := by
    rw [show ((111043 : ℝ) / 5000000) = ((111043 : ℝ) / 156250) / (2 : ℝ) ^ 5 by norm_num, Real.log_div (by norm_num) (by norm_num), Real.log_pow]
    norm_num
  rw [he]
  constructor <;> linarith [hm.1, hm.2, cov_log_two.1, cov_log_two.2]

theorem cov_log_558 : RB (Real.log ((73528089 : ℝ) / 100000000)) ((-30750269 : ℝ) / 100000000) ((-7687567 : ℝ) / 25000000) := by
  have hm := log_bounds_of_series (x := ((73528089 : ℝ) / 100000000)) (t := ((-26471911 : ℝ) / 173528089))
    (lo := ((-30750269 : ℝ) / 100000000)) (hi := ((-7687567 : ℝ) / 25000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm

theorem cov_log_559 : RB (Real.log ((36764381 : ℝ) / 50000000)) ((-15374677 : ℝ) / 50000000) ((-30749353 : ℝ) / 100000000) := by
  have hm := log_bounds_of_series (x := ((36764381 : ℝ) / 50000000)) (t := ((-13235619 : ℝ) / 86764381))
    (lo := ((-15374677 : ℝ) / 50000000)) (hi := ((-30749353 : ℝ) / 100000000)) (by norm_num) (by norm_num) 8
    (by norm_num [sum_range_succ]) (by norm_num [sum_range_succ])
  exact hm
end EP1038.ReferenceCert
