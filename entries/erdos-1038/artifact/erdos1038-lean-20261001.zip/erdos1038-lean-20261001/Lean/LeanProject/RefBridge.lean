import LeanProject.RefPositivity

/-!
# EP-1038, Stage 12, Lemma 12.2(c): `√(2a)/d(θ) = P_{ρ₀}(θ)`

* `Pq_eq_div`: `P_q(θ) = (1 - q²) D₀ / d(θ)` with `d(θ) = D₀(1 - 2q cos θ + q²)`.
* `sqrt2a_eq`: `(1 - q(a)²) D₀(a) = √(2a)` for `0 < a < 2`.
* `Pq_eq_sqrt` (**Lemma 12.2(c)**): `P_{q(a)}(θ) = √(2a)/d(θ)`, with `d(θ) = (a+2)/2 - ((2-a)/2) cos θ`.
* `alpha_eq_paper`: `α(θ) = k + 1 - k √(2a)/d(θ)`, the paper's definition of `α` in (H1).
-/

open Real

namespace EP1038.Arc

theorem Pq_eq_div {D0 q : ℝ} (hD : 0 < D0) (θ : ℝ) :
    Pq q θ = (1 - q ^ 2) * D0 / dth D0 q θ := by
  unfold Pq dth
  rw [mul_comm (1 - q ^ 2) D0, mul_div_mul_left _ _ hD.ne']

theorem sqrt2a_eq {a : ℝ} (ha0 : 0 < a) (_ha2 : a < 2) : (1 - qa a ^ 2) * D0a a = √(2 * a) := by
  have hs := Real.sqrt_pos.mpr ha0
  have h2 := Real.sqrt_pos.mpr (show (0 : ℝ) < 2 by norm_num)
  have hsa : √a ^ 2 = a := Real.sq_sqrt ha0.le
  have hs2 : √2 ^ 2 = 2 := Real.sq_sqrt (by norm_num)
  have hne : √2 + √a ≠ 0 := by linarith
  have hm : √(2 * a) = √2 * √a := Real.sqrt_mul (by norm_num) a
  unfold qa D0a
  rw [hm, show (1 - ((√2 - √a) / (√2 + √a)) ^ 2) * ((√a + √2) / 2) ^ 2 =
      ((√2 + √a) ^ 2 - (√2 - √a) ^ 2) / 4 by field_simp; ring]
  ring

/-- **Lemma 12.2(c)**: `√(2a)/d(θ) = P_{ρ₀}(θ)`. -/
theorem Pq_eq_sqrt {a : ℝ} (ha0 : 0 < a) (ha2 : a < 2) (θ : ℝ) :
    Pq (qa a) θ = √(2 * a) / ((a + 2) / 2 - ((2 - a) / 2) * Real.cos θ) := by
  rw [Pq_eq_div (D0a_pos ha0) θ, sqrt2a_eq ha0 ha2,
    dth_a ha0 θ]

/-- The paper's `α(θ) = k + 1 - k √(2a)/d(θ)` equals `alpha k ρ₀ θ`. -/
theorem alpha_eq_paper {a : ℝ} (ha0 : 0 < a) (ha2 : a < 2) (k θ : ℝ) :
    alpha k (qa a) θ = k + 1 - k * √(2 * a) / ((a + 2) / 2 - ((2 - a) / 2) * Real.cos θ) := by
  unfold alpha
  rw [Pq_eq_sqrt ha0 ha2 θ]
  ring

end EP1038.Arc
