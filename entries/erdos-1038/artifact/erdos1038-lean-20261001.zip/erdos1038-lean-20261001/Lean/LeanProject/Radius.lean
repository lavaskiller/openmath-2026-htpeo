import LeanProject.Atomization

/-!
# EP-1038: the residual component radius (Stage 15, fifth batch)

proof.md Lemma 7.5(b): on a residual component `(ℓ, r)` containing the cluster `d`, the background
`H` (the potential with the self-pole removed) is concave, and the boundary equations
`H ℓ = -q log (d - ℓ)`, `H r = -q log (r - d)`, `H d = -q log R` hold. Then `r - ℓ ≥ 2 R`.
This file proves that implication for an arbitrary concave `H`.
-/

open Real

namespace EP1038

theorem radius_bound {H : ℝ → ℝ} {l d r q R : ℝ} (hl : l < d) (hr : d < r) (hq : 0 < q)
    (hR : 0 < R) (hH : ConcaveOn ℝ (Set.Icc l r) H)
    (h1 : H l = -q * Real.log (d - l)) (h2 : H r = -q * Real.log (r - d))
    (h3 : H d = -q * Real.log R) : 2 * R ≤ r - l := by
  set s := d - l with hs
  set u := r - d with hu
  set T := r - l with hT
  have hs0 : 0 < s := by linarith
  have hu0 : 0 < u := by linarith
  have hT0 : 0 < T := by linarith
  set w := s / T with hw
  have hw0 : 0 ≤ w := by positivity
  have hw1 : w ≤ 1 := by rw [hw, div_le_one hT0]; linarith
  have hsw : s = w * T := by rw [hw]; field_simp
  have huw : u = (1 - w) * T := by rw [hw]; field_simp; linarith
  -- concavity at d = (1 - w) l + w r
  have hd : (1 - w) • l + w • r = d := by
    simp only [smul_eq_mul]
    have : (1 - w) * l + w * r = l + w * T := by ring
    rw [this, ← hsw]; linarith
  have hconc := hH.2 (Set.left_mem_Icc.mpr (by linarith)) (Set.right_mem_Icc.mpr (by linarith))
    (by linarith : (0:ℝ) ≤ 1 - w) hw0 (by ring)
  rw [hd] at hconc
  simp only [smul_eq_mul] at hconc
  rw [h1, h2, h3] at hconc
  -- log R ≤ (1 - w) log s + w log u
  have hlog : Real.log R ≤ (1 - w) * Real.log s + w * Real.log u := by nlinarith
  -- exponentiate
  have hexp : R ≤ s ^ (1 - w) * u ^ w := by
    have : Real.log R ≤ Real.log (s ^ (1 - w) * u ^ w) := by
      rw [Real.log_mul (by positivity) (by positivity), Real.log_rpow hs0, Real.log_rpow hu0]
      exact hlog
    exact (Real.log_le_log_iff hR (by positivity)).mp this
  have hfac : s ^ (1 - w) * u ^ w = T * (w ^ (1 - w) * (1 - w) ^ w) := by
    rw [hsw, huw, Real.mul_rpow hw0 hT0.le, Real.mul_rpow (by linarith) hT0.le]
    have hTT : T ^ (1 - w) * T ^ w = T := by
      rw [← Real.rpow_add hT0]; simp
    calc w ^ (1 - w) * T ^ (1 - w) * ((1 - w) ^ w * T ^ w)
        = (T ^ (1 - w) * T ^ w) * (w ^ (1 - w) * (1 - w) ^ w) := by ring
      _ = T * (w ^ (1 - w) * (1 - w) ^ w) := by rw [hTT]
  have hamgm := amgm_radius hw0 hw1
  rw [hfac] at hexp
  nlinarith

end EP1038
