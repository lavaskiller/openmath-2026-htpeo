# Lean project for Erdős 1038

Use the pinned `lean-toolchain` and `lake-manifest.json`. From the archive root run
`sh scripts/build.sh`. The theorem entrypoint is [Submission.lean](LeanProject/Submission.lean).
The project root imports every proof module packaged here.

See [the package README](../README.md) and [statement correspondence](../STATEMENT_CORRESPONDENCE.md).
