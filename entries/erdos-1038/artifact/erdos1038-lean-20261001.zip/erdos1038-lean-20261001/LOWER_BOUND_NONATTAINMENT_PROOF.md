# Universal lower bound and finite-degree nonattainment for Erdős problem 1038

Prepared 30 September 2026 from the current [EP1038_paper.md](EP1038_paper.md), with the corrections and limits recorded in [INFORMAL_AUDIT.md](INFORMAL_AUDIT.md) and the later [Lean build verification](Lean/LEAN_BUILD_VERIFICATION.md).

Let \(\mathcal P\) be the class of nonconstant monic polynomials in \(\mathbb R[x]\) whose roots, counted with multiplicity, are all real and belong to \([-1,1]\). Write
\[
S_f=\{x\in\mathbb R:|f(x)|<1\},\qquad M(f)=\operatorname{meas}(S_f).
\]
We prove **\(M(f)>D\) for every \(f\in\mathcal P\)** and then derive the two claims \(M(f)\ge D\) and \(M(f)\ne D\). The proof is computer-assisted: the precise interval-certified inputs are isolated below. No polynomial lower bound is assumed in establishing those inputs.

The numbered lemmas, propositions, theorems and equation labels in the extracted proof retain their original identifiers from **EP1038_paper.md**. In particular, a reference to a numbered section or result means the paper's reference; descriptive headings added here are unnumbered. All mathematical arguments needed from those results are included here. Literature attributions are not additional premises.

The proof of the supremum and the construction establishing \(\inf_f M(f)\le D\) are outside this document. The latter would establish sharpness when combined with the lower theorem; it is not needed for either of the two claims proved here.

## Preliminary facts and logarithmic conventions

**Source:** paper §1.1 and Lemma 1.2; §3 notation and Lemma 3.1.

If \(f(x)=\prod_{j=1}^n(x-r_j)\), then \(n\ge1\), \(r_j\in[-1,1]\), and
\[
\mu_f=\frac1n\sum_{j=1}^n\delta_{r_j},\qquad
V_{\mu_f}(x)=\int\log|x-t|\,d\mu_f(t)=\frac1n\log|f(x)|.
\]
At an atom use the extended value \(\log0=-\infty\). For compactly supported finite positive measures every logarithmic integral here has bounded positive part on compact observation intervals, so the extended integral is well defined. Thus \(S_f=\{V_{\mu_f}<0\}\), including the roots.

For \(|x|\ge2\), each factor \(|x-r_j|\ge1\); hence \(S_f\subset(-2,2)\). The boundary lies in the zero set of \(f^2-1\), a nonzero polynomial because \(n\ge1\). Consequently \(S_f\) is a finite disjoint union of bounded open intervals; its endpoints satisfy \(|f|=1\). The strict inequality matters at a contact point: a point with potential zero is excluded and can separate two open components even when their closures meet. The arguments below consistently use this convention.

## Exact definition of the constant

**Source:** paper Lemmas 5.1–5.2 and Definition 5.3.

For \(0<q<1\), set
\[
s(q)=\frac{1-q}{1+q},\qquad H(q)=\frac{2q}{(1+q)^2},\qquad
\mathfrak f(q)=(1+q)\log\frac{2}{(1+q)^2}+2q\log q.
\]
The threshold \(q_s\) is the unique zero of \(\mathfrak f\) in \((0,1)\). To check existence and uniqueness rather than assume them, differentiate:
\[
\mathfrak f'(q)=\log\frac{2q^2}{(1+q)^2}<0,\qquad
\mathfrak f(0+)=\log2>0,\qquad \mathfrak f(1)=-2\log2<0.
\]
Continuity and strict monotonicity prove the assertion. Also
\(\mathfrak f(\sqrt2-1)=2(\sqrt2-1)\log(\sqrt2-1)<0\), so
\(q_s<\sqrt2-1\). Define
\[
A(q)=\frac{\log H(q)}{\log q}\quad(0<q<q_s).
\]
Since \(q<H(q)<1\) in this range, \(0<A(q)<1\). With
\(d_q=\log(2/(1+q)^2)>0\) and \(\tau=\log(1/q)>0\),
\[
A(q)=1-\frac{d_q}{\tau},\qquad
A(q)<s(q)\iff(1+q)d_q-2q\tau=\mathfrak f(q)>0.
\]
The following calculation defines the reference probability measure and its negative-potential width, including the two roots used to define \(\Lambda\).

### Lemma 5.1 (arcsine measure, balayage of $\delta_{-1}$, exterior potentials)

**Source:** paper Lemma 5.1.

Fix $s\in(0,1)$. Put $a^\circ=2s^2-1$, $c_0=s^2$, $\ell=1-s^2$ (so $[a^\circ,1]=[c_0-\ell,c_0+\ell]$), $q=\frac{1-s}{1+s}$, and $H=\ell/2=\frac{2q}{(1+q)^2}$. Parametrize $t=c_0+\ell\cos\theta$, $\theta\in[0,\pi]$. Let $\omega$ be the arcsine probability measure on $[a^\circ,1]$ ($d\omega=d\theta/\pi$) and $\omega_{-1}:=\frac{2s}{t+1}\,\omega$.

- (i) $\frac{2s}{t+1}=\Pi(\theta):=\frac{1-q^2}{1+2q\cos\theta+q^2}=1+2\sum_{n\ge1}(-1)^nq^n\cos n\theta$. In particular $\omega_{-1}$ is a probability measure.
- (ii) For $x\in[a^\circ,1]$: $V_\omega(x)=\log H$ and $V_{\omega_{-1}}(x)=\log(x+1)+\log q$.
- (iii) For $x<a^\circ$, write $x=c_0-H(u+u^{-1})$ with a unique $u>1$. Then $V_\omega(x)=\log(Hu)$, $V_{\omega_{-1}}(x)=\log(Hu)+2\log(1-q/u)$, and $x+1=H\,\frac{(u-q)(1-qu)}{qu}$. The map $u\mapsto x$ is a decreasing bijection $(1,\infty)\to(-\infty,a^\circ)$, and $u=1/q\leftrightarrow x=-1$.

*Proof.*

- (i) $t+1=\ell(Z+\cos\theta)$ with $Z=\frac{1+s^2}{1-s^2}=\frac12(w_0+w_0^{-1})$ and $w_0=\frac{1+s}{1-s}=1/q$. Then $Z+\cos\theta=\frac{|w_0+e^{i\theta}|^2}{2w_0}=\frac{1+2q\cos\theta+q^2}{2q}$. Using $4sq/\ell=1-q^2$ gives the formula, and the Poisson series is standard. The $\theta$-average of $\Pi$ is $1$.
- (ii) For $x=c_0+\ell\cos\psi$:
  - $\log|x-t|=\log(\ell/2)-2\sum_{n\ge1}\frac{\cos n\psi\cos n\theta}n$. This follows from $\log|2\sin\frac\tau2|=-\sum_n\frac{\cos n\tau}n$ in $L^2$, applied at $\tau=\psi\pm\theta$.
  - Pairing with $1$ and with $\Pi$ (Parseval in $L^2(0,\pi)$; $\Pi$ has absolutely summable coefficients) gives $V_\omega=\log(\ell/2)=\log H$ and $V_{\omega_{-1}}(x)=\log(\ell/2)-2\sum_n\frac{(-1)^nq^n\cos n\psi}n$.
  - On the other hand, $x+1=\ell(Z+\cos\psi)$ and $\log(Z+\cos\psi)=-\log2-\log q+2\log|1+qe^{i\psi}|$, which gives $\log(x+1)=\log(\ell/2)-\log q-2\sum_n\frac{(-1)^nq^n\cos n\psi}n$.
  - Subtracting the two expansions gives the claim.
- (iii)
  - $|x-t|=H(u+u^{-1}+2\cos\theta)$, so $\log|x-t|=\log(Hu)+2\log|1+e^{i\theta}/u|$, whose series $2\sum_n(-1)^{n+1}u^{-n}\cos n\theta/n$ converges uniformly.
  - Integrating against $d\theta/\pi$ and against $\Pi\,d\theta/\pi$ (coefficients $(-1)^nq^n$) gives the two potentials; the second is $\log(Hu)-2\sum_n(q/u)^n/n$.
  - Finally, $c_0+1=\ell Z=H(q^{-1}+q)$, so $x+1=H(q^{-1}+q-u-u^{-1})=H(u-q)(1-qu)/(qu)$. $\square$

### Lemma 5.2 (the family $\mu_A$ and its zero set)

**Source:** paper Lemma 5.2.

Fix $q\in(0,1)$ (equivalently $s$) and $A\in(0,s)$. Put
$$\mu_A:=\omega+A(\delta_{-1}-\omega_{-1})=A\delta_{-1}+\frac{t+1-2As}{\pi(t+1)\sqrt{(t-a^\circ)(1-t)}}\mathbf 1_{[a^\circ,1]}(t)\,dt .$$

- (i) $\mu_A$ is a probability measure on $[-1,1]$ with positive density on $[a^\circ,1]$. The numerator is increasing in $t$, with minimum $2s(s-A)>0$.
- (ii) $V_{\mu_A}\equiv C(A):=\log H-A\log q$ on $[a^\circ,1]$. Moreover $V_{\mu_A}>C(A)$ on $(1,\infty)$: there $V'=\int d\mu_A/(x-t)>0$, and $V(x)\downarrow V(1)=C(A)$ as $x\downarrow1$ by monotone convergence.
- (iii) For $x=x(u)<a^\circ$: $V_{\mu_A}(x(u))=C(A)-F_A(u)$ with $F_A(u):=A\log\frac{u-q}{|1-qu|}-\log u$.
- (iv) Shape of $F_A$:
  - On $(1/q,\infty)$: $F_A'=-\frac{A(1-q^2)}{(u-q)(qu-1)}-\frac1u<0$, with $F_A\to+\infty$ at $1/q^+$ and $F_A\to-\infty$ at $\infty$.
  - On $(1,1/q)$: $F_A'=\frac{qu^2-b_Au+q}{u(u-q)(1-qu)}$, where $b_A=1+q^2-A(1-q^2)$. The numerator is $<0$ at $u=1$ (it equals $(1-q)[A(1+q)-(1-q)]$, and $A<s$), $>0$ at $u=1/q$, and its roots have product $1$. So $F_A$ decreases, then increases, with $F_A(1)=0$ and $F_A\to+\infty$ at $1/q^-$.
- (v) Hence, if $C(A)\ge0$, $E_{\mu_A}=(x(u_-),x(u_+))$, where $u_->1/q$ and $u_+\in(1,1/q)$ are the unique solutions of $F_A(u)=C(A)$ on these branches ($u_+$ on the increasing branch). Both are simple, and
$$|E_{\mu_A}|=H\big(u_-+u_-^{-1}-u_+-u_+^{-1}\big).$$

*Proof.*

- (i) Density: Lemma 5.1(i). Total mass $1+A-A=1$.
- (ii) and (iii) follow from Lemma 5.1(ii) and (iii) by linearity. In (iii), $\log|x+1|-V_{\omega_{-1}}(x)=\log|1-qu|-\log q-\log(u-q)$.
- (iv) is a direct computation.
- (v)
  - On $[a^\circ,\infty)$, $V\ge C(A)\ge0$, so there are no points of $E$ there.
  - On $(-\infty,a^\circ)$, $V<0\iff F_A(u)>C(A)$. By (iv), this is the $u$-set $(u_+,1/q)\cup(1/q,u_-)$, together with $u=1/q$ (the atom, $V=-\infty$).
  - The image under the decreasing map $u\mapsto x$ is the interval $(x(u_-),x(u_+))$.
  - Simplicity: $F_A'(u_\pm)\ne0$ and $x'(u)=-H(1-u^{-2})\ne0$. $\square$

### Definition 5.3 (the terminal family and $D$)

**Source:** paper Definition 5.3.

- For $q\in(0,1)$ put $A(q):=\log H(q)/\log q$; this is exactly the choice $C(A)=0$ (zero platform).
- $A(q)\in(0,1)$ for $0<q<\sqrt2-1$, because then $q<H<1$. This covers every $q<q_s$ used below.
- $A(q)<s(q)\iff\mathfrak f(q):=(1+q)\log\frac2{(1+q)^2}+2q\log q>0$. Indeed $A=1-d_q/\tau$ with $d_q=\log\frac2{(1+q)^2}>0$ and $\tau=-\log q$, and $1-s=\frac{2q}{1+q}$.
- $\mathfrak f(0^+)=\log2>0$ and $\mathfrak f'(q)=\log\frac{2q^2}{(1+q)^2}<0$ on $(0,1)$. So $\mathfrak f$ has a unique zero $q_s$, and `cert/cert2/onecut_check.py` certifies $q_s\in(0.1236,0.1237)$ (Certificate 5.5).
- For $0<q<q_s$ put $\Lambda(q):=|E_{\mu_{A(q)}}|=H(q)\big(u_-+u_-^{-1}-u_+-u_+^{-1}\big)$, with $u_\pm$ from Lemma 5.2(v) at $A=A(q)$, $C=0$. Then
$$\boxed{D:=\inf_{0<q<q_s}\Lambda(q).}$$

Thus, more explicitly, for each \(0<q<q_s\), \(u_+(q)\) is the unique zero of
\[
F_{A(q)}(u)=A(q)\log\frac{u-q}{|1-qu|}-\log u
\]
on the increasing branch in \((1,1/q)\), and \(u_-(q)\) is its unique zero in \((1/q,\infty)\). Lemma 5.2 proves their existence, uniqueness **on these specified branches**, and simplicity. Define
\[
\boxed{\Lambda(q)=H(q)\big(u_-(q)+u_-(q)^{-1}-u_+(q)-u_+(q)^{-1}\big),\qquad
D=\inf_{0<q<q_s}\Lambda(q).}
\]
Each width is positive and finite. The family domain is nonempty, so this is a finite real infimum bounded below by zero. No minimizer or uniqueness of a minimizer of \(\Lambda\) is asserted or used.

For later comparisons fix the **exact rationals**
\[
\widehat q=\frac{257155}{10^7},\qquad
L_{\rm hi}=\frac{18344304757628}{10^{13}}.
\]
Certificate 5.5, specified in the computer-assisted section below, gives
\(\mathfrak f(\widehat q)>0\) and \(\Lambda(\widehat q)<L_{\rm hi}\). Therefore, solely by the definition of infimum,
\[
\tag{D-upper}0\le D\le\Lambda(\widehat q)<L_{\rm hi}<2.
\]
This is a bound from one explicit family member, not an assumption of a family minimum and not a use of the polynomial lower theorem.

## Component atomization, normalization, and residual widths

**Source:** paper §3, Lemmas 3.1–3.7 and Definition 3.5.

**Notation.** For a probability measure $\mu$ on $[-1,1]$ put $V_\mu(x)=\int\log|x-t|\,d\mu(t)\in[-\infty,\infty)$ and $E_\mu=\{V_\mu<0\}$. For $f\in\mathcal P$ of degree $n$ with roots $r_j$, let $\mu_f=\frac1n\sum_j\delta_{r_j}$. Then $V_{\mu_f}=\frac1n\log|f|$ and $E_{\mu_f}=S_f$. Such $\mu$ are called *empirical* (finitely many atoms, rational masses).

### Lemma 3.1 (components)

**Source:** paper Lemma 3.1.

For $f\in\mathcal P$, $S_f$ is a finite disjoint union of bounded open intervals (Lemma 1.2). Each component contains a root.

*Proof.* On a root-free open interval, $V''=-\frac1n\sum_j(x-r_j)^{-2}<0$. A root-free component $(p_1,p_2)$ would have $V(p_1)=V(p_2)=0$ (its boundary points satisfy $|f|=1$) and $V$ strictly concave, hence $V>0$ inside — a contradiction. $\square$

### Lemma 3.2 (simultaneous component atomization)

**Source:** paper Lemma 3.2.

Let $f\in\mathcal P$, and let $\mathcal C_1,\dots,\mathcal C_J$ be the components of $S_f$. Let $n_j$ be the number of roots in $\mathcal C_j$ (all roots lie in $S_f$, since $V=-\infty$ at roots), and $c_j$ their mean. Put $\tilde f=\prod_j(x-c_j)^{n_j}$. Then:

- $\tilde f\in\mathcal P$ and $\deg\tilde f=n$;
- the mean of the roots is unchanged;
- $S_{\tilde f}\subseteq S_f$;
- every component of $S_{\tilde f}$ contains exactly one distinct root of $\tilde f$.

A polynomial with the last property is called **atomized**.

*Proof.*

- $c_j$ is a mean of points of the interval $\mathcal C_j\cap[-1,1]$, so $c_j\in\mathcal C_j\cap[-1,1]$. The mean is preserved by construction.
- *Inclusion.* Let $x\notin S_f$, so $V(x)\ge0$ and $x\notin\mathcal C_j$ for all $j$. Then $t\mapsto\log|x-t|$ is concave on $\mathcal C_j$, because $x-t$ has constant sign there. Jensen gives $\sum_{r_i\in\mathcal C_j}\log|x-r_i|\le n_j\log|x-c_j|$. Summing over $j$ gives $V_{\tilde f}(x)\ge V_f(x)\ge0$, so $x\notin S_{\tilde f}$.
- *Component structure.* Each component of $S_{\tilde f}$ is a connected subset of $S_f$, hence lies in a single $\mathcal C_j$, and it contains a root of $\tilde f$ (Lemma 3.1). The only root of $\tilde f$ in $\mathcal C_j$ is $c_j$. So each $\mathcal C_j$ contains at most one component of $S_{\tilde f}$, and that component contains exactly the one cluster $c_j$. $\square$

### Lemma 3.3 (orientation)

**Source:** paper Lemma 3.3.

If the root mean $m$ of $f$ satisfies $m\le0$, then $(-1,0)\subseteq S_f$.

*Proof.*

- For $x\in(-1,0)$ and $t\in[-1,1]$: $(1-xt)^2-(x-t)^2=(1-x^2)(1-t^2)\ge0$ and $1-xt>0$, so $|x-t|\le1-xt$.
- By Jensen, $V(x)\le\int\log(1-xt)\,d\mu\le\log(1-xm)\le0$, since $xm\ge0$.
- If $V(x)=0$, all three inequalities are equalities. Jensen's equality case forces $\mu=\delta_{t_0}$, and then $m=0$ gives $\mu=\delta_0$. But then $V(x)=\log|x|<0$, a contradiction. $\square$

Reflection $f(x)\mapsto(-1)^nf(-x)$ preserves $\mathcal P$, $|S_f|$ and atomization, and negates $m$. So $m\le0$ can always be assumed.

### Lemma 3.4 (endpoint normalization)

**Source:** paper Lemma 3.4.

Let $f\in\mathcal P$ be atomized with root mean $m\le0$. Let $c$ be the root in the component $\mathcal C_0$ of $S_f$ that contains $(-1,0)$ (Lemma 3.3), and let $A$ be its multiplicity fraction. Then:

- (i) every root is $\ge c$, and $-1\le c\le m\le0$;
- (ii) after translating by $-c-1$, all roots lie in $[-1,1]$, the main root is $-1$, the mean is still $\le0$, and $|S|$ is unchanged;
- (iii) in the translated picture, the right end $\beta$ of the main component satisfies $\beta\ge0$, every other root lies in $(\beta,1]$, and $A\ge1/2$;
- (iv) if $A=1$, then $|S_f|=2$.

*Proof.*

- (i) Suppose some root $t<c$ existed; then $t\in[-1,c)$.
  - If $t>-1$: when $c<0$, $t\in(-1,c)\subset(-1,0)\subseteq\mathcal C_0$; when $c\ge0$, $t\in(-1,c]\subseteq\mathcal C_0$, since $\mathcal C_0$ is an interval containing $(-1,0)$ and $c$.
  - If $t=-1$, then $-1\in S_f$ (a root), and $S_f$ is open, so $-1\in\mathcal C_0$.
  - Either way $\mathcal C_0$ would contain two distinct roots, contradicting atomization. So $c=\min$ root $\le m$.
- (ii) A root $t\in[c,1]$ goes to $t-c-1\in[-1,-c]\subseteq[-1,1]$. The mean becomes $m-c-1\le0$.
- (iii) Work before the translation, with $b_0$ the right end of $\mathcal C_0$.
  - $b_0\ge0$ because $(-1,0)\subseteq\mathcal C_0$.
  - The other roots lie outside $\mathcal C_0$ and are $\ge c$. Since $[c,b_0)\subseteq\mathcal C_0$ and $b_0$ is not a root ($|f(b_0)|=1$), they are $>b_0$. They are $\le1$, so their distances to $b_0$ are $\le1-b_0\le1$.
  - If $b_0-c<1$, then $1=e^{V(b_0)}$ would be a product of powers of numbers $\le1$, one of them $<1$ with positive weight — impossible. Thus $\beta:=b_0-c-1\ge0$.
  - After translation, the other roots lie in $(\beta,1]$. At $\beta$, weighted AM–GM gives $1=e^{V(\beta)}\le\int|\beta-t|\,d\mu\le A(1+\beta)+(1-A)(1-\beta)=1+(2A-1)\beta$.
  - If $\beta>0$, then $A\ge1/2$.
  - If $\beta=0$, equality holds throughout. When $A<1$ (residual mass present), this forces every residual root to be at $1$. Then the mean $-A+(1-A)\le0$ gives $A\ge1/2$. When $A=1$ there is nothing to prove.
- (iv) If $A=1$, then $f=(x+1)^n$ after translation and $S=(-2,0)$. $\square$

### Definition 3.5 (normal form)

**Source:** paper Definition 3.5.

Let $f$ be as in Lemma 3.4, translated, with $A<1$, and put $k=A/(1-A)\ge1$. The residual roots have distinct values $t_1<\dots<t_N$ in $(\beta,1]\subseteq[0,1]$, with multiplicity fractions $(1-A)q_i$, where $q_i>0$ and $\sum_iq_i=1$. Shift $x\mapsto x+1$ and put $d_i=1+t_i\in[1,2]$. Then $S$ (shifted) $=\{W<0\}$ with
$$W(x)=k\log|x|+\sum_iq_i\log|x-d_i|=\frac1{(1-A)n}\log|f(x-1)|,$$
where $f$ denotes the translated polynomial; that is, $W=V/(1-A)$ in the shifted variable. $M_k$ denotes the width of the component of $\{W<0\}$ containing $0$ (the **main component**). Put
$$R_i=\exp\Big[-\frac1{q_i}\Big(k\log d_i+\sum_{j\ne i}q_j\log|d_i-d_j|\Big)\Big],\qquad\mathcal J_k=M_k+2\sum_iR_i .$$

Atomization, reflection, translation and the shift each map components to components, so in the normal form $0$ and each $d_i$ lie in pairwise different components of $\{W<0\}$.

### Lemma 3.6 (residual radius; $|S|\ge\mathcal J_k$)

**Source:** paper Lemma 3.6.

- (a) $(0,1)$ lies in the main component, and each residual component $(\lambda_i^-,\lambda_i^+)\ni d_i$ has $\lambda_i^-\ge1$.
- (b) $\lambda_i^+-\lambda_i^-\ge2R_i$.
- Hence $|S_f|\ge\mathcal J_k=M_k+2\sum_iR_i$.

*Proof.*

- (a) For $0<x<1$: $|x-d_i|\le2-x$ and $k\log x\le\log x$, so $W(x)\le\log(x(2-x))<0$. The residual component containing $d_i$ is not the main one (atomization), so it lies to the right of $(0,1)$.
- (b) On $[\lambda_i^-,\lambda_i^+]$ put $V_i(x)=k\log x+\sum_{j\ne i}q_j\log|x-d_j|$. No $d_j$ with $j\ne i$ lies in $[\lambda_i^-,\lambda_i^+]$ (one cluster per component; the endpoints are not roots), and $x\ge1$. So $V_i$ is smooth with $V_i''<0$.
  - Put $s=d_i-\lambda_i^-$, $u=\lambda_i^+-d_i$, $\tau=s+u$ and $w=s/\tau$. The boundary equations $W(\lambda_i^-)=W(\lambda_i^+)=0$ read $V_i(\lambda_i^-)=-q_i\log s$ and $V_i(\lambda_i^+)=-q_i\log u$. By definition $V_i(d_i)=-q_i\log R_i$.
  - Concavity at $d_i=(1-w)\lambda_i^-+w\lambda_i^+$ gives $-q_i\log R_i\ge-q_i[(1-w)\log s+w\log u]$. Hence $R_i\le s^{1-w}u^w=\tau\,w^{1-w}(1-w)^w$.
  - Weighted AM–GM gives $w^{1-w}(1-w)^w\le(1-w)w+w(1-w)=2w(1-w)\le\frac12$. So $\tau\ge2R_i$.
- The components are disjoint, and the shift and the division by $1-A$ change neither lengths nor sets. $\square$

### Lemma 3.7 (endpoint window)

**Source:** paper Lemma 3.7.

Let $\rho_{\rm w}(k)\in(0,1)$ solve $\rho^k(2+\rho)=1$. Then $M_k\ge1+\rho_{\rm w}(k)$, $\rho_{\rm w}(1)=\sqrt2-1$, and $\rho_{\rm w}$ is increasing in $k$.

*Proof.*

- $r\mapsto r^k(2+r)$ increases from $0$ to $3$ on $[0,1]$, so $\rho_{\rm w}(k)$ exists and is unique.
- For $0<r<\rho_{\rm w}(k)$, $W(-r)\le k\log r+\log(2+r)<0$. So $(-\rho_{\rm w}(k),1)$ lies in the main component.
- $r^k(2+r)$ decreases in $k$ for fixed $r\in(0,1)$, so $\rho_{\rm w}(k)$ increases in $k$. $\square$

## The small mass-ratio case

**Source:** paper Proposition 4.1; the constant check is part of the certificate section below.

### Proposition 4.1

**Source:** paper Proposition 4.1.

If $1\le k\le\bar k:=29/20$, then $\Sigma_R:=\sum_iR_i>1/3$ and $\mathcal J_k>\sqrt2+2/3>2$.

*Proof.*

- *A separating point.* The main component and the component of $d_1$ are distinct, so some $b\in(0,d_1)$ has $W(b)\ge0$; take the right end of the main component, which is $\ge1$ by Lemma 3.6(a).
  - Put $y_i=2-d_i\ge0$ and $\bar y=\sum_iq_iy_i$. Since $b<d_1\le d_i$ (the component of $d_1$ lies to the right of the main one), $|b-d_i|=2-y_i-b$, and Jensen gives $0\le k\log b+\log(2-\bar y-b)$. So $b^k(2-b)\ge1$.
  - Hence $b\ge1$ (as in Lemma 3.6(a), $b^k(2-b)\le b(2-b)<1$ for $b<1$).
  - Therefore $\bar y\le2-b-b^{-k}\le2-b-b^{-\bar k}\le\bar\varepsilon:=2-(\bar k+1)\bar k^{-\bar k/(\bar k+1)}$, the maximum over $b\ge1$ being at $b=\bar k^{1/(\bar k+1)}$.
- *Pair terms.* Put $Q_2=\sum_iq_i^2$ and $t=1-Q_2=2\sum_{i<j}q_iq_j$. For $t>0$, Jensen with weights $2q_iq_j/t$ and $|d_i-d_j|=|y_i-y_j|\le y_i+y_j$ give
$$2\sum_{i<j}q_iq_j\log|d_i-d_j|\le t\log\frac{2\sum_iq_i(1-q_i)y_i}{t}\le t\log\frac{2\bar\varepsilon}{t}.$$
  This uses $\sum_{i<j}q_iq_j(y_i+y_j)=\sum_iq_i(1-q_i)y_i\le\bar y$. For $t=0$ the term is read as $0$.

- *Exact identity.* $\sum_iq_i^2\log R_i=-k\sum_iq_i\log d_i-2\sum_{i<j}q_iq_j\log|d_i-d_j|\ge-k\log2-t\log(2\bar\varepsilon/t)$.
- *AM–GM.* With weights $q_i^2/Q_2\le1$, $\Sigma_R\ge\sum_i\frac{q_i^2}{Q_2}R_i\ge\exp\big(\frac1{Q_2}\sum_iq_i^2\log R_i\big)$. Therefore
$$Q_2\log(3\Sigma_R)\ge Q_2\log3-k\log2-t\log\frac{2\bar\varepsilon}t=\log3-k\log2-t\log\frac{6\bar\varepsilon}t\ge\log3-\bar k\log2-\frac{6\bar\varepsilon}e,$$
  using $\max_{t>0}t\log(\hat a/t)=\hat a/e$.

- `cert/cert2/smallk_check.py` certifies $\bar\varepsilon\in[0.033642075,0.033642076]$ and that the right side is $\ge0.01929>0$. Hence $\Sigma_R>1/3$.
- Finally, $\mathcal J_k=M_k+2\Sigma_R>1+(\sqrt2-1)+2/3$ by Lemma 3.7 ($\rho_{\rm w}(k)\ge\rho_{\rm w}(1)$). $\square$

*Consequence.* For the infimum problem, the range $1\le k\le29/20$ gives $|S_f|>2$. Together with Lemma 3.4(iv) ($A=1$ gives $|S_{\tilde f}|=2$ for the atomized polynomial, hence $|S_f|\ge2$), this leaves $k>29/20$ for §§6–9.

For \(t=0\), the displayed terms \(t\log(c/t)\) are their continuous limits zero. The case \(N=1\) is therefore covered. At atomic contact the main right endpoint is a separating point \(b\): its potential is zero, so it is excluded from the strict sublevel set. Nothing in this argument requires a positive-length gap.

By (D-upper), this branch proves \(\mathcal J_k>2>D\). If the atomized polynomial has only one distinct root value, Lemma 3.4(iv) instead gives \(M(f)\ge2>D\). For the remaining cases the following analytic comparison will be applied to \(k>29/20\).

## Reference measures, admissibility, and the convex supporting inequality

**Source:** paper §6. The target is the normal form of Definition 3.5. References will satisfy (H1) and (H2); their existence for every remaining \(k\) is proved by the parameter cover below.

### 6.0 Conventions: quantile functions

- $\mathcal Q$ denotes the set of Lebesgue-measurable $S:(0,1)\to[1,2]$. Monotonicity is *not* assumed. (In this section $S$ denotes an element of $\mathcal Q$, not a sublevel set.)
- For $S\in\mathcal Q$ put $a_S:=\operatorname{ess\,inf}S\in[1,2]$, so $S(u)\ge a_S$ for a.e. $u$.
- For $S_0,S_1\in\mathcal Q$ and $t\in[0,1]$, $S_t:=(1-t)S_0+tS_1\in\mathcal Q$.
- The *quantile* of a Borel probability measure $\nu$ on $[1,2]$ is $T_\nu(u)=\inf\{d\in[1,2]:\nu([1,d])\ge u\}$.
  - With $F_\nu(d)=\nu([1,d])$ right-continuous, $T_\nu(u)\le d\iff u\le F_\nu(d)$.
  - Hence $|\{u:T_\nu(u)\le d\}|=F_\nu(d)$, so $T_\nu$ pushes Lebesgue measure on $(0,1)$ forward to $\nu$. Thus $\int_0^1h(T_\nu(u))\,du=\int h\,d\nu$ for every bounded or nonnegative Borel $h$.
  - For $\nu=\sum_iq_i\delta_{d_i}$ with $d_1<\dots<d_N$, $T_\nu=d_i$ on an interval of length $q_i$, and $a_{T_\nu}=d_1$.

For $S\in\mathcal Q$ define
$$W_S(x)=k\log|x|+\int_0^1\log|x-S(u)|\,du\in[-\infty,\infty),\quad W_S(0):=-\infty,\qquad R(S)=\exp\Big(-\tfrac1k\int_0^1\log S\Big),\qquad m_p(S)=\int_0^1S(u)^{-p}\,du\ \ (p\ge1).$$

- The integral defining $W_S(x)$ exists because the integrand is bounded above by $\log(|x|+2)$. It is upper semicontinuous: on each compact observation interval replace each logarithm by $\max(\log|x-t|,-m)$, integrate the continuous truncated kernel, and let $m\to\infty$ monotonically. The decreasing limit of these continuous potentials is upper semicontinuous. Thus $\{W_S<0\}$ is open, and its connected components are intervals.
- $M_k(S)$ denotes the width of the component of $\{W_S<0\}$ containing $0$, whenever that component is bounded.
- For $S=T_\nu$ with $\nu$ atomic, $W_S$ is exactly the function $W$ of Definition 3.5.

### Part (a). The reference measure $\eta_{k,a}$

#### Lemma 6.1 (Poisson–logarithm lemma)

**Source:** paper Lemma 6.1.

Let $P_\rho(\theta)=\dfrac{1-\rho^2}{|1-\rho e^{i\theta}|^2}=1+2\sum_{m\ge1}\rho^m\cos m\theta$ for $0\le\rho<1$ (so $P_0\equiv1$). For every real $\varphi$:
$$\text{(i)}\quad\frac1{2\pi}\int_{-\pi}^{\pi}\log|1-e^{i(\theta+\varphi)}|\,P_\rho(\theta)\,d\theta=\log|1-\rho e^{i\varphi}|;\qquad\text{(ii)}\quad\frac1{2\pi}\int_{-\pi}^{\pi}\log|1-\rho e^{i\theta}|\,d\theta=0.$$
The integrand in (i) is absolutely integrable.

*Proof.*

- *Series for $r<1$.* For $0\le r<1$, $\log|1-re^{it}|=\operatorname{Re}\operatorname{Log}(1-re^{it})=-\sum_{m\ge1}r^m\cos(mt)/m$, uniformly and absolutely convergent in $t$.
  - This already gives (ii): take $r=\rho$ and integrate termwise.
  - Multiply the series with $t=\theta+\varphi$ by the uniformly convergent series of $P_\rho$ and integrate termwise. By orthogonality, $\frac1{2\pi}\int\cos(m(\theta+\varphi))d\theta=0$ and $\frac1{2\pi}\int\cos(m(\theta+\varphi))\cos(m'\theta)d\theta=\frac12\delta_{mm'}\cos m\varphi$ for $m,m'\ge1$.
  - Hence $\frac1{2\pi}\int\log|1-re^{i(\theta+\varphi)}|P_\rho(\theta)d\theta=-\sum_m(r\rho)^m\cos(m\varphi)/m=\log|1-r\rho e^{i\varphi}|$.
- *Limit $r\uparrow1$.* The right side tends to $\log|1-\rho e^{i\varphi}|$, which is finite because $\rho<1$. For the left side, use dominated convergence.
  - For $r\in[\frac12,1]$: $|1-re^{it}|^2=(1-r)^2+2r(1-\cos t)\ge1-\cos t=2\sin^2(t/2)$, and $|1-re^{it}|\le2$.
  - So $|\log|1-re^{it}||\le\log2+|\log(\sqrt2|\sin(t/2)|)|$.
  - This bound is integrable on a period, since $|\sin(t/2)|\ge|t|/\pi$ on $[-\pi,\pi]$. Also $0\le P_\rho\le\frac{1+\rho}{1-\rho}$.
  - Pointwise convergence holds for $\theta\ne-\varphi\pmod{2\pi}$.
- The same bound (with $r=1$) gives absolute integrability. $\square$

#### The interval $I$ and its parametrisation
Fix $0<a<2$ (in the application $1\le a<2$), and put $I=[a,2]$,
$$c=\frac{a+2}2,\quad\ell=\frac{2-a}2,\quad H=\frac\ell2=\frac{2-a}4,\quad D_0(a)=\frac{a+2+2\sqrt{2a}}4=\Big(\frac{\sqrt a+\sqrt2}2\Big)^2.$$

- Since $c/\ell>1$, put $\tau_0=\operatorname{arccosh}(c/\ell)>0$ and $\rho_0=e^{-\tau_0}\in(0,1)$.
- Then $\ell\sinh\tau_0=\sqrt{c^2-\ell^2}=\sqrt{2a}$, so $e^{\tau_0}=(c+\sqrt{2a})/\ell=\frac{\sqrt2+\sqrt a}{\sqrt2-\sqrt a}$ and $\rho_0=\frac{\sqrt2-\sqrt a}{\sqrt2+\sqrt a}$.
- Also $\ell e^{\tau_0}/2=(c+\sqrt{2a})/2=D_0(a)$ and $(1-\rho_0^2)D_0(a)=\ell\sinh\tau_0=\sqrt{2a}$.

The map $\theta\mapsto d(\theta)=c-\ell\cos\theta$ is an increasing homeomorphism $[0,\pi]\to I$, with $d-a=\ell(1-\cos\theta)$, $2-d=\ell(1+\cos\theta)$, $\sqrt{(d-a)(2-d)}=\ell\sin\theta$ and $\mathrm dd=\ell\sin\theta\,d\theta$. Moreover
$$d(\theta)=\ell(\cosh\tau_0-\cos\theta)=\frac{\ell e^{\tau_0}}2\,|1-\rho_0e^{i\theta}|^2=D_0(a)\,|1-\rho_0e^{i\theta}|^2.\tag{6.1}$$
To check (6.1), expand $|1-\rho_0e^{i\theta}|^2=1-2\rho_0\cos\theta+\rho_0^2$ and multiply by $e^{\tau_0}/2$.

**Definition.** $e_I$ is the image of $d\theta/\pi$ on $[0,\pi]$ under $\theta\mapsto d(\theta)$, and $\omega_{0,I}$ is the image of $P_{\rho_0}(\theta)\,d\theta/\pi$. By the substitution above and (6.1) (which gives $P_{\rho_0}(\theta)=(1-\rho_0^2)D_0/d=\sqrt{2a}/d$), these are exactly the measures of Wang's (4.2):
$$de_I(d)=\frac{\mathrm dd}{\pi\sqrt{(d-a)(2-d)}},\qquad d\omega_{0,I}(d)=\frac{\sqrt{2a}}d\,de_I(d).$$

#### Lemma 6.2 (equilibrium and balayage potentials)

**Source:** paper Lemma 6.2.

- (i) $e_I$ and $\omega_{0,I}$ are probability measures on $I$, and $\omega_{0,I}$ has positive density.
- (ii) For every $x\in I$ (all integrals absolutely convergent):
$$U_e(x):=\int\log|x-d|\,de_I(d)=\log H,\qquad U_\omega(x):=\int\log|x-d|\,d\omega_{0,I}(d)=\log x+\log H-\log D_0(a).$$

- (iii) For $x<a$, $x\ne0$, let $\tau_x=\operatorname{arccosh}((c-x)/\ell)>0$ and $\rho_x=e^{-\tau_x}\in(0,1)$. Then
$$U_e(x)=\log H+\tau_x,\qquad U_\omega(x)=\log H+\tau_x+2\log(1-\rho_0\rho_x).$$
($\rho_x$ is the root in $(0,1)$ of $\rho+\rho^{-1}=2(c-x)/\ell$; it coincides with $\rho_x$ of Lemma 7.2(i). The exclusion $x\ne0$ matters only for $W_0$ below.)

(ii) says that $\omega_{0,I}$ is a probability measure on $I$ whose potential differs from $\log|x-0|$ by a constant on $I$: it is the balayage of $\delta_0$ onto $I$. Uniqueness of balayage is not needed; only the formula is used.

*Proof.*

- (i) The total masses are $\frac1\pi\int_0^\pi d\theta=1$ and $\frac1\pi\int_0^\pi P_{\rho_0}=1$ (termwise integration of the series). Also $P_{\rho_0}>0$.
- (ii) Write $x=c-\ell\cos\varphi$ with $\varphi\in[0,\pi]$. For all real $\theta,\varphi$, $\cos\theta-\cos\varphi=-2\sin\frac{\theta+\varphi}2\sin\frac{\theta-\varphi}2$ and $|1-e^{it}|=2|\sin\frac t2|$. Hence, for $\theta\ne\pm\varphi$,
$$\log|x-d(\theta)|=\log\ell+\log|\cos\theta-\cos\varphi|=\log\ell-\log2+\log|1-e^{i(\theta+\varphi)}|+\log|1-e^{i(\theta-\varphi)}|.$$

  - Both sides are even in $\theta$, and so is $P_{\rho_0}$. So $\frac1\pi\int_0^\pi(\cdot)P_{\rho_0}\,d\theta=\frac1{2\pi}\int_{-\pi}^{\pi}(\cdot)P_{\rho_0}\,d\theta$.
  - Lemma 6.1(i), applied with $\varphi$ and with $-\varphi$, and $|1-\rho_0e^{-i\varphi}|=|1-\rho_0e^{i\varphi}|$, give
$$U_\omega(x)=\log\ell-\log2+2\log|1-\rho_0e^{i\varphi}|=\log H+\log\frac x{D_0(a)},$$
    where the last step is (6.1) at $\theta=\varphi$.

  - The same computation with $\rho_0$ replaced by $0$ ($P_0\equiv1$) gives $U_e(x)=\log\ell-\log2=\log H$.
- (iii) For $x<a$: $|x-d(\theta)|=\ell(\cosh\tau_x-\cos\theta)=\frac{\ell e^{\tau_x}}2|1-\rho_xe^{i\theta}|^2$. Use $\log|1-\rho_xe^{i\theta}|=-\sum_m\rho_x^m\cos(m\theta)/m$ (uniform).
  - Against $d\theta/\pi$ the series integrates to $0$, giving $U_e$.
  - Against $P_{\rho_0}\,d\theta/\pi$ it gives $2\cdot(-\sum_m(\rho_0\rho_x)^m/m)=2\log(1-\rho_0\rho_x)$, giving $U_\omega$. $\square$

#### Proposition 6.3 (the reference measure)

**Source:** paper Proposition 6.3.

Let $k>0$ and $\eta_{k,a}:=(k+1)e_I-k\,\omega_{0,I}$ (a finite signed measure on $I$).

1. **Density.** In the $\theta$ variable, $d\eta_{k,a}=\frac1\pi\big((k+1)-kP_{\rho_0}(\theta)\big)d\theta$. In the $d$ variable (Wang's (4.4)),
$$d\eta_{k,a}(d)=\Big(k+1-\frac{k\sqrt{2a}}d\Big)\frac{\mathrm dd}{\pi\sqrt{(d-a)(2-d)}}.\tag{6.2}$$

2. **Mass.** $\eta_{k,a}(I)=(k+1)-k=1$.
3. **Positivity.** $\eta_{k,a}\ge0$ if and only if (Wang's (4.5))
$$a\ge2\Big(\frac k{k+1}\Big)^2.\tag{6.3}$$

   - Under (6.3), $\eta_{k,a}$ is a probability measure with density $>0$ on $(a,2]$. If (6.3) is strict, the density is also positive near $a$.
   - In either case every interval $[a,a+\epsilon]$ has positive mass. So its quantile $T_0:=T_{\eta_{k,a}}$ has $a_{T_0}=a$ and values in $[a,2]$. If moreover $a\ge1$ (the only case used from §6(b) on), then $T_0\in\mathcal Q$. For $a<1$ the values of $T_0$ need not lie in $[1,2]$.
4. **Platform identity** (Wang's (4.6)). For every $d\in I$,
$$k\log d+\int_I\log|d-e|\,d\eta_{k,a}(e)=C(k,a):=\log H+k\log D_0(a).\tag{6.4}$$

5. **Distribution function.** $\eta_{k,a}([a,c-\ell\cos\theta])=\frac1\pi\Big(\theta-2k\arctan\frac{\rho_0\sin\theta}{1-\rho_0\cos\theta}\Big)$ for $\theta\in[0,\pi]$.
6. **Reference potential off $I$.** For $x<a$, $x\ne0$,
$$W_0(x):=k\log|x|+\int\log|x-d|\,d\eta_{k,a}(d)=k\log|x|+\log H+\tau_x-2k\log(1-\rho_0\rho_x).$$

*Proof.*

- 1–2 follow from the definitions and Lemma 6.2(i).
- 3. The factor $k+1-k\sqrt{2a}/d$ is strictly increasing in $d$. So the density is $\ge0$ on $(a,2)$ iff its limit at $d=a$ is $\ge0$, i.e. iff $k+1\ge k\sqrt{2/a}$, i.e. iff $\sqrt{a/2}\ge k/(k+1)$, which is (6.3).
  - If (6.3) fails, the density is negative on a neighbourhood of $a$ in $I$, so $\eta_{k,a}\not\ge0$.
  - If (6.3) holds, the factor is $>0$ on $(a,2]$.
  - Equivalently, in the $\theta$ variable positivity means $P_{\rho_0}(0)=\frac{1+\rho_0}{1-\rho_0}\le\frac{k+1}k$, i.e. $\rho_0\le\frac1{2k+1}$.
- 4. By Lemma 6.2(ii),
$$k\log d+(k+1)\log H-k(\log d+\log H-\log D_0)=\log H+k\log D_0.$$

- 5. $\int_0^\theta P_{\rho_0}=\theta+2\sum_m\rho_0^m\frac{\sin m\theta}m=\theta+2\operatorname{Im}(-\operatorname{Log}(1-\rho_0e^{i\theta}))=\theta+2\arctan\frac{\rho_0\sin\theta}{1-\rho_0\cos\theta}$. This uses $1-\rho_0\cos\theta>0$.
- 6. Combine Lemma 6.2(iii) with weights $k+1$ and $-k$. $\square$

*Remark.* $C(k,a)$ carries no sign assumption.

### Part (b). The functions $\Psi_S$, $\mathcal R_S$ and the separation–contact criterion

For $S\in\mathcal Q$ let $\Omega_S=\mathbb C\setminus[a_S,\infty)$.

- For $y\in\Omega_S$ and a.e. $u$, both $1-y/S(u)$ and $S(u)-y$ avoid $(-\infty,0]$.
- On compact $K'\subset\Omega_S$ they stay in a compact subset of $\mathbb C\setminus(-\infty,0]$ uniformly in $u$, because $(y,\sigma)\mapsto1-y/\sigma$ is continuous on $K'\times[a_S,2]$.
- Hence the following parameter integrals are holomorphic on $\Omega_S$ (principal logarithm):
$$\Psi_S(y)=y\exp\Big(\tfrac1k\int_0^1\operatorname{Log}\big(1-\tfrac y{S(u)}\big)du\Big),\qquad\mathcal R_S(y)=\exp\Big(-\tfrac1k\int_0^1\operatorname{Log}(S(u)-y)\,du\Big).$$

Since $\operatorname{Log}(S-y)=\log S+\operatorname{Log}(1-y/S)$ for $S>0$ and $y\in\Omega_S$ (both arguments lie in $(-\pi,\pi)$ and coincide),
$$\Psi_S(y)=\frac{R(S)\,y}{\mathcal R_S(y)}\qquad(y\in\Omega_S).\tag{6.5}$$
For real $y<a_S$, $y\ne0$, all quantities are real, $\mathcal R_S(y)=\exp(-\frac1k\int\log(S-y))>0$, and
$$W_S(y)=k\log\frac{|\Psi_S(y)|}{R(S)}.\tag{6.6}$$
Indeed, $k\log|\Psi_S(y)|-k\log R=k\log|y|+\int\log(1-y/S)+\int\log S=k\log|y|+\int\log(S-y)$. So on $(-\infty,a_S)\setminus\{0\}$: $W_S(y)<0\iff|\Psi_S(y)|<R(S)$.

For atomic $S=T_\nu$, with $\alpha_i=q_i/k$, this gives the source's formulas
$$\Psi(y)=y\prod_i(1-y/d_i)^{\alpha_i},\qquad R=\prod_id_i^{-\alpha_i},\qquad\mathcal R(y)=\prod_i(d_i-y)^{-\alpha_i}.$$

#### Lemma 6.4 (shape of $\Psi_S$ on the real axis)

**Source:** paper Lemma 6.4.

Let $S\in\mathcal Q$ and $k>0$.

1. $\Psi_S(0)=0$ and $\Psi_S'(0)=1$.
2. On $(-\infty,0)$: $\Psi_S(y)<y<0$ and $\Psi_S'>0$. Thus $\Psi_S$ is an increasing bijection of $(-\infty,0)$ onto itself.
3. On $(0,a_S)$: $\Psi_S>0$, and the function
$$G_S(y)=\frac{\Psi_S'(y)}{\Psi_S(y)}=\frac1y-\frac1k\int_0^1\frac{du}{S(u)-y}$$
   is strictly decreasing with $G_S(0+)=+\infty$.

   - Let $y_c(S)=\sup\{y\in(0,a_S):G_S(y)>0\}\in(0,a_S]$. Then $\Psi_S'>0$ on $(0,y_c)$ and $\Psi_S'<0$ on $(y_c,a_S)$.
   - Let $\Psi^\ast(S):=\sup_{(0,a_S)}\Psi_S=\lim_{y\uparrow y_c}\Psi_S(y)$. This limit is $\Psi_S(y_c)$ if $y_c<a_S$, and $\Psi^\ast(S)\le a_S$.
4. $\Psi_S$ is strictly increasing with $\Psi_S'>0$ on $(-\infty,y_c)$. Its inverse $\chi_S:(-\infty,\Psi^\ast(S))\to(-\infty,y_c)$ is continuous, increasing, and real-analytic.
5. If $S=T_\nu$ is atomic, then $a_S=d_1$ and $\Psi_S(y)\to0$ as $y\uparrow d_1$. So $y_c<d_1$ is the **unique** critical point of $\Psi_S$ in $(0,d_1)$, and $\Psi^\ast(S)=\Psi_S(y_c)$.

*Proof.*

- 1. Immediate.
- 2. For $y<0$, $1-y/S>1$, so the exponential factor is $>1$ and $\Psi_S(y)<y$. The logarithmic derivative is
$$G_S(y)=\frac1y-\frac1k\int\frac{du}{S-y}<0,$$
  obtained by differentiating under the integral, dominated by $1/(a_S-y)$ on compacts. Since $\Psi_S<0$, $\Psi_S'=G_S\Psi_S>0$. Also $\Psi_S(y)\to0$ as $y\uparrow0$.

- 3. Positivity: $1-y/S>0$ a.e. Next, $G_S'(y)=-y^{-2}-\frac1k\int(S-y)^{-2}<0$, and $\int(S-y)^{-1}\le(a_S-y)^{-1}$ stays bounded near $0$. The sign pattern of $\Psi_S'=G_S\Psi_S$ follows.
- 4. Items 1–3 give $\Psi_S'>0$ on $(-\infty,y_c)$. Continuity and strict monotonicity give a continuous increasing inverse onto $(-\infty,y_c)$. Real-analyticity:
  - at each $y_0<y_c$, $\Psi_S$ is holomorphic near $y_0$ with $\Psi_S'(y_0)\ne0$;
  - by the holomorphic inverse function theorem it has a holomorphic local inverse near $\Psi_S(y_0)$;
  - that inverse is a holomorphic $h$ on a disc $\mathbb B$ around $t_0=\Psi_S(y_0)$, with $h(\mathbb B)\subset\mathcal N$, where $\mathcal N$ is a complex neighbourhood of $y_0$ on which $\Psi_S$ is injective;
  - for real $t\in\mathbb B$ close to $t_0$, $\chi_S(t)\in\mathcal N$ by continuity of $\chi_S$, and $\Psi_S(\chi_S(t))=t=\Psi_S(h(t))$. Injectivity on $\mathcal N$ gives $h(t)=\chi_S(t)$, so $\chi_S$ is real-analytic near $t_0$.
- 5. $\Psi_S(y)=y\prod_i(1-y/d_i)^{\alpha_i}\to0$ as $y\uparrow d_1$, because $\alpha_1>0$. A positive function vanishing at both ends of $(0,d_1)$ cannot increase on the whole interval, so $y_c<d_1$. Uniqueness of the critical point follows from strict monotonicity of $G_S$. $\square$

#### Definition 6.5 (separation and contact)

**Source:** paper Definition 6.5.

$S\in\mathcal Q$ is

- **strictly separated** if $R(S)<\Psi^\ast(S)$. By (6.6) this is equivalent to $W_S(\varrho)>0$ for some $\varrho\in(0,a_S)$, i.e. to $\sup_{(0,a_S)}W_S>0$;
- **in contact** if $y_c(S)<a_S$ and $R(S)=\Psi_S(y_c)=\Psi^\ast(S)$;
- **admissible** if it is one of the two.

#### Lemma 6.6 (main component of an admissible $S$)

**Source:** paper Lemma 6.6.

Let $S$ be admissible. Put $x_-=\chi_S(-R(S))$, the unique negative solution of $\Psi_S(y)=-R(S)$. Put $x_+=\chi_S(R(S))$ in the strictly separated case and $x_+=y_c$ in the contact case. Then:

- the main component of $\{W_S<0\}$ is $(x_-,x_+)$, and $W_S(x_\pm)=0$;
- $M_k(S)=x_+-x_-$, with $x_-<0<x_+<a_S$.

In the strictly separated case, additionally:

- $x_+<y_c$, and $x_+<\varrho$ for every $\varrho\in(0,a_S)$ with $\Psi_S(\varrho)>R(S)$;
- the crossings are simple: $W_S'(x_-)=kG_S(x_-)<0<kG_S(x_+)=W_S'(x_+)$.

In particular, the simple-crossing hypothesis is automatic for a **strictly separated** $S$. At contact the positive endpoint is the critical point, and its derivative is zero; no simple target crossing is assumed there.

*Proof.*

- By (6.6), on $(-\infty,a_S)\setminus\{0\}$ we have $W_S<0\iff|\Psi_S|<R$.
- On $(-\infty,0)$, Lemma 6.4(2) gives $\{W_S<0\}\cap(-\infty,0)=(x_-,0)$ and $W_S(x_-)=0$.
- On $(0,y_c)$, $\Psi_S$ increases from $0$ to $\Psi^\ast$.
  - *Strictly separated* ($R<\Psi^\ast$): there is a unique $x_+\in(0,y_c)$ with $\Psi_S(x_+)=R$, and $W_S<0$ on $(0,x_+)$.
    - If $\Psi_S(\varrho)>R$: for $\varrho\le y_c$, monotonicity gives $x_+<\varrho$; for $\varrho>y_c$, $x_+<y_c<\varrho$.
  - *Contact* ($R=\Psi^\ast=\Psi_S(y_c)$, $y_c<a_S$): $\Psi_S<R$ on $(0,y_c)$, and $W_S(y_c)=0$.
- Together with $W_S(0)=-\infty$, the main component is $(x_-,x_+)$.
- The derivative formula is $W_S'=k\Psi_S'/\Psi_S=kG_S$. Its signs follow from $x_-<0$ and $x_+<y_c$. $\square$

#### Lemma 6.7 (separation–contact criterion for atomic targets)

**Source:** paper Lemma 6.7.

Let $\nu=\sum_{i=1}^Nq_i\delta_{d_i}$ with $1\le d_1<\dots<d_N\le2$, $q_i>0$, $\sum q_i=1$, and $T=T_\nu$. Then:

- If the main component of $\{W_T<0\}$ does not contain $d_1$, then $R(T)\le\Psi_T(y_c)$, where $y_c\in(0,d_1)$ is the unique critical point. So $T$ is admissible:
  - strictly separated iff $R(T)<\Psi_T(y_c)$;
  - in contact iff $R(T)=\Psi_T(y_c)$. In that case $y_c$ is the common boundary point of the main component and of the component containing $d_1$.
- In both cases $x_-=\chi_T(-R(T))$. In separation $x_+=\chi_T(R(T))$; in contact $x_+=\lim_{t\uparrow R(T)}\chi_T(t)=y_c$. This limit does not evaluate $\chi_T$ at the excluded right endpoint of its open domain.
- Every normal form (Definition 3.5) satisfies the hypothesis. Indeed, the chain atomize (Lemma 3.2) → reflect (Lemma 3.3) → translate (Lemma 3.4) → shift $x\mapsto x+1$ maps components to components, so the root $0$ and the root $d_1$ lie in different components. Moreover $d_i\in(1+\beta,2]\subseteq[1,2]$, $q_i>0$, $\sum q_i=1$, and $W_T=W$.

*Proof.*

- If $R>\Psi_T(y_c)=\max_{(0,d_1)}\Psi_T$, then $|\Psi_T|<R$ on $(0,d_1)$. So $W_T<0$ there, and $W_T(d_1)=-\infty$. Hence $(0,d_1]$ lies in the main component, which proves the first claim by contraposition.
- In the contact case, $\Psi_T$ decreases from $R$ to $0$ on $(y_c,d_1)$ (Lemma 6.4(3),(5)). So $W_T<0$ on $(y_c,d_1]$, and $y_c$ is a zero of $W_T$ separating two components.
- The rest is Lemma 6.6. $\square$

### Part (c). Inverse series, convexity, and the supporting inequality

#### Lemma 6.8 (Taylor data and the coefficients $F_n$)

**Source:** paper Lemma 6.8.

Let $S\in\mathcal Q$. For $|y|<a_S$,
$$\mathcal R_S(y)=R(S)\exp\Big(\frac1k\sum_{p\ge1}\frac{m_p(S)}py^p\Big).\tag{6.7}$$
This follows from $-\operatorname{Log}(S-y)=-\log S+\sum_py^pS^{-p}/p$, integrated termwise: dominated, since $|y|/S\le|y|/a_S<1$ a.e.

Define, for $n\ge1$,
$$F_n(S):=\frac1n[y^{n-1}]\,\mathcal R_S(y)^n .$$

1. **Moment form.** With $J_{n-1}=\{(j_1,\dots,j_{n-1})\in\mathbb N_0^{n-1}:\sum_pp\,j_p=n-1\}$,
$$F_n(S)=\frac{R(S)^n}n\sum_{j\in J_{n-1}}\prod_{p=1}^{n-1}\frac1{j_p!}\Big(\frac{n\,m_p(S)}{kp}\Big)^{j_p}.$$
   In particular $F_n(S)>0$.

2. **Atomic form** (Wang's (4.16)). For $S=T_\nu$ atomic,
$$F_n=\frac1n\sum_{r_1+\dots+r_N=n-1}\prod_i\frac{(n\alpha_i)_{r_i}}{r_i!}d_i^{-(n\alpha_i+r_i)},$$
   with rising Pochhammer symbols.

3. **Cauchy bound.** For every $\varrho\in(0,a_S)$,
$$0<F_n(S)\le\frac\varrho n\Big(\frac{R(S)}{\Psi_S(\varrho)}\Big)^n.$$

*Proof.*

- 1. $\mathcal R_S^n=R^n\exp(\sum_pc_py^p)$ with $c_p=\frac{n\,m_p}{kp}>0$. Expanding $\prod_p\exp(c_py^p)$ (all series absolutely convergent for $|y|<a_S$) and collecting $y^{n-1}$ gives the formula.
- 2. $\mathcal R^n=\prod_id_i^{-n\alpha_i}(1-y/d_i)^{-n\alpha_i}$ and $(1-t)^{-b}=\sum_r(b)_rt^r/r!$.
- 3. By Cauchy's formula on $|y|=\varrho$ ($\mathcal R_S$ is holomorphic on the closed disc),
$$F_n=\frac1n\cdot\frac1{2\pi i}\oint_{|y|=\varrho}\mathcal R_S(y)^ny^{-n}dy.$$

  - For $|y|=\varrho$: $|\mathcal R_S(y)|=\exp(-\frac1k\int\log|S-y|)\le\exp(-\frac1k\int\log(S-\varrho))=\mathcal R_S(\varrho)$, because $|S-y|\ge S-\varrho>0$ a.e.
  - Hence $F_n\le\frac1n\,\varrho\,(\mathcal R_S(\varrho)/\varrho)^n$.
  - By (6.5), $\mathcal R_S(\varrho)/\varrho=R/\Psi_S(\varrho)$. $\square$

#### Lemma 6.9 (Lagrange inversion)

**Source:** paper Lemma 6.9.

Let $\phi$ be holomorphic on a disc $|y|<r_0$ with $\phi(0)\ne0$, and $\psi(y)=y/\phi(y)$. Then $\psi$ has a holomorphic inverse $\Phi$ near $0$ with $\Phi(0)=0$, and $[z^n]\Phi=\frac1n[y^{n-1}]\phi^n$ for $n\ge1$.

*Proof.*

- *Local inverse.* $\psi'(0)=1/\phi(0)\ne0$. Choose a disc $U=\{|y|<\epsilon\}$ on which $\psi$ is injective and $\phi\ne0$. Then $\psi:U\to V=\psi(U)$ is biholomorphic; let $\Phi=\psi^{-1}$. Take $\delta>0$ with $\{|z|\le\delta\}\subset V$ and let $\gamma(t)=\Phi(\delta e^{it})$, a closed $C^1$ curve in $U\setminus\{0\}$.
- *Substitution and integration by parts.* Substituting $z=\psi(y)$,
$$[z^n]\Phi=\frac1{2\pi i}\oint_{|z|=\delta}\frac{\Phi(z)}{z^{n+1}}dz=\frac1{2\pi i}\int_\gamma y\,\psi^{-n-1}\psi'\,dy=\frac1{2\pi i}\int_\gamma\frac{\psi^{-n}}n\,dy,$$
  since $y\psi^{-n-1}\psi'=-\frac1n\big[(y\psi^{-n})'-\psi^{-n}\big]$ and the exact derivative integrates to $0$ over a closed curve.

- *Residue.* $\psi^{-n}=\phi^ny^{-n}$ has a single pole in $U$, at $0$, with residue $[y^{n-1}]\phi^n$.
  - $\operatorname{ind}_\gamma(0)=\frac1{2\pi i}\oint_{|z|=\delta}\Phi'/\Phi\,dz=1$, by the argument principle: $\Phi$ has exactly one zero in $|z|<\delta$, and it is simple.
  - The residue theorem in the disc $U$ gives the claim. $\square$

Apply Lemma 6.9 with $\phi=\mathcal R_S/R(S)$, which by (6.5) gives $\psi=\Psi_S$. The local inverse $\Phi_S$ of $\Psi_S$ at $0$ has
$$\Phi_S(z)=\sum_{n\ge1}a_n(S)z^n,\qquad a_n(S)=\frac1n[y^{n-1}]\Big(\frac{\mathcal R_S}R\Big)^n=F_n(S)\,R(S)^{-n}\ \ (\ge0).$$
For atomic $S$, $\mathcal R_S/R=\prod_i(1-y/d_i)^{-\alpha_i}$, and this is Wang's (4.14).

#### Proposition 6.10 (radius of convergence; the endpoint series)

**Source:** paper Proposition 6.10.

Let $S\in\mathcal Q$. The series $\Phi_S$ has nonnegative coefficients and radius of convergence $\operatorname{rad}(S)\ge\Psi^\ast(S)$. On $(-\Psi^\ast(S),\Psi^\ast(S))$, $\Phi_S=\chi_S$. Consequently:

1. **Strictly separated $S$.** $x_+=\sum_nF_n(S)$ and $x_-=\sum_n(-1)^nF_n(S)$, so
$$M_k(S)=2\sum_{n\ \mathrm{odd}}F_n(S),$$
   with geometric convergence: $F_n\le\frac\varrho n\varkappa^n$, $\varkappa=R/\Psi_S(\varrho)<1$, for any $\varrho\in(0,a_S)$ with $\Psi_S(\varrho)>R$.

2. **Contact $S$.** The same three identities hold. The nonnegative series $\sum F_n(S)$ converges, to $y_c$.

*Proof.*

- *Radius.* Lemma 6.8(3) gives $a_n=F_nR^{-n}\le\frac\varrho n\Psi_S(\varrho)^{-n}$ for all $\varrho\in(0,a_S)$. So $\limsup a_n^{1/n}\le1/\Psi_S(\varrho)$, and letting $\varrho\uparrow y_c$ gives $\operatorname{rad}(S)\ge\Psi^\ast(S)$.
- *Identity on $J'=(-\Psi^\ast,\Psi^\ast)$.* Both $\Phi_S|_{J'}$ (a convergent power series) and $\chi_S|_{J'}$ (Lemma 6.4(4)) are real-analytic on the interval $J'$.
  - They agree near $0$. For small real $t$, $\Phi_S(t)$ is real (real coefficients), small, and satisfies $\Psi_S(\Phi_S(t))=t$. Since $\Psi_S$ is injective on $(-\infty,y_c)$, $\Phi_S(t)=\chi_S(t)$.
  - By the identity theorem for real-analytic functions on an interval, they agree on $J'$.
- *Strictly separated.* $\pm R\in J'$, so $x_\pm=\chi_S(\pm R)=\Phi_S(\pm R)=\sum a_n(\pm R)^n=\sum(\pm1)^nF_n$, absolutely convergent. Subtracting gives $M_k=\sum(1-(-1)^n)F_n$.
- *Contact.* For $\lambda\in(0,1)$, $\sum F_n\lambda^n=\Phi_S(\lambda R)=\chi_S(\lambda R)$.
  - As $\lambda\uparrow1$, the left side increases to $\sum F_n\in[0,\infty]$ (monotone convergence). The right side increases to $\lim_{t\uparrow\Psi^\ast}\chi_S(t)=y_c$, because $\chi_S$ is an increasing bijection onto $(-\infty,y_c)$. Hence $\sum F_n=y_c<\infty$.
  - Then $\sum(-1)^nF_n\lambda^n\to\sum(-1)^nF_n$ (dominated by $F_n$), while $\chi_S(-\lambda R)\to\chi_S(-R)=x_-$ by continuity at $-R\in(-\infty,\Psi^\ast)$. $\square$

**Remark 6.10b (contact radius; source: paper Remark 6.10b).** In the contact case $\operatorname{rad}(S)=\Psi^\ast(S)=R(S)$ exactly. Indeed $\chi_S'(t)=1/\Psi_S'(\chi_S(t))\to+\infty$ as $t\uparrow\Psi^\ast$, because $\Psi_S'(y_c)=0$; this is impossible if $\Phi_S$ were holomorphic at $R$. So the endpoint series converges only on the boundary of its disc, which is why the target side needs the monotone-convergence argument rather than absolute convergence inside the disc.

#### Lemma 6.11 (convexity of each coefficient along quantile segments)

**Source:** paper Lemma 6.11.

For $S_0,S_1\in\mathcal Q$ and every $n\ge1$, $t\mapsto F_n(S_t)$ is convex on $[0,1]$, where $S_t=(1-t)S_0+tS_1$.

*Proof.*

- By Lemma 6.8(1), $F_n(S)=\sum_{j\in J_{n-1}}c_j\,R(S)^n\prod_pm_p(S)^{j_p}$ with constants $c_j\ge0$. So it suffices to prove convexity of each $\beta_j(S):=R(S)^n\prod_pm_p(S)^{j_p}$.
- Let $|j|=\sum_pj_p$, and list the exponents with multiplicity as $p_1,\dots,p_{|j|}$ ($p$ repeated $j_p$ times). By Fubini–Tonelli,
$$\beta_j(S)=\int_{(0,1)^{|j|}}\exp\big(\lambda_S(u_1,\dots,u_{|j|})\big)\,d\mathbf u,\qquad\lambda_S(\mathbf u)=-\frac nk\int_0^1\log S(w)\,dw-\sum_{i=1}^{|j|}p_i\log S(u_i).$$
  For $|j|=0$ there is no outer integral.

- Fix $\mathbf u$. Each $t\mapsto S_t(w)$ is affine and $-\log$ is convex on $(0,\infty)$. So $t\mapsto\lambda_{S_t}(\mathbf u)$ is a nonnegative combination (an integral in $w$ plus a finite sum) of convex functions, hence convex.
- $\exp$ is convex and nondecreasing, so $t\mapsto e^{\lambda_{S_t}(\mathbf u)}$ is convex.
- The integrand is measurable and bounded in $[2^{-n/k-\sum_ip_i},1]$. Integrating the pointwise convexity inequality over $\mathbf u$ gives convexity of $t\mapsto\beta_j(S_t)$. $\square$

#### Definition 6.12 (directional derivative of the width)

**Source:** paper Definition 6.12.

Let $T_0\in\mathcal Q$ be strictly separated, $T\in\mathcal Q$, $v=T-T_0$ (so $|v|\le1$), and $T_s=T_0+sv$ ($s\in[0,1]$). Define
$$\dot M_k(T_0;v):=\lim_{s\downarrow0}\frac{M_k(T_s)-M_k(T_0)}s,$$
the one-sided derivative along the linear segment of *quantile functions*. By Lemma 6.13 it exists, and $M_k(T_s)$ is defined for small $s$. (It is not a derivative along the segment of measures $(1-s)\eta+s\nu$; the width is not convex along the latter, and nothing is claimed about it.)

#### Lemma 6.13 (existence and series form of $\dot M_k$)

**Source:** paper Lemma 6.13.

Under Definition 6.12, there is $s_1\in(0,1]$ such that the following hold.

1. $T_s$ is strictly separated for every $s\in[0,s_1]$.
2. The functions $g_n(s):=F_n(T_s)$ are $C^1$ on $[0,s_1]$, and
$$\sup_{[0,s_1]}|g_n|\le\frac\varrho n\varkappa_\ast^n,\qquad\sup_{[0,s_1]}|g_n'|\le\frac{\varrho\,\varkappa_\ast^n}{k\delta},$$
   for some $\varrho\in(0,a_{T_0})$, $\delta>0$, $\varkappa_\ast<1$.

3. The endpoints $x_\pm(s)$ of the main component of $W_{T_s}$ satisfy $x_+(s)=\sum_ng_n(s)$ and $x_-(s)=\sum_n(-1)^ng_n(s)$. They are $C^1$ on $[0,s_1]$, and $M_k(T_s)=2\sum_{n\,\mathrm{odd}}g_n(s)$.
4. $\dot M_k(T_0;v)$ exists, and
$$\dot M_k(T_0;v)=2\sum_{n\ \mathrm{odd}}g_n'(0)=x_+'(0)-x_-'(0)=-\sigma_+\int_0^1\frac{v(u)\,du}{T_0(u)-x_+}-\sigma_-\int_0^1\frac{v(u)\,du}{T_0(u)-x_-},$$
   with $x_\pm=x_\pm(0)$, $\sigma_+=1/W_{T_0}'(x_+)>0$ and $\sigma_-=-1/W_{T_0}'(x_-)>0$. The series converges absolutely.

For $T_0=T_{\eta_{k,a}}$ the integrals may be written as $\int_Iv(d)\,d\eta_{k,a}(d)/(d-x_\pm)$, with $v(d):=v(u)$ for $d=T_0(u)$. This is well defined because $T_0$ is injective: $F_0\circ T_0=\mathrm{id}$, where $F_0(d)=\eta_{k,a}([a,d])$ is continuous ($\eta_{k,a}$ has no atoms).

*Proof.*

- *Choice of constants.* By strict separation and Lemma 6.4, pick $\varrho\in(0,a_{T_0})$ with $\Psi_{T_0}(\varrho)>R(T_0)$. Let $\delta=(a_{T_0}-\varrho)/2$.
  - Since $T\ge1$ and $T_0\le2$, $v\ge-1$, so $T_s\ge a_{T_0}-s$ a.e. For $s\le\delta$: $a_{T_s}\ge\varrho+\delta$, and $T_s-\varrho\ge\delta$ a.e.
- *Uniform ratio.* Put $\varkappa(s):=R(T_s)/\Psi_{T_s}(\varrho)=\mathcal R_{T_s}(\varrho)/\varrho=\varrho^{-1}\exp(-\frac1k\int\log(T_s-\varrho))$ by (6.5).
  - The integrand lies in $[\log\delta,\log2]$ and is continuous in $s$. By dominated convergence, $\varkappa$ is continuous on $[0,\delta]$.
  - Since $\varkappa(0)<1$, choose $s_1\le\delta$ with $\varkappa(s)\le\varkappa_\ast:=\frac{1+\varkappa(0)}2<1$ on $[0,s_1]$.
  - Then $\Psi_{T_s}(\varrho)>R(T_s)$ with $\varrho<a_{T_s}$, which is (1).
- *(2).* For $|y|=\varrho$ and $s\in[0,s_1]$, $\operatorname{Re}(T_s(u)-y)\ge\delta$ a.e. Hence $s\mapsto\operatorname{Log}(T_s(u)-y)$ is $C^1$ with derivative $v/(T_s-y)$, bounded by $1/\delta$.
  - Differentiation under $\int du$ gives $\partial_s\mathcal R_{T_s}(y)=-\frac1k\mathcal R_{T_s}(y)\int_0^1\frac{v(u)}{T_s(u)-y}du$, jointly continuous in $(s,y)$.
  - Differentiating the Cauchy integral $g_n(s)=\frac1{2\pi in}\oint_{|y|=\varrho}\mathcal R_{T_s}^ny^{-n}dy$ under the integral sign gives
$$g_n'(s)=\frac1{2\pi i}\oint_{|y|=\varrho}\mathcal R_{T_s}(y)^ny^{-n}\Big(-\frac1k\int_0^1\frac{v\,du}{T_s-y}\Big)dy,$$
    continuous in $s$.

  - Both bounds follow as in Lemma 6.8(3), using $|\mathcal R_{T_s}(y)|\le\mathcal R_{T_s}(\varrho)$ on $|y|=\varrho$ and $\mathcal R_{T_s}(\varrho)/\varrho=\varkappa(s)\le\varkappa_\ast$.
- *(3).* Proposition 6.10(1) applied to each $T_s$ gives the identities. By (2), $\sum g_n$ and $\sum g_n'$ converge uniformly on $[0,s_1]$ (Weierstrass M-test), and termwise differentiation gives $x_\pm\in C^1[0,s_1]$ (one-sided at $0$).
- *(4).* $M_k(T_s)=x_+(s)-x_-(s)$ is $C^1$ on $[0,s_1]$, with derivative $\sum(1-(-1)^n)g_n'$. At $s=0$ this is the claimed series, so the limit in Definition 6.12 exists.
  - For the closed form, let $\Omega(x,s)=W_{T_s}(x)=k\log|x|+\int\log(T_s(u)-x)du$ on $\{x\le\varrho,\ x\ne0\}\times[0,s_1]$, where $T_s-x\ge\delta$.
  - $\Omega$ is $C^1$, with $\partial_x\Omega=k/x-\int(T_s-x)^{-1}$ and $\partial_s\Omega=\int v/(T_s-x)$, both jointly continuous by dominated convergence.
  - By Lemma 6.6, $x_+(s)\in(0,\varrho)$ and $x_-(s)<0$, and $\Omega(x_\pm(s),s)\equiv0$. The chain rule at $s=0$ gives $x_\pm'(0)=-\partial_s\Omega/\partial_x\Omega$.
  - Here $\partial_x\Omega(x_\pm,0)=W_{T_0}'(x_\pm)\ne0$, by the simple crossings of Lemma 6.6. $\square$

*Remark (two-sided derivative).* After possibly shrinking $s_1$, the crossings $s\mapsto x_\pm(s)$ are in fact $C^1$ on $[-s_1,s_1]$: $T_s-x\ge\delta$ still holds for $|s|\le\delta$, and values of $T_s$ above $2$ are harmless for the holomorphic representation. The simple crossings persist by the implicit function theorem on this smaller interval. So differentiation at $s=0$ is two-sided, and $\dot M_k$, called a right derivative throughout, coincides with the two-sided derivative (Lemma 7.4).

#### Theorem 6.14 (convex supporting inequality)

**Source:** paper Theorem 6.14.

Let $k>0$ and let $T_0\in\mathcal Q$ be strictly separated. Examples:

- the quantile of $\eta_{k,a}$ under (6.3) with $1\le a<2$, whenever $\sup_{(0,a)}W_0>0$ (Proposition 6.3(6) gives $W_0$ in closed form);
- more generally, any strictly separated $T_0\in\mathcal Q$.

Let $T\in\mathcal Q$ be admissible (strictly separated or in contact). In particular, $T$ may be the quantile of any atomic normal-form target (Lemma 6.7). Then, with $v=T-T_0$,
$$M_k(T)\ \ge\ M_k(T_0)+\dot M_k(T_0;v).\tag{6.8}$$
This is Wang's (4.13).

*Proof.*

- *Termwise inequality.* Let $g_n(s)=F_n(T_0+sv)$, $s\in[0,1]$. By Lemma 6.11, $g_n$ is convex on $[0,1]$. For $s\in(0,1]$, $g_n(s)\le(1-s)g_n(0)+sg_n(1)$, i.e. $\frac{g_n(s)-g_n(0)}s\le g_n(1)-g_n(0)$. Letting $s\downarrow0$ (Lemma 6.13(2)) gives
$$g_n(1)\ge g_n(0)+g_n'(0)\qquad(n\ge1).$$

- *Summation.* Multiply by $2$ and sum over odd $n$. The three series converge:
  - $2\sum_{\rm odd}g_n(1)=M_k(T)$ by Proposition 6.10 (either case of admissibility);
  - $2\sum_{\rm odd}g_n(0)=M_k(T_0)$ by Proposition 6.10(1);
  - $2\sum_{\rm odd}g_n'(0)=\dot M_k(T_0;v)$ by Lemma 6.13(4), absolutely.
- A termwise inequality between convergent series passes to the sums. $\square$

*Remarks.*

- No truncation-then-limit argument and no Abel widths are needed. The inequality holds term by term, and all three series are known to converge.
- *Equality case of (6.3).* If $a=2(k/(k+1))^2$, the density of $\eta_{k,a}$ vanishes like $\sqrt{d-a}$ at $a$ (but still $\operatorname{ess\,inf}T_0=a$), $\int d\eta/(d-y)$ stays bounded as $y\uparrow a$, and $y_c(T_0)=a$. This is why "the first positive critical value" of the source must be read as the supremum $\Psi^\ast$; in that case $T_0$ is strictly separated iff $\sup_{(0,a)}W_0>0$ (not "$\max$").
- *What the later sections use.* Proposition 6.3 (density, positivity (6.3), mass, platform identity (6.4) with $C(k,a)=\log H+k\log D_0(a)$, closed-form distribution function, closed form of $W_0$ off $I$); Lemma 6.6 (simple crossings are automatic under strict separation; to certify strict separation of the reference it suffices to exhibit one $\varrho\in(0,a)$ with $W_0(\varrho)>0$); Theorem 6.14 with the explicit derivative formula of Lemma 6.13(4).

---

## The endpoint-corrected adjoint identity and inequality

**Source:** paper §7, Theorem 7.1 and Lemmas 7.2–7.10.

### 7.0 Setting, hypotheses, and the link with §6

**Parameters.**

- Fix $k\ge1$ and $1\le a<2$ with $a\ge2\big(\tfrac k{k+1}\big)^2$ (condition (6.3)).
- Put $I=[a,2]$, $c=\frac{a+2}2$, $\ell=\frac{2-a}2$, and $d(\theta)=c-\ell\cos\theta$ for $\theta\in[0,\pi]$; so $d(0)=a$ and $d(\pi)=2$.
- $de_I(d)=\dfrac{\mathrm dd}{\pi\sqrt{(d-a)(2-d)}}$, i.e. $de_I=d\theta/\pi$. Indeed $\sqrt{(d(\theta)-a)(2-d(\theta))}=\ell\sin\theta$ and $\mathrm dd=\ell\sin\theta\,d\theta$.

**Reference.**

- $\alpha(d)=k+1-\dfrac{k\sqrt{2a}}d$ and $d\eta=\alpha\,de_I$; this is $\eta_{k,a}$ of Proposition 6.3. We also write $\alpha(\theta)=\alpha(d(\theta))$.
- $F_0(d)=\eta([a,d])$, and $T_0=F_0^{-1}:(0,1)\to(a,2)$ is the reference quantile.
- $W_0(x)=k\log|x|+\int_I\log|x-e|\,d\eta(e)$.

**Hypothesis (H)** (Wang's (4.8); certified for the calibrated parameters in §9).

- The component of $\{W_0<0\}$ containing $0$ is $(x_-,x_+)$, with $x_-<0<x_+<a$.
- The crossings are simple: $W_0'(x_-)<0<W_0'(x_+)$.

*(H) is equivalent to strict separation of $T_0$* (Definition 6.5). If (H) holds, then $W_0(x_+)=0$, $W_0'(x_+)>0$ and $x_+<a$ give $W_0>0$ just to the right of $x_+$, i.e. $\sup_{(0,a)}W_0>0$. Conversely, Lemma 6.6 gives (H) from strict separation, and the $x_\pm$, $\sigma_\pm$ of §6 and of this section coincide.

**Adjoint data.** For $j\in\{-,+\}$:

- $\sigma_-=-1/W_0'(x_-)>0$ and $\sigma_+=1/W_0'(x_+)>0$;
- $K_j=\sqrt{(a-x_j)(2-x_j)}$ and $\rho_j=\dfrac\ell{c-x_j+K_j}$;
- $D_\xi=\sum_j\dfrac{\sigma_jK_j}{a-x_j}$ and $N(d)=D_\xi-\sum_j\dfrac{\sigma_jK_j}{d-x_j}$;
- $d\xi=\dfrac{N(d)\,\mathrm dd}{\pi\sqrt{(d-a)(2-d)}}$ (Wang's (4.10)), i.e. $d\xi=B(\theta)\,d\theta/\pi$ with $B(\theta)=N(d(\theta))$;
- $\Gamma=\dfrac{\sigma_-}{K_-}+\dfrac{\sigma_+}{K_+}$ and $a_\pi=\alpha(2)$.

**Target.**

- $T$ is the quantile of $\sum_{i=1}^Nq_i\delta_{d_i}$, with $1\le d_1<\dots<d_N\le2$, $q_i>0$ and $\sum q_i=1$.
- $T=d_i$ on $I_i=[u_{i-1},u_i)$, where $u_i=q_1+\dots+q_i$ and $u_0=0$. (Block endpoints are null sets for every measure used below, so the choice of half-open convention is immaterial.)
- Spatial blocks: $\mathcal I_i=[\beta_{i-1},\beta_i]$ with $\beta_i=T_0(u_i)$, $\beta_0=a$ and $\beta_N=2$. Angular block ends: $d(\theta_i)=\beta_i$, so $0=\theta_0<\theta_1<\dots<\theta_N=\pi$.
- Material velocity: $v=T-T_0$ on $(0,1)$. In the spatial variable, $v(d)=d_i-d$ for $d\in\operatorname{int}\mathcal I_i$.
- $F=\alpha v$ and $\widetilde F(\theta)=F(d(\theta))$.
- The segment is $T_s=T_0+sv$, and $\mathcal M(s)=M_k(T_s)$, where $M_k(S)$ is the width of the component containing $0$ of $\{x:k\log|x|+\int_0^1\log|x-S(u)|\,du<0\}$.
- Note $|v|\le1$, since $T,T_0\in[1,2]$.
- *Conventions at the endpoint $2$.* $T_0<2$ on $(0,1)$, so $v(2)$ and $F(2)$ are **defined** as $v(2):=\lim_{u\uparrow1}v(u)=d_N-2$ and $\widetilde F(\pi):=a_\pi(d_N-2)$. The functional of §7.4 is applied to functions with this designated value at $\pi$ (left-continuous there).

**Link with §6.** Assume (H). The target $T$ of an atomized normal form is admissible (Lemma 6.7). So Theorem 6.14 gives
$$M_k(T)\ge M_k(T_0)+\dot M_k(T_0;v),$$
where $\dot M_k(T_0;v)$ is the right derivative $\mathcal M'(0^+)$ of Definition 6.12. Lemma 7.4 below shows independently that $\mathcal M$ is $C^1$ near $0$ and computes $\mathcal M'(0)$ in closed form (7.4); Lemma 7.5 shows that Wang's termwise series derivative is the same number. The formula (7.4) agrees with Lemma 6.13(4).

> **Theorem 7.1 (endpoint-corrected adjoint; source: paper Theorem 7.1).** Assume (H). Parts (i)–(ii) hold for every ordered atomic target as above. For the supporting inequality in (iii), assume additionally that the target is admissible, as every normal-form target is by Lemma 6.7:
> - (i) $g$ (Lemma 7.3) is defined at every point of $I$ except $a$, $2$ and the $\beta_i$, and $g\in L^1(\xi)$.
> - (ii) Exact endpoint identity:
> $$\dot M_k(T_0;v)-\int_Ig\,d\xi=-\Gamma\,F(2)=-a_\pi(d_N-2)\Big(\frac{\sigma_-}{K_-}+\frac{\sigma_+}{K_+}\Big).$$
> - (iii) $a_\pi>0$ and $\Gamma>0$. Hence, with Theorem 6.14, $M_k(T)\ge M_k(T_0)+\int_Ig\,d\xi$.

### 7.1 Elementary identities

#### Lemma 7.2

**Source:** paper Lemma 7.2.

- **(i) Poisson representation.**
  - For $x<a$ there is a unique $\rho_x\in(0,1)$ with $x=c-\frac\ell2(\rho_x+\rho_x^{-1})$, namely $\rho_x=\ell/(c-x+K_x)$ with $K_x=\sqrt{(a-x)(2-x)}$.
  - $K_x=\dfrac{\ell(1-\rho_x^2)}{2\rho_x}$ and $\dfrac{K_x}{d(\theta)-x}=P_{\rho_x}(\theta):=\dfrac{1-\rho_x^2}{1-2\rho_x\cos\theta+\rho_x^2}$.
  - For $0\le\rho<1$: $P_\rho(\theta)=1+2\sum_{n\ge1}\rho^n\cos n\theta$ (uniformly), and $\frac1\pi\int_0^\pi P_\rho\cos n\theta\,d\theta=\rho^n$ for $n\ge0$.
- **(ii) Reference density.**
  - $\sqrt{2a}/d(\theta)=P_{\rho_0}(\theta)$, where $\rho_0:=\rho_{x=0}=\dfrac{\sqrt2-\sqrt a}{\sqrt2+\sqrt a}$ (the $\rho_0$ of §6).
  - Hence $\alpha(d(\theta))=k+1-kP_{\rho_0}(\theta)$, and $\eta$ has total mass $1$.
  - $\alpha$ is increasing. $\alpha(a)\ge0$ exactly under $a\ge2(k/(k+1))^2$, so $\alpha>0$ on $(a,2]$.
  - $a_\pi=\alpha(2)=k+1-k\sqrt{a/2}=1+\dfrac{2k\rho_0}{1+\rho_0}\ge1>0$.
  - $F_0$ is continuous and strictly increasing on $[a,2]$. So $T_0$ is a homeomorphism $(0,1)\to(a,2)$, and the push-forward of Lebesgue measure on $(0,1)$ under $T_0$ is $\eta$.
- **(iii) Finite Hilbert transform.**
  - For bounded measurable $f$ on $[0,\pi]$ and $\theta\in(0,\pi)$, put $\mathcal Hf(\theta):=\lim_{\epsilon\downarrow0}\frac1\pi\int_{[0,\pi]\setminus(\theta-\epsilon,\theta+\epsilon)}\frac{f(\phi)\,d\phi}{\cos\theta-\cos\phi}$ when the limit exists.
  - $\mathcal H1\equiv0$ and $\mathcal H[\cos n\phi](\theta)=-U_{n-1}(\cos\theta)=-\dfrac{\sin n\theta}{\sin\theta}$ for $n\ge1$ ($U_{n-1}$ the Chebyshev polynomial of the second kind).
  - If $f$ is Lipschitz near $\theta$, then $\mathcal Hf(\theta)=\frac1\pi\int_0^\pi\frac{f(\phi)-f(\theta)}{\cos\theta-\cos\phi}\,d\phi$ (absolutely convergent).
  - In that case the same limit is obtained with *symmetric excision in the spatial variable*, i.e. removing $\{|d(\phi)-d(\theta)|\le\epsilon\}$.
- **(iv) Lipschitz bound.** If $f$ is Lipschitz on $[0,\pi]$ with constant $\operatorname{Lip}(f)$, then for all $\theta\in(0,\pi)$
$$|\mathcal Hf(\theta)|\le\frac{\pi\operatorname{Lip}(f)}2\,\lambda_{\mathcal H}(\theta),\qquad\lambda_{\mathcal H}(\theta)=\log\frac{\pi+\theta}\theta+\log\frac{2\pi-\theta}{\pi-\theta}\in L^1(0,\pi).$$

- **(v) Platform derivative.** For $d\in(a,2)$: $\dfrac kd+\mathrm{PV}\!\displaystyle\int_I\frac{d\eta(e)}{d-e}=0$ (PV symmetric in $e$).
- **(vi) Chebyshev integrals.**
  - $\varepsilon_n:=\frac1\pi\int_0^\pi U_{n-1}(\cos\theta)\,d\theta$ equals $1$ for odd $n$ and $0$ for even $n$.
  - $\Sigma_n(\rho):=\frac1\pi\int_0^\pi P_\rho\,U_{n-1}(\cos\theta)\,d\theta$ equals $\dfrac{1+\rho^2-2\rho^{n+1}}{1-\rho^2}$ for odd $n$ and $\dfrac{2\rho(1-\rho^n)}{1-\rho^2}$ for even $n$.

*Proof.*

- **(i)**
  - $\rho+\rho^{-1}=2(c-x)/\ell>2$, because $c-x>\ell\iff x<a$. The smaller root is $\rho_x=\frac{(c-x)-\sqrt{(c-x)^2-\ell^2}}\ell=\frac\ell{c-x+K_x}$, using $(c-x)^2-\ell^2=(a-x)(2-x)$.
  - Then $a-x=\frac\ell2(\rho+\rho^{-1}-2)=\frac\ell{2\rho}(1-\rho)^2$, $2-x=\frac\ell{2\rho}(1+\rho)^2$, and $d(\theta)-x=\frac\ell{2\rho}(1-2\rho\cos\theta+\rho^2)$. Taking the square root of the product of the first two gives $K_x$; dividing gives $P_\rho$.
  - The series is $\operatorname{Re}\frac{1+\rho e^{i\theta}}{1-\rho e^{i\theta}}$ expanded geometrically. Orthogonality gives the integrals.
- **(ii)**
  - Apply (i) at $x=0<a$: $K_0=\sqrt{2a}$ and $\rho_0=\ell/(c+\sqrt{2a})=(c-\sqrt{2a})/\ell$, since $c^2-2a=\ell^2$. Also $c-\sqrt{2a}=\frac12(\sqrt2-\sqrt a)^2$ and $\ell=\frac12(\sqrt2-\sqrt a)(\sqrt2+\sqrt a)$.
  - Mass: $\frac1\pi\int_0^\pi(k+1-kP_{\rho_0})=k+1-k=1$.
  - $\alpha(a)=k+1-k\sqrt{2/a}\ge0\iff a\ge2k^2/(k+1)^2$.
  - $\alpha(2)=k+1-k\sqrt{a/2}$. Also $P_{\rho_0}(\pi)=\frac{1-\rho_0}{1+\rho_0}=\sqrt{a/2}$.
  - The density of $\eta$ is positive on $(a,2)$, which gives the last claims.
- **(iii)** Fix $\theta\in(0,\pi)$ and put $G_\theta(\phi)=\log\left|\dfrac{\sin\frac{\phi-\theta}2}{\sin\frac{\phi+\theta}2}\right|$.
  - Derivative: $G_\theta'(\phi)=\frac12\big[\cot\frac{\phi-\theta}2-\cot\frac{\phi+\theta}2\big]=\dfrac{\sin\theta}{2\sin\frac{\phi-\theta}2\sin\frac{\phi+\theta}2}=\dfrac{\sin\theta}{\cos\theta-\cos\phi}$ for $\phi\ne\theta$.
  - Endpoint values: $G_\theta(0)=\log1=0$ and $G_\theta(\pi)=\log\frac{\cos(\theta/2)}{\cos(\theta/2)}=0$.
  - Hence, for excision $[\theta-\epsilon_1,\theta+\epsilon_2]$,
$$\frac1\pi\int_{[0,\pi]\setminus[\theta-\epsilon_1,\theta+\epsilon_2]}\frac{d\phi}{\cos\theta-\cos\phi}=\frac{G_\theta(\theta-\epsilon_1)-G_\theta(\theta+\epsilon_2)}{\pi\sin\theta}=\frac1{\pi\sin\theta}\Big[\log\frac{\sin(\epsilon_1/2)}{\sin(\epsilon_2/2)}+\log\frac{\sin(\theta+\epsilon_2/2)}{\sin(\theta-\epsilon_1/2)}\Big].$$

    - With $\epsilon_1=\epsilon_2$ this tends to $0$, so $\mathcal H1=0$.
    - With spatial excision, $\cos(\theta-\epsilon_1)-\cos\theta=\epsilon/\ell=\cos\theta-\cos(\theta+\epsilon_2)$. So $\epsilon_{1,2}=\frac\epsilon{\ell\sin\theta}(1+o(1))$, and the limit is again $0$.
  - $n=1$: $\frac{\cos\phi}{\cos\theta-\cos\phi}=-1+\frac{\cos\theta}{\cos\theta-\cos\phi}$, so $\mathcal H[\cos\phi]=-1=-U_0$.
  - Recurrence: $\cos(n+1)\phi+\cos(n-1)\phi=2\cos\theta\cos n\phi-2(\cos\theta-\cos\phi)\cos n\phi$ and $\frac1\pi\int_0^\pi\cos n\phi=0$ for $n\ge1$. These give $\mathcal H_{n+1}=2\cos\theta\,\mathcal H_n-\mathcal H_{n-1}$ with $\mathcal H_0=0$ and $\mathcal H_1=-1$ (where $\mathcal H_n:=\mathcal H[\cos n\phi]$). This is the recurrence of $-U_{n-1}$ (with $U_{-1}=0$, $U_0=1$).
  - Lipschitz case: write $f=(f-f(\theta))+f(\theta)$.
    - The first part is absolutely integrable: $|f(\phi)-f(\theta)|\le\operatorname{Lip}(f)|\phi-\theta|$ near $\theta$, $|\cos\theta-\cos\phi|\ge c_\theta|\phi-\theta|$ near $\theta$, and the denominator is bounded below elsewhere. So every excision scheme converges to the same absolute integral.
    - The constant part is handled by the two excision computations above.
- **(iv)**
  - Put $w=(\theta+\phi)/2\in[0,\pi]$ and use $\sin x\ge2x/\pi$ on $[0,\pi/2]$. Then $\sin w\ge\frac1\pi\hat m$ with $\hat m=\min(\theta+\phi,2\pi-\theta-\phi)$, and $|\sin\frac{\theta-\phi}2|\ge|\theta-\phi|/\pi$.
  - So $|\cos\theta-\cos\phi|\ge\frac2{\pi^2}\hat m|\theta-\phi|$, and
$$\Big|\frac{f(\phi)-f(\theta)}{\cos\theta-\cos\phi}\Big|\le\frac{\pi^2\operatorname{Lip}(f)}2\Big(\frac1{\theta+\phi}+\frac1{2\pi-\theta-\phi}\Big).\tag{7.1}$$

  - Integrate in $\phi$ and use (iii).
- **(v)**
  - $\alpha$ is smooth near $d$. By (iii), transported to the spatial variable, $\mathrm{PV}\int\frac{\alpha(e)\,de_I(e)}{d-e}=-\int\frac{\alpha(e)-\alpha(d)}{e-d}\,de_I(e)$, since the PV of the constant vanishes.
  - $\alpha(e)-\alpha(d)=k\sqrt{2a}\,\frac{e-d}{de}$, and $\int\frac{de_I(e)}e=\frac1{K_0}\cdot\frac1\pi\int_0^\pi P_{\rho_0}=\frac1{\sqrt{2a}}$ by (i) at $x=0$.
  - So the PV equals $-k/d$.
- **(vi)** Use $\frac{\sin n\theta}{\sin\theta}=\sum_{m=0}^{n-1}e^{i(n-1-2m)\theta}$:
  - $U_{2p}=1+2\sum_{l=1}^p\cos2l\theta$ and $U_{2p-1}=2\sum_{l=1}^p\cos(2l-1)\theta$;
  - then apply (i): $1+2\sum_{l\le p}\rho^{2l}=\frac{1+\rho^2-2\rho^{2p+2}}{1-\rho^2}$ and $2\sum_{l\le p}\rho^{2l-1}=\frac{2\rho(1-\rho^{2p})}{1-\rho^2}$. $\square$

### 7.2 (a) The material first variation $g$

For $u\in(0,1)$ and small $|s|$ put
$$\Phi_u(s)=k\log T_s(u)+\int_0^1\log|T_s(u)-T_s(w)|\,dw .$$

#### Lemma 7.3

**Source:** paper Lemma 7.3.

Let $u\in\operatorname{int}I_i$ and $d=T_0(u)\in\operatorname{int}\mathcal I_i$.

- (a1) $\Phi_u$ is differentiable at $s=0$, and $g(d):=\Phi_u'(0)$ is given by
$$g(d)=\frac{k\,v(d)}d+\int_I\frac{v(d)-v(e)}{d-e}\,d\eta(e)=\frac{k(d_i-d)}d-1+\sum_{j\ne i}(d_i-d_j)\int_{\mathcal I_j}\frac{d\eta(e)}{d-e},\tag{7.2}$$
  an absolutely convergent integral. Its integrand equals $-1$ on $\mathcal I_i$ and is bounded on $\bigcup_{j\ne i}\mathcal I_j$.

- (a2) Principal-value form:
$$g(d)=\mathrm{PV}\!\int_I\frac{F(e)}{e-d}\,de_I(e)=\frac1\ell\,\mathcal H\widetilde F(\theta),\qquad d=d(\theta),\tag{7.3}$$
  with the PV symmetric in $e$ or in $\phi$ (same value).

- (a3) Regularity: $g$ is real-analytic on each $\operatorname{int}\mathcal I_i$ and has at most logarithmic singularities at the $\beta_i$ (explicitly in §7.5). It is undefined at $u=u_i$, a null set. Only local Lipschitz continuity of $v$ near $d$ is used; no global regularity of $v$ is needed.

*Proof.*

- Change variables $e=T_0(w)$ (Lemma 7.2(ii)). For $w\in I_j$ put $X=d-e$ and $Y=d_i-d_j$. Then $T_s(u)-T_s(w)=X+s(v(d)-v(e))$ and $v(d)-v(e)=Y-X$, so $T_s(u)-T_s(w)=(1-s)X+sY$.
- **$j=i$** ($Y=0$):
  - The contribution is $q_i\log(1-s)+\int_{I_i}\log|X|\,dw$. It is finite because $\log|d-\cdot|$ is $\eta$-integrable: in $\theta$ the density is bounded.
  - Its derivative at $0$ is $-q_i$.
- **$j\ne i$**: $X$ and $Y$ have the same sign (the blocks and the atoms are both ordered), $|X|\ge\delta_u:=\operatorname{dist}(d,\bigcup_{j\ne i}\mathcal I_j)>0$, and $|Y-X|\le1$ (only boundedness matters).
  - For $s\in[0,1]$: $|(1-s)X+sY|\ge\min(|X|,|Y|)\ge\min(\delta_u,\gamma)$, where $\gamma=\min_{i\ne j}|d_i-d_j|>0$.
  - For $-\delta_u/2\le s<0$: $|(1-s)X+sY|\ge\delta_u/2$.
  - So $\partial_s\log|(1-s)X+sY|=(Y-X)/((1-s)X+sY)$ is uniformly bounded, and differentiation under the integral is legitimate.
- $k\log(d+sv(d))$ has derivative $kv(d)/d$.
- Summing, and using $\frac{Y-X}X=\frac{v(d)-v(e)}{d-e}$ with value $-1$ on $\mathcal I_i$, gives (7.2).
- For (a2):
  - Truncate the absolutely convergent integral in (7.2) at $|e-d|>\epsilon$ and split it linearly: $\int_{|e-d|>\epsilon}\frac{v(d)-v(e)}{d-e}\,d\eta=v(d)\int_{|e-d|>\epsilon}\frac{d\eta}{d-e}-\int_{|e-d|>\epsilon}\frac{v(e)\,d\eta}{d-e}$.
  - As $\epsilon\to0$, the left side converges, and the first term tends to $-kv(d)/d$ by Lemma 7.2(v). Hence the last PV exists and $g(d)=\mathrm{PV}\int\frac{v(e)}{e-d}\,d\eta(e)=\mathrm{PV}\int\frac{F(e)}{e-d}\,de_I(e)$.
  - In angular variables $e-d=\ell(\cos\theta-\cos\phi)$. $\widetilde F$ is Lipschitz near $\theta$, so Lemma 7.2(iii) shows that spatial and angular symmetric excision give the same limit, namely $\frac1\ell\mathcal H\widetilde F(\theta)$.
- (a3) follows from (7.2) and the closed form in §7.5. $\square$

(7.2) is exactly the "unreduced first variation" used in Wang's block reduction; in quantile variables it is (8.1) below.

### 7.3 (b) First variation of the reference width

#### Lemma 7.4

**Source:** paper Lemma 7.4.

Let $T:(0,1)\to[1,2]$ be measurable (atomicity is not needed here) and $s_0:=(a-x_+)/3$.

- There is $s_2\in(0,s_0]$ such that for $|s|\le s_2$ the main component of $\{W_{T_s}<0\}$ is $(x_-(s),x_+(s))$, where $x_\pm(\cdot)$ are $C^1$ and $x_\pm(0)=x_\pm$.
- Hence $\mathcal M(s)=x_+(s)-x_-(s)$ is $C^1$ on $[-s_2,s_2]$, and
$$\mathcal M'(0)=-\sum_{j=\pm}\sigma_j\int_I\frac{F(d)}{d-x_j}\,de_I(d)=-\sum_j\frac{\sigma_j}{K_j}\Big(f_0+2\sum_{n\ge1}f_n\rho_j^n\Big),\tag{7.4}$$
  where $f_n=\frac1\pi\int_0^\pi\widetilde F\cos n\theta$.

*Proof.*

- **Setup.** $|v|\le1$, so $T_s(u)\in[a-s_0,2+s_0]$ for $|s|\le s_0$.
  - On $\mathcal U=\big((-\infty,x_++s_0]\setminus\{0\}\big)\times[-s_0,s_0]$ we have $T_s(u)-x\ge s_0$.
  - So $W(x,s)=k\log|x|+\int_0^1\log|x-T_s(u)|\,du$ is $C^1$ there, with $\partial_xW=\frac kx+\int\frac{du}{x-T_s(u)}$ and $\partial_sW=\int\frac{v(u)\,du}{T_s(u)-x}$, both continuous by dominated convergence.
  - Moreover, with $\mathcal V_s(x):=\int\log|x-T_s|$, uniformly on $[x_--1,x_++s_0]$: $|\mathcal V_s(x)-\mathcal V_0(x)|\le|s|/s_0$ and $|\partial_x\mathcal V_s-\partial_x\mathcal V_0|\le|s|/s_0^2$.
- **Choice of $\delta$.** By (H) choose $\delta\in(0,s_0)$ with:
  - $W_0'\ge c_\ast>0$ on $[x_+-\delta,x_++\delta]$;
  - $W_0'\le-c_\ast$ on $[x_--\delta,x_-+\delta]$;
  - $x_-+\delta<0<x_+-\delta$.
- **Negativity inside.** On the compact set $[x_-+\delta,x_+-\delta]$, the upper semicontinuous function $W_0$ (with values in $[-\infty,0)$) attains its maximum $-\mu_\ast<0$.
- **Small $s$.** For $|s|\le s_2$ (small):
  - $W(\cdot,s)<0$ on $[x_-+\delta,x_+-\delta]$;
  - $W(\cdot,s)$ is strictly monotone on the two $\delta$-windows, with opposite signs at their ends;
  - hence each window contains exactly one zero $x_\pm(s)$;
  - therefore $W(\cdot,s)<0$ on $(x_-(s),x_+(s))$, with $W(x_\pm(s),s)=0$, and the main component is $(x_-(s),x_+(s))$.
- **Implicit function theorem.** $x_\pm$ are $C^1$ with $x_\pm'(0)=-\partial_sW(x_\pm,0)/W_0'(x_\pm)$, and $\partial_sW(x_j,0)=\int\frac{v\,du}{T_0-x_j}=\int_I\frac{v(e)\,d\eta(e)}{e-x_j}=\int_I\frac{F\,de_I}{e-x_j}$.
- **Signs.**
  - $x_+'(0)=-\sigma_+\partial_sW(x_+,0)$ and $x_-'(0)=+\sigma_-\partial_sW(x_-,0)$.
  - Subtracting gives the first form of (7.4).
  - The second form follows from $\frac1{d(\theta)-x_j}=\frac{P_{\rho_j}(\theta)}{K_j}$ and Lemma 7.2(i), valid for any $\widetilde F\in L^1$. $\square$

In particular $\dot M_k(T_0;v)=\mathcal M'(0)$ exists (two-sided), and (7.4) holds for the discontinuous atomic velocity: only $v\in L^\infty$ is used.

#### Lemma 7.5 (identification with the termwise series derivative)

**Source:** paper Lemma 7.5.

Use the notation of §6: $\Psi_S(y)=y\,\psi_S(y)$ with $\psi_S(y)=\exp\big(\frac1k\int_0^1\operatorname{Log}(1-y/S(u))\,du\big)$, $R(S)=\exp\big(-\frac1k\int\log S\big)$, and $a_n(S)=\frac1n[y^{n-1}]\psi_S(y)^{-n}$ (the coefficients of $\Phi_S$, since $\psi_S^{-1}=\mathcal R_S/R(S)$ by (6.5)). Then $s\mapsto\sum_{m\ge0}2a_{2m+1}(T_s)R(T_s)^{2m+1}$ is analytic on a complex disc $|s|<s_3$ and equals $\mathcal M(s)$ for real $s$. In particular its termwise derivative at $0$, equals $\mathcal M'(0)$.

*This lemma is not needed for the main line of the proof* (Theorem 6.14 is stated with the true derivative); it shows that the derivative used in Wang's text is the same number.

*Proof.*

- **Choice of $\tau$.** For real $0<y<a$: $\frac1kW_0(y)=\log\frac{\Psi_0(y)}{R(T_0)}$, with $\Psi_0=\Psi_{T_0}$. By (H), $W_0>0$ just right of $x_+$, so there is $\tau\in(x_+,a)$ with $m_\tau:=\Psi_0(\tau)>R(T_0)$.
- **Circle minimum.** For $|y|=\tau$ and $e\in(a,2)$: $|1-y/e|\ge1-\tau/e$. Hence $\min_{|y|=\tau}|\Psi_0(y)|=\Psi_0(\tau)=m_\tau$.
- **Complex $s$.** For complex $|s|\le s_3<(a-\tau)/2$, $\operatorname{Re}(1-y/T_s(u))>0$ on $|y|\le\tau$. So $\psi_{T_s}$ is analytic and zero-free in $(y,s)$, and $\Psi_{T_s}\to\Psi_0$ uniformly on $|y|=\tau$. Shrinking $s_3$, fix $\delta>0$ with $R(T_0)+2\delta<m_\tau-2\delta$, $\min_{|y|=\tau}|\Psi_{T_s}|\ge m_\tau-\delta$ and $|R(T_s)|\le R(T_0)+\delta$.
- **Coefficient bound.** Cauchy's formula $a_n(T_s)=\frac1{2\pi in}\oint_{|y|=\tau}\psi_{T_s}^{-n}y^{-n}\,dy$ gives:
  - $a_n(T_s)$ is analytic in $s$;
  - $|a_n(T_s)|\le\frac\tau n(m_\tau-\delta)^{-n}$.
  - So the odd series converges uniformly on $|s|\le s_3$ and is analytic (Weierstrass), and it may be differentiated termwise.
- **Identification for real $s$.** For real $s$ and $|z|<m_\tau-\delta$:
  - Rouché on $|y|=\tau$ shows that $\Psi_{T_s}(y)=z$ has exactly one root $\hat\Phi_s(z)$ in $|y|<\tau$; $\Psi_{T_s}$ has the single zero $y=0$ there.
  - $\hat\Phi_s$ is analytic, and it equals the Lagrange series $\sum a_n(T_s)z^n$ near $0$, hence on the whole disc.
  - The real crossings satisfy $\Psi_{T_s}(x_\pm(s))=\pm R(T_s)$. Indeed $W_{T_s}(y)=k\log(|\Psi_{T_s}(y)|/R(T_s))$ for real $y<\min T_s$, with $\Psi_{T_s}>0$ on $(0,\min T_s)$ and $<0$ on $(-\infty,0)$.
  - Both crossings lie in $|y|<\tau$: $x_+(s)\to x_+<\tau$; $|\Psi_0|$ is increasing on the negative axis with $|\Psi_0(-\tau)|\ge m_\tau>R(T_0)=|\Psi_0(x_-)|$, so $|x_-|<\tau$. This bound, proved at $s=0$, persists for real $|s|<\min(s_2,s_3)$ after shrinking $s_3$, by continuity of $x_\pm(s)$ (Lemma 7.4).
  - Hence $x_\pm(s)=\hat\Phi_s(\pm R(T_s))$, and $\mathcal M(s)=\hat\Phi_s(R)-\hat\Phi_s(-R)=2\sum a_{2m+1}R^{2m+1}$ with $R=R(T_s)$. $\square$

(The same Cauchy/Rouché argument also shows, without Pringsheim's theorem, that the reference inverse series converges absolutely at $\pm R(T_0)$ with room to spare.)

### 7.4 (c) The coefficient computation (cosine polynomials)

For bounded measurable $f$ on $[0,\pi]$ such that $\mathcal Hf$ exists a.e. and $\mathcal Hf\cdot B\in L^1$ (with $f(\pi)$ the designated value, §7.0), define the linear functional
$$\mathfrak L(f):=-\sum_j\frac{\sigma_j}{K_j}\cdot\frac1\pi\int_0^\pi fP_{\rho_j}\,d\theta-\frac1{\pi\ell}\int_0^\pi\mathcal Hf(\theta)B(\theta)\,d\theta+\Gamma f(\pi).$$

#### Lemma 7.6

**Source:** paper Lemma 7.6.

$\mathfrak L(p)=0$ for every cosine polynomial $p=f_0+2\sum_{n=1}^{n_1}f_n\cos n\theta$. This holds for arbitrary $x_\pm<a$ and real $\sigma_\pm$, provided $D_\xi:=\sum_j\sigma_jP_{\rho_j}(0)$ and $B=D_\xi-\sum_j\sigma_jP_{\rho_j}$. The identity is purely algebraic.

*Proof.*

- Constants:
  - $\frac1{K_j}=\frac{2\rho_j}{\ell(1-\rho_j^2)}$, so $\Gamma=\frac2\ell\sum_j\frac{\sigma_j\rho_j}{1-\rho_j^2}$;
  - $P_\rho(0)=\frac{1+\rho}{1-\rho}=\frac{(1+\rho)^2}{1-\rho^2}$.
- The three terms of $\mathfrak L(p)$:
  - First term, by Lemma 7.2(i): $-\sum_j\frac{\sigma_j}{K_j}(f_0+2\sum_nf_n\rho_j^n)$.
  - Second term, by Lemma 7.2(iii): $\mathcal Hp=-2\sum_nf_nU_{n-1}(\cos\theta)$. With (vi) the second term becomes $+\frac2\ell\sum_nf_n\big(D_\xi\varepsilon_n-\sum_j\sigma_j\Sigma_n(\rho_j)\big)$.
  - Third term: $\Gamma p(\pi)=\Gamma\big(f_0+2\sum_n(-1)^nf_n\big)$.
- Coefficient of $f_0$: $-\Gamma+\Gamma=0$.
- Coefficient of $f_n$, $n$ even: $-\frac4\ell\sum_j\frac{\sigma_j\rho_j^{n+1}}{1-\rho_j^2}-\frac4\ell\sum_j\frac{\sigma_j\rho_j(1-\rho_j^n)}{1-\rho_j^2}+2\Gamma=-2\Gamma+2\Gamma=0$.
- Coefficient of $f_n$, $n$ odd:
$$-\frac4\ell\sum_j\frac{\sigma_j\rho_j^{n+1}}{1-\rho_j^2}+\frac2\ell\sum_j\sigma_j\frac{(1+\rho_j)^2-(1+\rho_j^2-2\rho_j^{n+1})}{1-\rho_j^2}-2\Gamma=\frac2\ell\sum_j\frac{2\sigma_j\rho_j}{1-\rho_j^2}-2\Gamma=0.\qquad\square$$

So for $\widetilde F=p$, $\dot M_k-\int g\,d\xi=-\Gamma p(\pi)=-\Gamma F(2)$ (by (7.3), (7.4) and $d(\pi)=2$). This agrees with Wang's (4.23), including the sign and the factor. The parity bookkeeping (constant: $-\Gamma$; even: $-2\Gamma$; odd: $+2\Gamma$) matches $-\Gamma F(2)$, because $F(2)=f_0+2\sum(-1)^nf_n$.

### 7.5 (d) Passage to atomic targets

#### Lemma 7.7 (Lipschitz $f$)

**Source:** paper Lemma 7.7.

If $f$ is Lipschitz on $[0,\pi]$, then $\mathcal Hf\cdot B\in L^1$ and $\mathfrak L(f)=0$.

*Proof.*

- **Fejér approximation.**
  - The even $2\pi$-periodic extension of $f$ is Lipschitz with the same constant; across $0$ use $|\phi-\theta|\le\phi+\theta$ for $\phi,\theta\ge0$, and similarly at $\pi$.
  - Its Fejér means $p_m$ are cosine polynomials, with $\operatorname{Lip}(p_m)\le\operatorname{Lip}(f)$ (the kernel is positive with mass one) and $\|p_m-f\|_\infty\to0$ (Fejér).
  - Put $e_m=p_m-f$. Then $\operatorname{Lip}(e_m)\le2\operatorname{Lip}(f)$ and $\|e_m\|_\infty\to0$.
- **Convergence of the three terms.**
  - First term of $\mathfrak L(e_m)$: at most $\Gamma\|e_m\|_\infty\to0$.
  - Third term: $\Gamma|e_m(\pi)|\to0$.
  - Middle term. For each $\theta\in(0,\pi)$, $\mathcal He_m(\theta)=\frac1\pi\int\frac{e_m(\phi)-e_m(\theta)}{\cos\theta-\cos\phi}\,d\phi$ (Lemma 7.2(iii)).
    - The integrand tends to $0$ pointwise: it is at most $2\|e_m\|_\infty/|\cos\theta-\cos\phi|$.
    - It is dominated by (7.1) with $2\operatorname{Lip}(f)$, which is integrable in $\phi$. So $\mathcal He_m(\theta)\to0$.
    - By Lemma 7.2(iv), $|\mathcal He_m\cdot B|\le\pi\operatorname{Lip}(f)\|B\|_\infty\lambda_{\mathcal H}\in L^1$. Dominated convergence gives $\int\mathcal He_m\,B\to0$.
- **Conclusion.** Since $\mathfrak L(p_m)=0$ (Lemma 7.6), $\mathfrak L(f)=0$. $\square$

#### Lemma 7.8 (one jump)

**Source:** paper Lemma 7.8.

For $0<\omega<\pi$ and $\chi_\omega=\mathbf 1_{[\omega,\pi]}$:

- for $\theta\ne\omega$,
$$\mathcal H\chi_\omega(\theta)=-\frac1{\pi\sin\theta}\log\left|\frac{\sin\frac{\omega-\theta}2}{\sin\frac{\omega+\theta}2}\right|;\tag{7.5}$$

- for $t$ in a compact $[\omega-\epsilon_0,\omega+\epsilon_0]\subset(0,\pi)$, $|\mathcal H\chi_t(\theta)|\le C_1(1+|\log|\theta-t||)$ uniformly;
- $\mathfrak L(\chi_\omega)=0$.

*Proof.*

- **Formula (7.5).** It is $\frac1{\pi\sin\theta}[G_\theta(\pi)-G_\theta(\omega)]$ with $G_\theta(\pi)=0$ (Lemma 7.2(iii)). If $\theta\in(\omega,\pi)$, the symmetric excision adds a vanishing term.
- **Bound.** Write $\lambda_t(\theta)=\log|\sin\frac{t-\theta}2|-\log|\sin\frac{t+\theta}2|$.
  - $\lambda_t(0)=\lambda_t(\pi)=0$.
  - $\lambda_t'$ is bounded on $[0,t/2]$ and on $[(\pi+t)/2,\pi]$ (both cotangent arguments stay in a compact subset of $(0,\pi)$). So $|\lambda_t|\le C\min(\theta,\pi-\theta)$ there, and $|\mathcal H\chi_t|$ is bounded there.
  - In between, $\sin\theta$ is bounded below and $|\lambda_t|\le C+|\log|t-\theta||$.
- **Ramp approximation.** For $0<\epsilon<\epsilon_0$ let $\chi_{\omega,\epsilon}=\frac1{2\epsilon}\int_{\omega-\epsilon}^{\omega+\epsilon}\chi_t\,dt$ (a Lipschitz ramp). Lemma 7.7 gives $\mathfrak L(\chi_{\omega,\epsilon})=0$.
  - As $\epsilon\to0$ the first term converges ($L^1$), and the third is constant: $\chi_{\omega,\epsilon}(\pi)=1=\chi_\omega(\pi)$.
  - Middle term, step 1. For fixed $\theta$, $\mathcal H\chi_{\omega,\epsilon}(\theta)=\frac1\pi\int\frac{\chi_{\omega,\epsilon}(\phi)-\chi_{\omega,\epsilon}(\theta)}{\cos\theta-\cos\phi}\,d\phi=\frac1{2\epsilon}\int\mathcal H\chi_t(\theta)\,dt$. This is Tonelli: $\chi_t(\phi)-\chi_t(\theta)\ne0$ only for $\phi$ on the far side of $t$, where $\int\frac{d\phi}{|\cos\theta-\cos\phi|}\le C(1+|\log|\theta-t||)$, which is integrable in $t$.
  - Middle term, step 2. By the uniform log bound and Fubini, $\int_0^\pi\mathcal H\chi_{\omega,\epsilon}B=\frac1{2\epsilon}\int_{\omega-\epsilon}^{\omega+\epsilon}\Theta(t)\,dt$, with $\Theta(t):=\int_0^\pi\mathcal H\chi_tB$.
  - Middle term, step 3. $\Theta$ is continuous at $\omega$:
    - $\mathcal H\chi_t(\theta)\to\mathcal H\chi_\omega(\theta)$ for $\theta\ne\omega$, by (7.5);
    - the family $\{C_1(1+|\log|\cdot-t||)\}_t$ is uniformly integrable. Indeed, for $t\in[0,\pi]$ and measurable $E\subseteq[0,\pi]$ with $0<m=|E|\le2$: since $|\theta-t|\le\pi$, $|\log|\theta-t||\le\log\pi+(-\log|\theta-t|)_+$. The function $(-\log|\theta-t|)_+$ decreases in $|\theta-t|$, so its integral over $E$ is at most its integral over the interval of length $m$ centred at $t$. Hence
$$\int_E|\log|\theta-t||\,d\theta\le m\log\pi+2\int_0^{m/2}(-\log r)\,dr=m\log\pi+m\Big(1+\log\frac2m\Big)\xrightarrow[m\to0]{}0,$$
      uniformly in $t$;

    - Vitali's theorem applies.
  - Hence $0=\mathfrak L(\chi_{\omega,\epsilon})\to\mathfrak L(\chi_\omega)$. $\square$

#### Proposition 7.9 (atomic targets)

**Source:** paper Proposition 7.9.

For the atomic target, $g\in L^1(\xi)$, and
$$\dot M_k(T_0;v)-\int_Ig\,d\xi=-\Gamma\,a_\pi(d_N-2).$$

*Proof.*

- **Jump decomposition.** On $(\theta_{i-1},\theta_i)$, $\widetilde F$ is the restriction of the analytic function $\widetilde F_i(\theta)=\alpha(d(\theta))(d_i-d(\theta))$.
  - Put $\Delta_i=\widetilde F_{i+1}(\theta_i)-\widetilde F_i(\theta_i)=\alpha(\beta_i)(d_{i+1}-d_i)\ge0$, for $1\le i\le N-1$.
  - $F_c:=\widetilde F-\sum_i\Delta_i\chi_{\theta_i}$ extends to a continuous function on $[0,\pi]$ that is $C^1$ on each $[\theta_{i-1},\theta_i]$, hence Lipschitz.
- **Transform of $\widetilde F$.** For $\theta\notin\{\theta_i\}$, $\mathcal H\widetilde F(\theta)=\mathcal HF_c(\theta)+\sum_i\Delta_i\mathcal H\chi_{\theta_i}(\theta)$ (linearity of limits).
  - By Lemma 7.3(a2) this equals $\ell\,g(d(\theta))$.
  - By Lemma 7.2(iv) and Lemma 7.8, $|g(d(\theta))|\le C\big(\lambda_{\mathcal H}(\theta)+\sum_i(1+|\log|\theta-\theta_i||)\big)$.
  - $B$ is bounded, so $g\in L^1(\xi)$. Also $\int_Ig\,d\xi=\frac1\pi\int_0^\pi g(d(\theta))B(\theta)\,d\theta$, using $d\xi=B\,d\theta/\pi$.
- **Assembly.** By (7.4), $\dot M_k(T_0;v)=-\sum_j\frac{\sigma_j}{K_j}\frac1\pi\int\widetilde FP_{\rho_j}$.
  - Therefore $\dot M_k-\int g\,d\xi+\Gamma\widetilde F(\pi)=\mathfrak L(F_c)+\sum_i\Delta_i\mathfrak L(\chi_{\theta_i})=0$ (Lemmas 7.7 and 7.8).
  - $\widetilde F(\pi)=F_c(\pi)+\sum\Delta_i$ (since $\chi_{\theta_i}(\pi)=1$), and this is $\widetilde F_N(\pi)=\alpha(2)(d_N-2)=a_\pi v(2)$. $\square$

**Shape of the singularity.** By (7.5), near a block boundary
$$g(d(\theta))=-\frac{\Delta_i}{\pi\ell\sin\theta_i}\log|\theta-\theta_i|+O(1)\to+\infty,$$
an integrable logarithmic spike. So $\int g\,d\xi$ is finite.

### 7.6 (e) Positivity and finiteness of $\xi$

#### Lemma 7.10

**Source:** paper Lemma 7.10.

- (i) $N(a)=0$ and $N'(d)=\sum_j\frac{\sigma_jK_j}{(d-x_j)^2}>0$ on $I$. So $N>0$ on $(a,2]$, and $\xi$ is a positive measure, positive on every nonempty open subinterval of $I$.
- (ii) In angles: $B(\theta)=\sum_j\sigma_j\big(P_{\rho_j}(0)-P_{\rho_j}(\theta)\big)$.
  - $B(0)=0$ and $B(\theta)=O(\theta^2)$, since $B$ is even and smooth.
  - $B(\pi)=b_\pi:=\sum_j\frac{4\sigma_j\rho_j}{1-\rho_j^2}=2\ell\Gamma>0$.
- (iii) $R_\xi:=\xi(I)=\frac1\pi\int_0^\pi B=D_\xi-\sigma_--\sigma_+=\sum_j\frac{2\sigma_j\rho_j}{1-\rho_j}$. This is finite and positive; it is Wang's calibration constant "$R_0$" (not to be confused with $R(T_0)$ of §6).

*Proof.*

- $d-x_j>0$ on $I$ because $x_j<a$, and $\sigma_j,K_j>0$; $N(a)=0$ is the definition of $D_\xi$.
- (ii) follows from $\frac{K_j}{d(\theta)-x_j}=P_{\rho_j}(\theta)$; $P_\rho$ is decreasing in $\theta$ on $[0,\pi]$.
- (iii) follows from Lemma 7.2(i).
- Also $\Gamma=\frac2\ell\sum_j\frac{\sigma_j\rho_j}{1-\rho_j^2}=\frac{b_\pi}{2\ell}$. $\square$

### 7.7 Proof of Theorem 7.1

- (i) is Lemma 7.3 together with Proposition 7.9.
- (ii) is Proposition 7.9 together with Lemma 7.4.
- (iii) Positivity:
  - $a_\pi\ge1$ (Lemma 7.2(ii));
  - $\Gamma>0$ (since $\sigma_\pm>0$ by (H) and $K_\pm>0$);
  - $v(2)=d_N-2\le0$.
  - Hence $\dot M_k(T_0;v)-\int g\,d\xi=-\Gamma a_\pi(d_N-2)\ge0$, with equality iff $d_N=2$.
  - For an admissible target, Theorem 6.14 now gives $M_k(T)\ge M_k(T_0)+\dot M_k(T_0;v)\ge M_k(T_0)+\int_Ig\,d\xi$. The atomic normal form supplies this admissibility; (H) supplies strict separation of the reference. $\square$

*Where the correction comes from.* The Cauchy transform of $\xi$ on $I$ is $\mathrm{PV}\int\frac{d\xi(d)}{d-e}=\sum_j\frac{\sigma_j}{e-x_j}$ (from $\mathcal HP_\rho=-\frac{2\rho}{1-2\rho\cos\theta+\rho^2}$). A *formal* Fubini swap of the two principal-value integrals would therefore give $\int g\,d\xi=\dot M$ with no correction. The swap is illegitimate because both $e_I$ and $\xi$ have inverse-square-root densities at $d=2$ ($B(\pi)\ne0$), and the defect is exactly $-\Gamma F(2)$. This is why the regularisation argument of Lemmas 7.7–7.8 is indispensable.

---

## Block reduction, circle rearrangement, and scalar inequalities

**Source:** paper §8, Lemmas 8.1–8.18, Theorems 8.4, 8.8 and 8.19, Proposition 8.6 and Corollary 8.20.

### 8.0 Notation and standing hypotheses

**Target.** Normal form (Definition 3.5): $k\ge1$; the atomized target is $\nu=\sum_{i=1}^Nq_i\delta_{d_i}$ with $1<d_1<\dots<d_N\le2$, $q_i>0$ and $\sum q_i=1$. Then $W(x)=k\log|x|+\sum_iq_i\log|x-d_i|$, $M_k=M_k(T)$ is the width of the main component, and $R_i$, $\mathcal J_k=M_k+2\sum_iR_i$ are as in Definition 3.5. The strict inequality $d_1>1$ holds by Lemma 3.6(a): the component of $d_1$ has left end $\lambda_1^-\ge1$ and contains $d_1$ in its interior. The target quantile is $T(u)=d_i$ for $u\in I_i:=[u_{i-1},u_i)$, where $u_i=\sum_{j\le i}q_j$ and $u_0=0$. The blocks $I_i$ are consecutive, and $T$ is nondecreasing.

**Reference.** Fix $1\le a<2$ and put $I=[a,2]$,
$$c=\tfrac{a+2}2,\qquad\ell=\tfrac{2-a}2\ \ (\text{Wang's }r),\qquad H=\tfrac\ell2,\qquad d(\theta)=c-\ell\cos\theta\quad(0\le\theta\le\pi).$$

- **(H1)** $a\ge2\big(\tfrac k{k+1}\big)^2$. Put $\alpha(\theta)=k+1-k\sqrt{2a}/d(\theta)$ and $d\eta=\alpha(\theta)\,d\theta/\pi$. In the variable $d$ this is (6.2) (Wang's (4.4)).
- **(H2)** Hypothesis (H) of §7 for $W_0(x)=k\log|x|+\int\log|x-e|\,d\eta(e)$: the main component is $(x_-,x_+)$, strictly separated, with simple crossings $x_-<0<x_+<a$, $W_0'(x_-)<0<W_0'(x_+)$. Put $\sigma_-=-1/W_0'(x_-)>0$ and $\sigma_+=1/W_0'(x_+)>0$. Let $\rho_\pm\in(0,1)$ be defined by $x_\pm=c-\frac\ell2(\rho_\pm+\rho_\pm^{-1})$, let $P_\rho(\theta)=\frac{1-\rho^2}{1-2\rho\cos\theta+\rho^2}$, and $D_\xi=\sum_\pm\sigma_\pm P_{\rho_\pm}(0)$. Then
$$B(\theta)=D_\xi-\sum_\pm\sigma_\pm P_{\rho_\pm}(\theta),\qquad d\xi=B(\theta)\,d\theta/\pi .$$

- $M_0=M_k(T_0)=x_+-x_-$, $R_\xi=\xi(I)$, and $C=C(k,a)=\log H+k\log D_0(a)$ with $D_0(a)=\frac{a+2+2\sqrt{2a}}4$.
- $L$ is any real constant (in the application $L=L_{\rm hi}$ or $L=D$, §9), and $C_{\rm eff}=C+(L-M_0)/R_\xi$.

**Quantiles.** $F_0(d)=\eta([a,d])$, $T_0=F_0^{-1}$ (the quantile of $\eta$), and $\hat\xi=(F_0)_\#\xi$ on $(0,1)$. A *quantile interval* is an interval $I'\subset(0,1)$ of positive length. For such $I'$ put $q'=|I'|$, $r'=\hat\xi(I')$, and
$$\mathcal E(I')=\int_{I'}\!\int_{I'}\log|T_0(u)-T_0(w)|\,dw\,d\hat\xi(u).$$
Write $r_i=\hat\xi(I_i)$ for the target blocks (so $q_i=|I_i|$).

### 8.1 Structure of the reference

#### Lemma 8.1 (monotone densities; the quantile–angle dictionary)

**Source:** paper Lemma 8.1.

Assume (H1), (H2). Then:

1. $\alpha$ is strictly increasing on $[0,\pi]$, $\alpha\ge0$, and $\alpha>0$ on $(0,\pi]$. Also $\frac1\pi\int_0^\pi\alpha=1$, and
$$a_\pi:=\alpha(\pi)=k+1-\tfrac k2\sqrt{2a}=1+\frac{2k\rho_0}{1+\rho_0}\ \ge1,\qquad\rho_0:=\frac{c-\sqrt{2a}}\ell\in(0,1).$$

2. $B$ is strictly increasing on $[0,\pi]$, with $B(0)=0$ and $B>0$ on $(0,\pi]$. Moreover
$$b_\pi:=B(\pi)=\sum_\pm\frac{4\sigma_\pm\rho_\pm}{1-\rho_\pm^2},\qquad R_\xi=\frac1\pi\int_0^\pi B=\sum_\pm\frac{2\sigma_\pm\rho_\pm}{1-\rho_\pm},\qquad0<R_\xi<b_\pi .$$

3. $\Phi:=F_0\circ d:[0,\pi]\to[0,1]$ is a strictly increasing homeomorphism, with
$$\Phi(\theta)=\frac1\pi\Big[(k+1)\theta-2k\arctan\Big(\sqrt{2/a}\,\tan\tfrac\theta2\Big)\Big].$$
   At $\theta=\pi$ the tangent-half-angle expression is evaluated by its continuous limit: $\arctan(\sqrt{2/a}\tan(\theta/2))\to\pi/2$, so $\Phi(\pi)=((k+1)\pi-k\pi)/\pi=1$. Hence $T_0=d\circ\Phi^{-1}$ is continuous and strictly increasing. Every quantile interval $I'$ with endpoints $u'<u''$ (closed, open or half-open) corresponds to the angular interval $J$ with endpoints $\Phi^{-1}(u')<\Phi^{-1}(u'')$, and
$$q'=|I'|=\tfrac1\pi\int_J\alpha,\qquad r'=\hat\xi(I')=\tfrac1\pi\int_JB,\qquad\mathcal E(I')=\frac1{\pi^2}\int_J\!\int_JB(\theta)\alpha(\theta')\log|d(\theta)-d(\theta')|\,d\theta'\,d\theta .$$

4. $\hat\xi$ is atomless. For every quantile interval $I'$ we have $q'>0$ and $r'>0$.
5. Put $Q=\int_J\alpha/a_\pi$ and $R=\int_JB/b_\pi$ (Wang's (5.1); the normalized masses). Then $0<Q\le|J|\le\pi$ and $0<R\le|J|\le\pi$. Moreover $Q\le Q_{\max}:=\pi/a_\pi\le\pi$ and $R\le R_{\max}:=\pi R_\xi/b_\pi<\pi$.

*Proof.*

1. $d(\theta)$ is strictly increasing on $[0,\pi]$ and $k>0$, so $\alpha$ is strictly increasing. Its minimum is $\alpha(0)=k+1-k\sqrt{2/a}$, which is $\ge0$ iff (H1) holds. Hence $\alpha>0$ on $(0,\pi]$.
   - Total mass (Lemma 8.2(c) below): $\frac1\pi\int_0^\pi\frac{\sqrt{2a}}{d(\theta)}d\theta=1$, so $\frac1\pi\int\alpha=(k+1)-k=1$.
   - $\alpha\le a_\pi$ and $\alpha$ has mean $1$, so $a_\pi\ge1$. This also follows from $\sqrt{2a}/2\le1$.
   - The $\rho_0$ form: $c-\sqrt{2a}=(\sqrt2-\sqrt a)^2/2$ and $\ell+c-\sqrt{2a}=2-\sqrt{2a}=\sqrt2(\sqrt2-\sqrt a)$. So $\frac{2k\rho_0}{1+\rho_0}=\frac{2k(c-\sqrt{2a})}{2-\sqrt{2a}}=k\big(1-\sqrt{a/2}\big)$.
   - $\rho_0\in(0,1)$ because $0<c-\sqrt{2a}<\ell$. The second inequality is $a+2-2\sqrt{2a}<2-a$, i.e. $a<\sqrt{2a}$, i.e. $a<2$. (This $\rho_0$ equals $\frac{\sqrt2-\sqrt a}{\sqrt2+\sqrt a}$ of §§6–7.)
2. For $\rho\in(0,1)$, the denominator $1-2\rho\cos\theta+\rho^2$ is strictly increasing on $[0,\pi]$, so $P_\rho$ is strictly decreasing. Since $\sigma_\pm>0$ (H2), $B$ is strictly increasing, and $B(0)=0$ by the definition of $D_\xi$.
   - $b_\pi=\sum\sigma_\pm\big(P_{\rho_\pm}(0)-P_{\rho_\pm}(\pi)\big)$, with $P_\rho(0)-P_\rho(\pi)=\frac{1+\rho}{1-\rho}-\frac{1-\rho}{1+\rho}=\frac{4\rho}{1-\rho^2}$.
   - $\frac1\pi\int_0^\pi P_\rho=1$, since $P_\rho=1+2\sum_n\rho^n\cos n\theta$. Hence $R_\xi=D_\xi-\sum\sigma_\pm=\sum\sigma_\pm\frac{2\rho_\pm}{1-\rho_\pm}$.
   - Termwise, $\frac{2\rho/(1-\rho)}{4\rho/(1-\rho^2)}=\frac{1+\rho}2<1$. So $R_\xi<b_\pi$.
3. Put $\Phi(\theta)=\frac1\pi\int_0^\theta\alpha$. It is strictly increasing because $\alpha>0$ a.e., and $\Phi(\pi)=1$.
   - The closed form follows from $\int_0^\theta\frac{d\phi}{c-\ell\cos\phi}=\frac2{\sqrt{c^2-\ell^2}}\arctan\big(\sqrt{\tfrac{c+\ell}{c-\ell}}\tan\tfrac\theta2\big)$ with $c^2-\ell^2=2a$, $c+\ell=2$ and $c-\ell=a$.
   - $F_0(d(\theta))=\eta([a,d(\theta)])=\Phi(\theta)$. So $T_0(u)=d(\Phi^{-1}(u))$.
   - The change of variables $w=\Phi(\theta')$ gives $dw=\alpha(\theta')d\theta'/\pi$.
   - By definition of the pushforward, $\int\varphi\,d\hat\xi=\int_I\varphi(F_0)\,d\xi=\frac1\pi\int_0^\pi\varphi(\Phi(\theta))B(\theta)\,d\theta$.
   - Combining these gives the three formulas. Consequently, the image of a quantile interval is always an angular interval; a "non-interval image" cannot occur.
4. $\hat\xi$ has the bounded density $B$ in the angle, so it is atomless. $q'>0$ and $r'>0$ because $\alpha,B>0$ on $(0,\pi]$ and $J$ has positive length.
5. $0\le\alpha/a_\pi\le1$ and $0\le B/b_\pi\le1$ by monotonicity, so $Q,R\le|J|\le\pi$.
   - For $J=[0,\pi]$: $Q=\pi\cdot\frac1\pi\int\alpha/a_\pi=\pi/a_\pi$ and $R=\pi R_\xi/b_\pi$.
   - Monotonicity in $J$ gives $Q\le Q_{\max}$ and $R\le R_{\max}$.
   - $R_{\max}<\pi$ by item 2. $\square$

In particular, $Q\le\pi$ and $R\le\pi$ hold for *every* angular interval, because $\alpha/a_\pi$ and $B/b_\pi$ are bounded by $1$; this uses (H1) ($\alpha\ge0$) and $\sigma_\pm>0$ from (H2).

#### Lemma 8.2 (chord identity; platform identity)

**Source:** paper Lemma 8.2.

- (a) For $\theta,\theta'\in[0,\pi]$,
$$|d(\theta)-d(\theta')|=H\,|e^{i\theta}-e^{i\theta'}|\,|e^{i\theta}-e^{-i\theta'}|,\qquad H=\ell/2 .$$
  Equivalently, $\log|d(\theta)-d(\theta')|=\log H+K(\theta-\theta')+K(\theta+\theta')$ with $K(t)=\log|e^{it}-1|=\log|2\sin(t/2)|$.

- (b) $\int_{-\pi}^{\pi}K(t)\,dt=0$. For $0\le\rho<1$, $\frac1{2\pi}\int_{-\pi}^{\pi}K(\theta-\theta')P_\rho(\theta')\,d\theta'=\log|1-\rho e^{i\theta}|$.
- (c) $\frac{\sqrt{2a}}{d(\theta')}=P_{\rho_0}(\theta')$.
- (d) *(Platform identity, Wang's (4.6).)* For every $d\in I$: $k\log d+\int_I\log|d-e|\,d\eta(e)=C(k,a)$. Equivalently, for every $u\in(0,1)$: $k\log T_0(u)+\int_0^1\log|T_0(u)-T_0(w)|\,dw=C$.

*Proof.*

- (a) $\cos\theta-\cos\theta'=-2\sin\frac{\theta+\theta'}2\sin\frac{\theta-\theta'}2$. Also $|e^{i\theta}-e^{\pm i\theta'}|=2|\sin\frac{\theta\mp\theta'}2|$. Hence $|d(\theta)-d(\theta')|=2\ell|\sin\frac{\theta+\theta'}2||\sin\frac{\theta-\theta'}2|=\frac\ell2\cdot4|\cdots||\cdots|$. So $H=\ell/2$ (Wang's $H=r/2$).
- (b) $K(t)=-\sum_{n\ge1}\frac{\cos nt}n$ in $L^2(-\pi,\pi)$. This is the boundary value of $\operatorname{Re}\log(1-z)=-\operatorname{Re}\sum z^n/n$, and the series of squared coefficients $\sum n^{-2}$ converges.
  - The constant Fourier coefficient is $0$.
  - Convolution with $P_\rho=1+2\sum\rho^n\cos n\theta'$ (bounded, hence acting continuously on $L^2$) multiplies the $n$-th coefficient by $\rho^n$. That gives $-\sum\rho^n\cos(n\theta)/n=\log|1-\rho e^{i\theta}|$.
- (c) $\rho_0$ is the root in $(0,1)$ of $\rho+\rho^{-1}=2c/\ell$. Hence $1-2\rho_0\cos\theta'+\rho_0^2=\frac{2\rho_0}\ell d(\theta')$ and $P_{\rho_0}=\frac{\ell(1-\rho_0^2)}{2\rho_0d}$.
  - Also $(\rho_0^{-1}-\rho_0)^2=(2c/\ell)^2-4=4(c^2-\ell^2)/\ell^2$, so $\frac{\ell(1-\rho_0^2)}{2\rho_0}=\sqrt{c^2-\ell^2}=\sqrt{2a}$.
- (d) Put $d=d(\theta)$. By (a) and evenness of $K$,
$$\int_0^\pi\log|d(\theta)-d(\theta')|\,m(\theta')\frac{d\theta'}\pi=\log H\cdot\frac1\pi\int_0^\pi m+\frac1\pi\int_{-\pi}^{\pi}K(\theta-\theta')m(|\theta'|)\,d\theta'$$
  for even bounded $m$.

  - With $m\equiv1$ (equilibrium $e_I$), (b) gives $\log H$.
  - With $m=P_{\rho_0}$ (balayage $\omega_{0,I}$, by (c)), (b) gives $\log H+2\log|1-\rho_0e^{i\theta}|=\log H+\log\frac{2\rho_0d}\ell$.
  - $\frac{2\rho_0}\ell=\frac1{D_0(a)}$, since $\frac\ell{2\rho_0}=\frac{\ell^2}{2(c-\sqrt{2a})}=\frac{(2-a)^2}{4(\sqrt2-\sqrt a)^2}=\frac{(\sqrt2+\sqrt a)^2}4=D_0(a)$.
  - Hence, with $\eta=(k+1)e_I-k\,\omega_{0,I}$:
$$k\log d+(k+1)\log H-k(\log H+\log d-\log D_0)=\log H+k\log D_0=C .$$

  - The identity holds for every $\theta\in[0,\pi]$. The quantile form follows from Lemma 8.1(3). $\square$

(This proof of the platform identity is self-contained and independent of Proposition 6.3(4), which it reproduces.)

#### Lemma 8.3 (absolute convergence)

**Source:** paper Lemma 8.3.

- $\int_J\int_J\alpha(\theta')B(\theta)\,|\log|d(\theta)-d(\theta')||\,d\theta'\,d\theta<\infty$ for every $J\subset[0,\pi]$.
- Hence $\mathcal E(I')$ is finite and Fubini/Tonelli apply.
- Also $\int_{I_i}|\log|T_0(u)-T_0(w)||\,dw<\infty$ for every $u\in(0,1)$.

*Proof.* $\alpha,B$ are bounded. By Lemma 8.2(a), $|\log|d(\theta)-d(\theta')||\le|\log H|+|K(\theta-\theta')|+|K(\theta+\theta')|$. Each term is integrable on $[0,\pi]^2$, since $K\in L^1$ of the circle and is $2\pi$-periodic. The last claim is the same bound in one variable (via $w=\Phi(\theta')$). $\square$

### 8.2 The supporting inequality in quantile form, and block reduction

#### Theorem 8.4 (endpoint-corrected supporting inequality, quantile form)

**Source:** paper Theorem 8.4.

Assume (H1), (H2). Let $T$ be the quantile of an atomized target as in §8.0. For $u\in(0,1)\setminus\{u_0,\dots,u_N\}$, $u\in I_i$, define
$$g(u)=k\,\frac{d_i-T_0(u)}{T_0(u)}+\int_0^1\frac{[T(u)-T(w)]-[T_0(u)-T_0(w)]}{T_0(u)-T_0(w)}\,dw.\tag{8.1}$$
Then $g\in L^1(\hat\xi)$ and
$$M_k(T)\ \ge\ M_k(T_0)+\int_{(0,1)}g\,d\hat\xi\qquad\Big(=M_0+\int_Ig(F_0(d))\,d\xi(d)\Big).\tag{8.2}$$

*Proof.* By Lemma 6.7 (via Lemma 3.2), $T$ is separated or in contact with the component of $d_1$, so §7 applies. With $v=T-T_0$, $d=T_0(u)$ and $e=T_0(w)$,
$$\frac{[T(u)-T(w)]-[T_0(u)-T_0(w)]}{T_0(u)-T_0(w)}=\frac{v(d)-v(e)}{d-e},$$
and $T_0$ pushes Lebesgue measure on $(0,1)$ to $\eta$ (Lemma 7.2(ii)). So (8.1) at $u$ equals (7.2) at $d=T_0(u)$. Theorem 7.1(i),(iii) gives $g\circ F_0\in L^1(\xi)$ and $M_k(T)\ge M_k(T_0)+\int_I g(F_0(d))\,d\xi(d)$; since $\hat\xi=(F_0)_\#\xi$, this is (8.2). $\square$

*Remarks.*

- For $u$ interior to $I_i$ the integrand of (8.1) equals $-1$ for $w\in I_i$, $w\ne u$, because $T(u)=T(w)=d_i$. For $w\notin I_i$ the integrand is bounded, since $|T_0(u)-T_0(w)|\ge\operatorname{dist}(T_0(u),T_0(\partial I_i))>0$. So **(8.1) is an absolutely convergent Lebesgue integral**, and no principal value is needed at non-endpoint $u$.
- Wang's symmetric principal value in the reference coordinate coincides with (8.1) there. The block endpoints are $\hat\xi$-null (Lemma 8.1(4)).
- Near an interior block endpoint $u_i$, $g$ has at worst a logarithmic singularity (§7.5).

#### Lemma 8.5 (pointwise lower bound)

**Source:** paper Lemma 8.5.

For $u$ in the interior of $I_i$,
$$g(u)\ \ge\ G_i(u):=-q_i\log R_i-C-q_i+\int_{I_i}\log|T_0(u)-T_0(w)|\,dw.\tag{8.3}$$

*Proof.* Fix such $u$. The tangent inequality is: for $x,y>0$, $\frac{y-x}x=\frac yx-1\ge\log\frac yx$, because $t-1\ge\log t$ for $t>0$.

1. *External field.* $T_0(u)\ge a\ge1>0$, $d_i\ge1>0$, and $k>0$. So $k\frac{d_i-T_0(u)}{T_0(u)}\ge k\log d_i-k\log T_0(u)$.
2. *Off-block, $w\in I_j$, $j\ne i$.*
   - Let $w<u$ (so $j<i$). Then $T(u)-T(w)=d_i-d_j>0$, since the $d$'s are distinct and increasing. Also $T_0(u)-T_0(w)>0$, since $T_0$ is strictly increasing.
   - Let $w>u$. Both differences are $<0$.
   - In either case, with $\epsilon=\pm1$ the common sign, $x=\epsilon(T_0(u)-T_0(w))=|T_0(u)-T_0(w)|>0$ and $y=\epsilon(d_i-d_j)=|d_i-d_j|>0$. The integrand in (8.1) equals $\frac{y-x}x\ge\log|d_i-d_j|-\log|T_0(u)-T_0(w)|$.
3. *Within block, $w\in I_i$, $w\ne u$.* The integrand is $\frac{0-(T_0(u)-T_0(w))}{T_0(u)-T_0(w)}=-1$. The within-block contribution is exactly $-q_i$; no inequality is used here.
4. *Integrate* over $w\in(0,1)$. All pieces are absolutely integrable at the fixed interior $u$: item 2 by boundedness, and the log term by Lemma 8.3. This gives
$$g(u)\ge\Big[k\log d_i+\sum_{j\ne i}q_j\log|d_i-d_j|\Big]-\Big[k\log T_0(u)+\int_{(0,1)\setminus I_i}\log|T_0(u)-T_0(w)|\,dw\Big]-q_i .$$

5. *The first bracket* is $-q_i\log R_i$, by the definition of $R_i$.
6. *The second bracket* is $C-\int_{I_i}\log|T_0(u)-T_0(w)|\,dw$, by the platform identity, Lemma 8.2(d), at the point $T_0(u)\in I$. $\square$

#### Proposition 8.6 (block reduction; Wang Prop. 4.4)

**Source:** paper Proposition 8.6.

Assume (H1), (H2). Suppose every quantile interval $I'\subset(0,1)$ satisfies
$$\mathcal E(I')\ \ge\ q'r'\log\frac{q'r'}2+C_{\rm eff}\,r',\qquad q'=|I'|,\ r'=\hat\xi(I').\tag{8.4}$$
Then $\mathcal J_k\ge L$. If (8.4) is strict for every quantile interval, then $\mathcal J_k>L$.

*Proof.*

1. $\hat\xi\ge0$ (as $B\ge0$), $g\in L^1(\hat\xi)$ (Theorem 8.4) and $G_i\in L^1(\hat\xi|_{I_i})$ (Lemma 8.3). The finitely many endpoints $u_j$ are $\hat\xi$-null. So integrating (8.3) against $\hat\xi$ over each $I_i$ and summing is legitimate:
$$\int g\,d\hat\xi\ \ge\ \sum_i\Big[r_i\big(-q_i\log R_i-C-q_i\big)+\mathcal E(I_i)\Big].$$

2. By Theorem 8.4, $M_k=M_k(T)\ge M_0+\int g\,d\hat\xi$. Adding $2\sum R_i$:
$$\mathcal J_k\ \ge\ M_0+\sum_i\Xi_i(R_i),\qquad\Xi_i(y):=r_i(-q_i\log y-C-q_i)+\mathcal E(I_i)+2y\quad(y>0).$$

3. *Minimisation.* $r_i>0$ and $q_i>0$ (Lemma 8.1(4)). $\Xi_i$ is strictly convex on $(0,\infty)$, with $\Xi_i'(y)=2-q_ir_i/y$ and unique critical point $y^\ast=q_ir_i/2$. Hence for the actual (fixed) $R_i>0$,
$$\Xi_i(R_i)\ge\Xi_i(y^\ast)=-q_ir_i\log\frac{q_ir_i}2-Cr_i-q_ir_i+\mathcal E(I_i)+q_ir_i=\mathcal E(I_i)-q_ir_i\log\frac{q_ir_i}2-Cr_i .$$
   This is an inequality for the given $R_i$; no optimisation over targets is involved.

4. By (8.4) applied to $I'=I_i$, $\Xi_i(R_i)\ge(C_{\rm eff}-C)r_i$. Summing, with $\sum_ir_i=\hat\xi((0,1))=\xi(I)=R_\xi$ (endpoints null):
$$\mathcal J_k\ge M_0+(C_{\rm eff}-C)R_\xi=M_0+(L-M_0)=L .$$
   Strictness passes through step 4. $\square$

*Remark.* The sign of $C$ plays no role. Only $\hat\xi\ge0$, $q_i,r_i>0$ and the exact within-block value $-1$ are used. The $-q_i$ within-block term and the $+q_ir_i$ from the minimum cancel exactly.

### 8.3 Symmetric decreasing functions on the circle

Let $\mathbb T=\mathbb R/2\pi\mathbb Z$ carry Lebesgue measure; functions on $\mathbb T$ are identified with $2\pi$-periodic functions on $\mathbb R$.

**Definition.** A function $F$ on $\mathbb T$ is **symmetric decreasing** if it is even and nonincreasing in $|\theta|$ on $[0,\pi]$.

#### Lemma 8.7 (two elementary rearrangement facts on $\mathbb T$)

**Source:** paper Lemma 8.7.

- (a) *(Convolution of symmetric decreasing functions.)* If $\Psi_a,\Psi_b\ge0$ on $\mathbb T$ are symmetric decreasing and $\Psi_a\ast\Psi_b$ is finite, then $\Psi_a\ast\Psi_b$ is symmetric decreasing (pointwise, at every point).
- (b) *(Bathtub.)* Let $\Psi$ be symmetric decreasing and integrable, and let $\varphi:\mathbb T\to[0,1]$ with $\int_{\mathbb T}\varphi=2Q$, $0<Q\le\pi$. Then $\int\varphi\Psi\le\int_{-Q}^{Q}\Psi$.

*Proof.*

- (a) By the layer-cake formula and Tonelli, $\Psi_a\ast\Psi_b=\int_0^\infty\!\!\int_0^\infty\mathbf 1_{\{\Psi_a>s\}}\ast\mathbf 1_{\{\Psi_b>t\}}\,ds\,dt$, pointwise. Each level set is, up to null sets (which do not affect convolutions), a centred arc $[-t_1,t_1]$ (respectively $[-t_2,t_2]$). So it suffices to treat $\psi(x)=|[-t_1,t_1]\cap(x+[-t_2,t_2])|$ with $0\le t_1,t_2\le\pi$.
  - $\psi$ is even and Lipschitz. For $x\in(0,\pi)$, $\psi'(x)=\mathbf 1_{[-t_1,t_1]}(x+t_2)-\mathbf 1_{[-t_1,t_1]}(x-t_2)$ a.e. (arcs on $\mathbb T$).
  - The circular distances satisfy $\operatorname{dist}(x+t_2,0)=\min(x+t_2,2\pi-x-t_2)\ge|x-t_2|=\operatorname{dist}(x-t_2,0)$. This uses $x\le\pi$ and $t_2\le\pi$.
  - Hence $\psi'\le0$ a.e. on $(0,\pi)$, and $\psi$ is nonincreasing in $|x|$.
- (b) Put $\tau=\Psi(Q)$; any value between the one-sided limits works. On $|\theta|<Q$: $1-\varphi\ge0$ and $\Psi-\tau\ge0$. On $|\theta|>Q$: $-\varphi\le0$ and $\Psi-\tau\le0$. So $\int(\mathbf 1_{[-Q,Q]}-\varphi)(\Psi-\tau)\ge0$. Since $\int(\mathbf 1_{[-Q,Q]}-\varphi)=0$, this is the claim.
  - $Q\le\pi$ is needed for $[-Q,Q]$ to be an arc of length $2Q$. In the application it is guaranteed by Lemma 8.1(5). $\square$

### 8.4 The circle rearrangement inequality (Theorem 8.8)

**What is needed.** The circle block inequality (Theorem 8.19) needs exactly one rearrangement fact: for $\varphi_1,\varphi_2:\mathbb T\to[0,1]$ with $\int\varphi_1=2Q$, $\int\varphi_2=2R$, $0<Q,R\le\pi$, and the kernel $\mathcal L(t)=-\log|\sin(t/2)|$,
$$\iint\varphi_1(\theta)\varphi_2(\theta')\mathcal L(\theta-\theta')\le\int_{-Q}^{Q}\!\int_{-R}^{R}\mathcal L(\theta-\theta').$$
In the literature this is obtained as "Riesz rearrangement inequality on the circle, then bathtub, then bathtub" (paper Appendix C). Its bounded-kernel form is statement (R) below, which subsumes all three steps; rearrangements of general functions are not needed, and monotone convergence is applied once, to (R) itself (Theorem 8.19, step 3). The proof below establishes this rearrangement fact directly by discrete two-point rearrangements and a limiting argument.

#### Theorem 8.8 (circle rearrangement inequality with centred-arc extremals)

**Source:** paper Theorem 8.8.

Let $\bar\kappa\ge0$ and let $\kappa:\mathbb T\to[0,\bar\kappa]$ be symmetric decreasing. Let $\varphi_1,\varphi_2:\mathbb T\to[0,1]$ be measurable, with $\int_{\mathbb T}\varphi_1=2Q$ and $\int_{\mathbb T}\varphi_2=2R$. (Automatically $0\le Q,R\le\pi$.) Then
$$I_\kappa(\varphi_1,\varphi_2):=\int_{\mathbb T}\!\int_{\mathbb T}\varphi_1(\theta)\,\kappa(\theta-\theta')\,\varphi_2(\theta')\,d\theta\,d\theta'\ \le\ V_\kappa(Q,R):=\int_{-Q}^{Q}\!\int_{-R}^{R}\kappa(\theta-\theta')\,d\theta'\,d\theta.\tag{R}$$

*Remarks.*

- $\kappa$ is Borel, because it is monotone in $|\theta|$ on $[0,\pi]$.
- Nonnegativity of $\kappa$ is inessential: if $\kappa$ is bounded and symmetric decreasing, apply (R) to $\kappa+c\ge0$; both sides change by $4QRc$.
- For $Q=0$, $\varphi_1=0$ a.e. and both sides vanish; the same holds for $R=0$. So assume $Q,R>0$ where convenient.

**Proof architecture.**

- A discrete cyclic Riesz inequality on $\mathbb Z_n$, by two-point rearrangements (Lemmas 8.9–8.12, Theorem 8.13).
- An exact transfer to step functions on $n$ equal cells (Lemma 8.14).
- A symmetric step function within $L^1$-distance $\delta_n=2\pi/n$ of the discrete extremal (Lemma 8.15); for it, the bathtub steps of Lemma 8.7 give $V_\kappa(Q,R)$ exactly (Lemma 8.16).
- Cell averages $\mathbb E_n\varphi\to\varphi$ in $L^1$ with the same masses, and $n\to\infty$ (Lemma 8.17).

Masses need not be multiples of $2\pi/n$: cell averages preserve the masses exactly, and the comparison with arcs of the exact masses $2Q,2R$ is done in the continuum, by the bathtub principle.

#### Discrete notation

- $n\ge1$; $\mathbb Z_n=\mathbb Z/n\mathbb Z$, and $|z|_n=\min(z\bmod n,\;n-z\bmod n)\in\{0,\dots,\lfloor n/2\rfloor\}$.
- A **symmetric decreasing kernel** on $\mathbb Z_n$ is $\gamma:\mathbb Z_n\to\mathbb R$ of the form $\gamma_z=\bar\gamma(|z|_n)$ with $\bar\gamma$ nonincreasing on $\{0,\dots,\lfloor n/2\rfloor\}$. No sign condition is imposed.
- For $\mathbf a,\mathbf b\in\mathbb R^{\mathbb Z_n}$ put $S_\gamma(\mathbf a,\mathbf b)=\sum_{i,j\in\mathbb Z_n}a_i\,b_j\,\gamma_{i-j}$.
- **Canonical positions.** $p(1)=0$, $p(2k)=k$, $p(2k+1)=-k$ (mod $n$), for $1\le j\le n$. This lists $\mathbb Z_n$ once each, in order of nondecreasing $|\cdot|_n$: $|p(j)|_n=\lfloor j/2\rfloor$. For even $n$, the last position is $p(n)=n/2$.
- **Canonical arrangement.** If $v_1\ge v_2\ge\dots\ge v_n$ are the entries of $\mathbf a$ in nonincreasing order (with multiplicity), then $\mathbf a^\#$ is defined by $a^\#_{p(j)}=v_j$.

#### Lemma 8.9 (reflections of the discrete circle)

**Source:** paper Lemma 8.9.

Let $m\in\mathbb Z$. On $\mathbb T_n=\mathbb R/n\mathbb Z$ let $\|x\|=\min_{k\in\mathbb Z}|x-kn|$, and let $\iota(x)=m-x$. Put
$$U_+=\{\tfrac m2+s:0<s<n/2\},\qquad U_-=\{\tfrac m2-s:0<s<n/2\}.$$

1. $\mathbb T_n=U_+\sqcup U_-\sqcup\{\frac m2,\frac m2+\frac n2\}$. The map $\iota$ fixes $\frac m2$ and $\frac m2+\frac n2$, swaps $U_+$ and $U_-$, and satisfies $\|\iota x-\iota y\|=\|x-y\|$.
2. If $x,y\in U_+$, or $x,y\in U_-$, then $\|x-y\|<\|x-\iota y\|$.
3. The fixed points of $\iota$ in $\mathbb Z_n$ are exactly $\mathbb Z_n\cap\{\frac m2,\frac m2+\frac n2\}$.

*Proof.*

1. Each $x\in\mathbb T_n$ is uniquely $\frac m2+s$ with $s\in(-n/2,n/2]$. Then $\iota(\frac m2+s)=\frac m2-s$. Also $\|(m-x)-(m-y)\|=\|y-x\|=\|x-y\|$.
2. Let $x=\frac m2+s$ and $y=\frac m2+t$ with $s,t\in(0,n/2)$.
   - $x-y=s-t\in(-n/2,n/2)$, so $\|x-y\|=|s-t|$.
   - $x-\iota y=s+t\in(0,n)$, so $\|x-\iota y\|=\min(s+t,\,n-s-t)$.
   - $|s-t|<s+t$ because $\min(s,t)>0$.
   - $|s-t|<n-s-t$ is equivalent to $2\max(s,t)<n$, which holds.
   - For $x,y\in U_-$: $\iota x,\iota y\in U_+$. By item 1, $\|x-y\|=\|\iota x-\iota y\|<\|\iota x-y\|=\|x-\iota y\|$.
3. $\iota x=x$ iff $2x\equiv m\pmod n$ iff $x=\frac m2+s$ with $2s\equiv0\pmod n$ and $s\in(-n/2,n/2]$, i.e. $s\in\{0,n/2\}$. $\square$

**Half-sets.** For $m\in\mathbb Z_n$ write $\iota_m(z)=m-z$ and $\operatorname{Fix}_m$ for its fixed-point set.

- If $m\not\equiv0$: then $0\notin\{\frac m2,\frac m2+\frac n2\}$, since otherwise $2\cdot0\equiv m$. So $0$ lies in exactly one of $U_\pm$; call it $U$, and put $\Omega_m=\mathbb Z_n\cap U$. Equivalently, $\Omega_m=\{z\in\mathbb Z_n:|z|_n<|z-m|_n\}$; this description does not depend on the representative of $m$. (By Corollary 8.10 below, $z\in\Omega_m$ gives $|z|_n<|z-m|_n$; $z\in\iota_m(\Omega_m)$ gives the reverse strict inequality, and $z\in\operatorname{Fix}_m$ gives equality.)
- If $m\equiv0$: put $\Omega_0=\mathbb Z_n\cap U_+=\{z:0<z<n/2\}$.
- By Lemma 8.9, $\mathbb Z_n=\Omega_m\sqcup\iota_m(\Omega_m)\sqcup\operatorname{Fix}_m$.

#### Corollary 8.10

**Source:** paper Corollary 8.10.

If $m\not\equiv0$ and $z\in\Omega_m$, then $|z|_n<|\iota_mz|_n$.

*Proof.* $z,0\in U$, so Lemma 8.9(2) gives $|z|_n=\|z-0\|<\|z-\iota_m0\|=\|z-m\|=|\iota_mz|_n$. $\square$

**Polarization.** For $\mathbf a\in\mathbb R^{\mathbb Z_n}$ define $\operatorname{Pol}_m\mathbf a$ by:

- $(\operatorname{Pol}_m\mathbf a)_z=\max(a_z,a_{\iota_mz})$ for $z\in\Omega_m$;
- $(\operatorname{Pol}_m\mathbf a)_z=\min(a_z,a_{\iota_mz})$ for $z\in\iota_m(\Omega_m)$;
- $(\operatorname{Pol}_m\mathbf a)_z=a_z$ for $z\in\operatorname{Fix}_m$.

$\operatorname{Pol}_m\mathbf a$ is a permutation of $\mathbf a$: swap $a_z$ and $a_{\iota_mz}$ whenever $z\in\Omega_m$ and $a_z<a_{\iota_mz}$.

#### Lemma 8.11 (two-point inequality)

**Source:** paper Lemma 8.11.

For every $m$, all $\mathbf a,\mathbf b\in\mathbb R^{\mathbb Z_n}$ and every symmetric decreasing kernel $\gamma$:
$$S_\gamma(\operatorname{Pol}_m\mathbf a,\operatorname{Pol}_m\mathbf b)\ge S_\gamma(\mathbf a,\mathbf b).$$

*Proof.* Write $\iota=\iota_m$, $\Omega=\Omega_m$, $F=\operatorname{Fix}_m$. Since $\iota$ is an isometry of $|\cdot|_n$ (Lemma 8.9(1)), $\gamma_{\iota i-\iota j}=\gamma_{i-j}$ and $\gamma_{\iota i-j}=\gamma_{i-\iota j}$. Split the sum over $(i,j)$ as follows.

- **$i,j\in F$.** These terms do not change.
- **$i\in F$, $j\in\{y,\iota y\}$ with $y\in\Omega$.** Here $\gamma_{i-\iota y}=\gamma_{\iota i-\iota y}=\gamma_{i-y}$. So the terms equal $a_i\gamma_{i-y}(b_y+b_{\iota y})$. Polarization changes neither $a_i$ nor $b_y+b_{\iota y}$.
- **$i\in\{x,\iota x\}$ with $x\in\Omega$, $j\in F$.** Symmetric to the previous case.
- **$i\in\{x,\iota x\}$, $j\in\{y,\iota y\}$ with $x,y\in\Omega$.** Every ordered pair of non-fixed points occurs in exactly one such group. With $\gamma'=\gamma_{x-y}$ and $\gamma''=\gamma_{x-\iota y}$, the group equals
$$\gamma'(a_xb_y+a_{\iota x}b_{\iota y})+\gamma''(a_xb_{\iota y}+a_{\iota x}b_y)=(\gamma'-\gamma'')(a_xb_y+a_{\iota x}b_{\iota y})+\gamma''(a_x+a_{\iota x})(b_y+b_{\iota y}).$$

  - The last term does not change.
  - By Lemma 8.9(2), $|x-y|_n<|x-\iota y|_n$, so $\gamma'\ge\gamma''$.
  - For reals $u\ge u'$ and $w\ge w'$: $uw+u'w'-(uw'+u'w)=(u-u')(w-w')\ge0$. Hence $a_xb_y+a_{\iota x}b_{\iota y}\le\max\cdot\max+\min\cdot\min$, and the right side is the value after polarization. $\square$

#### Lemma 8.12 (states fixed by all polarizations with $m\ne0$)

**Source:** paper Lemma 8.12.

Suppose $\operatorname{Pol}_m\mathbf a=\mathbf a$ for every $m\not\equiv0$. Then $a_x\ge a_y$ whenever $|x|_n<|y|_n$.

*Proof.* Put $m=x+y$.

- $m\not\equiv0$, since otherwise $y=-x$ and $|y|_n=|x|_n$.
- $\iota_mx=y\ne x$, so $x\notin\operatorname{Fix}_m$.
- If $x\in\iota_m(\Omega_m)$, then $y\in\Omega_m$, and Corollary 8.10 gives $|y|_n<|\iota_my|_n=|x|_n$, a contradiction.
- So $x\in\Omega_m$, and $a_x=(\operatorname{Pol}_m\mathbf a)_x=\max(a_x,a_y)\ge a_y$. $\square$

#### Theorem 8.13 (discrete cyclic Riesz inequality)

**Source:** paper Theorem 8.13.

For all $\mathbf a,\mathbf b\in\mathbb R^{\mathbb Z_n}$ and every symmetric decreasing kernel $\gamma$ on $\mathbb Z_n$:
$$S_\gamma(\mathbf a,\mathbf b)\le S_\gamma(\mathbf a^\#,\mathbf b^\#).$$

*Proof.*

- *Potential.* Put $\operatorname{Pot}(\mathbf a)=-\sum_z|z|_n\,a_z$. For $m\not\equiv0$, polarization moves the larger of $a_z,a_{\iota_mz}$ to $z\in\Omega_m$, and $|z|_n<|\iota_mz|_n$ (Corollary 8.10). Hence
$$\operatorname{Pot}(\operatorname{Pol}_m\mathbf a)-\operatorname{Pot}(\mathbf a)=\sum_{z\in\Omega_m}\big(|\iota_mz|_n-|z|_n\big)\big((\operatorname{Pol}_m\mathbf a)_z-a_z\big)\ \ge0,$$
  with equality iff $\operatorname{Pol}_m\mathbf a=\mathbf a$.

- *Algorithm.* While some $m\not\equiv0$ has $(\operatorname{Pol}_m\mathbf a,\operatorname{Pol}_m\mathbf b)\ne(\mathbf a,\mathbf b)$, replace $(\mathbf a,\mathbf b)$ by $(\operatorname{Pol}_m\mathbf a,\operatorname{Pol}_m\mathbf b)$.
  - Each replacement strictly increases $\operatorname{Pot}(\mathbf a)+\operatorname{Pot}(\mathbf b)$.
  - $(\mathbf a,\mathbf b)$ stays in the finite set of pairs of permutations of the original vectors.
  - So no pair repeats, and the algorithm stops after finitely many steps.
  - By Lemma 8.11, $S_\gamma$ never decreases.
- *Terminal state.* At termination, Lemma 8.12 applies to both $\mathbf a$ and $\mathbf b$: they are *radially nonincreasing*, i.e. the minimum over the level $\{|z|_n=k\}$ is $\ge$ the maximum over the level $\{|z|_n=k'\}$ for $k<k'$.
- *Final step.* Apply $\operatorname{Pol}_0$ once, again not decreasing $S_\gamma$ (Lemma 8.11).
  - $\operatorname{Pol}_0$ permutes entries only within the pairs $\{z,-z\}$ with $0<z<n/2$. So it preserves radial monotonicity.
  - After it, $a_z\ge a_{-z}$ for $0<z<n/2$.
  - Hence $a_{p(1)}\ge a_{p(2)}\ge\dots\ge a_{p(n)}$, i.e. $a_0\ge a_1\ge a_{-1}\ge a_2\ge a_{-2}\ge\cdots$.
  - A permutation of the original $\mathbf a$ that is nonincreasing along $p$ is $\mathbf a^\#$. The same holds for $\mathbf b$. $\square$

*Remarks.*

- (i) The **same** orientation $p$ must be used for $\mathbf a$ and $\mathbf b$. With $\mathbf b$ mirrored ($z\mapsto-z$) the value can be strictly smaller. The final $\operatorname{Pol}_0$ step is what fixes a common orientation.
- (ii) $S_\gamma$ is linear in $\gamma$. The symmetric decreasing kernels form the cone generated by the rays $\mathbf 1_{\{|z|_n\le r\}}$ ($0\le r\le\lfloor n/2\rfloor$) and the constants $\pm1$, on which $S_\gamma(\mathbf a,\mathbf b)=(\sum a)(\sum b)$ is invariant.

#### Cells
Fix $n\ge2$ and the mesh $\delta_n=2\pi/n\le\pi$. The cells are $\Delta_i=[i\delta_n-\delta_n/2,\,i\delta_n+\delta_n/2)$ (mod $2\pi$), $i\in\mathbb Z_n$. They partition $\mathbb T$. For $\mathbf a\in[0,1]^{\mathbb Z_n}$ write $\mathrm{st}(\mathbf a)=\sum_ia_i\mathbf 1_{\Delta_i}$. The bilinear form $I_\kappa(\psi_1,\psi_2)=\iint\psi_1(\theta)\kappa(\theta-\theta')\psi_2(\theta')$ satisfies $|I_\kappa(\psi_1,\psi_2)|\le\bar\kappa\|\psi_1\|_1\|\psi_2\|_1$.

#### Lemma 8.14 (cell kernel)

**Source:** paper Lemma 8.14.

Let $\kappa$ be as in Theorem 8.8. Put $\gamma^{(n)}_z=\int_{\Delta_z}\int_{\Delta_0}\kappa(\theta-\theta')\,d\theta'\,d\theta$. Then:

- $\int_{\Delta_i}\int_{\Delta_j}\kappa(\theta-\theta')\,d\theta'\,d\theta=\gamma^{(n)}_{i-j}$, so $I_\kappa(\mathrm{st}(\mathbf a),\mathrm{st}(\mathbf b))=S_{\gamma^{(n)}}(\mathbf a,\mathbf b)$;
- $\gamma^{(n)}$ is a symmetric decreasing kernel on $\mathbb Z_n$.

*Proof.*

- Translating $\theta\mapsto\theta+i\delta_n$ and $\theta'\mapsto\theta'+j\delta_n$ changes $\theta-\theta'$ by $(i-j)\delta_n$. So the double integral depends only on $i-j$ mod $n$.
- Substitute $t=\theta-\theta'$ over $[-\delta_n/2,\delta_n/2]^2$. Then
$$\gamma^{(n)}_z=\int_{-\delta_n}^{\delta_n}\kappa(z\delta_n+t)(\delta_n-|t|)\,dt=(\kappa\ast\tau)(z\delta_n),$$
  where $\tau$ is the $2\pi$-periodic function equal to $(\delta_n-|t|)_+$ on $[-\pi,\pi]$. This uses $\delta_n\le\pi$ and the evenness of $\tau$.

- $\tau\ge0$ is even and nonincreasing in $|t|$ on $[0,\pi]$, and so is $\kappa$. By Lemma 8.7(a), $\Psi=\kappa\ast\tau$ is even and nonincreasing in $|x|$ on $[0,\pi]$, pointwise (its layer-cake proof is pointwise in $x$).
- $z\delta_n$ has circular distance $|z|_n\delta_n\in[0,\pi]$ from $0$. So $\gamma^{(n)}_z=\Psi(|z|_n\delta_n)$, which is nonincreasing in $|z|_n$. $\square$

#### Lemma 8.15 (canonical arrangement vs. symmetric step function)

**Source:** paper Lemma 8.15.

Let $\mathbf a\in[0,1]^{\mathbb Z_n}$ with sorted entries $v_1\ge\dots\ge v_n$. Put $\varphi^\#=\mathrm{st}(\mathbf a^\#)$. Let $\varphi^\star$ be the even function with $\varphi^\star(\theta)=v_j$ for $|\theta|\in[(j-1)\delta_n/2,\,j\delta_n/2)$, $1\le j\le n$, and $\varphi^\star(\pi)=v_n$. Then:

- $\varphi^\star$ is symmetric decreasing, with values in $[0,1]$;
- $\int\varphi^\star=\delta_n\sum_ia_i=\int\mathrm{st}(\mathbf a)$;
- $\|\varphi^\#-\varphi^\star\|_1\le\delta_n\,(v_2-v_n)\le\delta_n$.

*Proof.* The first two items are immediate: each $v_j$ occupies measure $2\cdot\delta_n/2$. For the third, compare cell by cell; the descriptions below hold up to null sets.

- **$\Delta_0$.** It equals $\{|\theta|<\delta_n/2\}$, and both functions are $v_1$ there.
- **$\Delta_k$ and $\Delta_{-k}$, $1\le k<n/2$.** These lie in $\{k\delta_n-\delta_n/2\le|\theta|\le k\delta_n+\delta_n/2\}\subset[0,\pi]$.
  - $\varphi^\#=v_{2k}$ on $\Delta_k$ and $\varphi^\#=v_{2k+1}$ on $\Delta_{-k}$.
  - $\varphi^\star=v_{2k}$ for $|\theta|\in[k\delta_n-\delta_n/2,k\delta_n)$ and $\varphi^\star=v_{2k+1}$ for $|\theta|\in[k\delta_n,k\delta_n+\delta_n/2)$.
  - So they differ only on $\Delta_k\cap\{\theta\ge k\delta_n\}$ and $\Delta_{-k}\cap\{|\theta|<k\delta_n\}$. Each has length $\delta_n/2$, and the difference there is $v_{2k}-v_{2k+1}$.
- **$\Delta_{n/2}$ ($n$ even).** It equals $\{|\theta|\ge\pi-\delta_n/2\}$, and both functions are $v_n$ there.

Summing, $\|\varphi^\#-\varphi^\star\|_1=\delta_n\sum_{1\le k<n/2}(v_{2k}-v_{2k+1})\le\delta_n\sum_{j=2}^{n-1}(v_j-v_{j+1})=\delta_n(v_2-v_n)$. $\square$

#### Lemma 8.16 (bathtub bound for symmetric decreasing densities)

**Source:** paper Lemma 8.16.

Let $\varphi_1,\varphi_2:\mathbb T\to[0,1]$ be symmetric decreasing, with $\int\varphi_1=2Q$ and $\int\varphi_2=2R$. Then $I_\kappa(\varphi_1,\varphi_2)\le V_\kappa(Q,R)$.

*Proof.* Assume $Q,R>0$, else the claim is trivial.

1. $\Psi_1=\kappa\ast\varphi_2$ is bounded and symmetric decreasing (Lemma 8.7(a)). Since $0\le\varphi_1\le1$ and $Q\le\pi$, Lemma 8.7(b) gives
$$I_\kappa(\varphi_1,\varphi_2)=\int\varphi_1\,\Psi_1\le\int\mathbf 1_{[-Q,Q]}\Psi_1 .$$

2. By Fubini and the evenness of $\kappa$, $\int\mathbf 1_{[-Q,Q]}\Psi_1=\int\varphi_2\,\Psi_2$ with $\Psi_2=\kappa\ast\mathbf 1_{[-Q,Q]}$. Here $\mathbf 1_{[-Q,Q]}$ is symmetric decreasing because $Q\le\pi$, so $\Psi_2$ is symmetric decreasing (Lemma 8.7(a)).
3. Lemma 8.7(b) with $R\le\pi$ gives $\int\varphi_2\,\Psi_2\le\int_{-R}^{R}\Psi_2=V_\kappa(Q,R)$. $\square$

(Only step 1 uses the symmetry of $\varphi_2$; the symmetry of $\varphi_1$ is not needed.)

#### Lemma 8.17 (cell averages)

**Source:** paper Lemma 8.17.

For $\psi\in L^1(\mathbb T)$ put $\mathbb E_n\psi=\sum_i\big(\frac1{\delta_n}\int_{\Delta_i}\psi\big)\mathbf 1_{\Delta_i}$. Then:

- $\|\mathbb E_n\psi\|_1\le\|\psi\|_1$ and $\int\mathbb E_n\psi=\int\psi$;
- if $0\le\psi\le1$, then $0\le\mathbb E_n\psi\le1$;
- $\|\mathbb E_n\psi-\psi\|_1\to0$ as $n\to\infty$.

*Proof.* The first two items are immediate. For the third:

- For continuous $\chi$ with modulus of continuity $\omega_\chi$: every cell has diameter $\delta_n$, so $|\mathbb E_n\chi-\chi|\le\omega_\chi(\delta_n)$ pointwise.
- Given $\varepsilon>0$, choose continuous $\chi$ with $\|\psi-\chi\|_1<\varepsilon$ (density of $C(\mathbb T)$ in $L^1(\mathbb T)$).
- Then $\|\mathbb E_n\psi-\psi\|_1\le\|\mathbb E_n(\psi-\chi)\|_1+\|\mathbb E_n\chi-\chi\|_1+\|\chi-\psi\|_1\le2\varepsilon+2\pi\,\omega_\chi(2\pi/n)$. $\square$

#### Proof of Theorem 8.8
Fix $n\ge2$ and put $\varphi_{1,n}=\mathbb E_n\varphi_1=\mathrm{st}(\mathbf a)$ and $\varphi_{2,n}=\mathbb E_n\varphi_2=\mathrm{st}(\mathbf b)$.

- By Lemma 8.17, $\mathbf a,\mathbf b\in[0,1]^{\mathbb Z_n}$, $\int\varphi_{1,n}=2Q$ and $\int\varphi_{2,n}=2R$.
- By Lemma 8.14 and Theorem 8.13 (with $\gamma=\gamma^{(n)}$),
$$I_\kappa(\varphi_{1,n},\varphi_{2,n})=S_{\gamma^{(n)}}(\mathbf a,\mathbf b)\le S_{\gamma^{(n)}}(\mathbf a^\#,\mathbf b^\#)=I_\kappa(\varphi_1^\#,\varphi_2^\#),$$
  where $\varphi_1^\#=\mathrm{st}(\mathbf a^\#)$ and $\varphi_2^\#=\mathrm{st}(\mathbf b^\#)$.

- Let $\varphi_1^\star,\varphi_2^\star$ be the symmetric step functions of Lemma 8.15. They have values in $[0,1]$, are symmetric decreasing, and have masses exactly $2Q,2R$. By bilinearity, Lemma 8.15 and Lemma 8.16,
$$I_\kappa(\varphi_1^\#,\varphi_2^\#)\le I_\kappa(\varphi_1^\star,\varphi_2^\star)+\bar\kappa\big(\|\varphi_1^\#-\varphi_1^\star\|_1\|\varphi_2^\#\|_1+\|\varphi_1^\star\|_1\|\varphi_2^\#-\varphi_2^\star\|_1\big)\le V_\kappa(Q,R)+2\bar\kappa\,\delta_n(Q+R).$$

- Finally,
$$|I_\kappa(\varphi_1,\varphi_2)-I_\kappa(\varphi_{1,n},\varphi_{2,n})|\le\bar\kappa\big(\|\varphi_1-\varphi_{1,n}\|_1\cdot2R+2Q\cdot\|\varphi_2-\varphi_{2,n}\|_1\big)\to0$$
  by Lemma 8.17.

- Letting $n\to\infty$ in $I_\kappa(\varphi_1,\varphi_2)\le I_\kappa(\varphi_{1,n},\varphi_{2,n})+o(1)\le V_\kappa(Q,R)+2\bar\kappa\,\delta_n(Q+R)+o(1)$ gives (R). $\square$

*Remarks.*

- (a) No general theory of rearrangements is needed: $\varphi^\star$ is written down explicitly for step functions.
- (b) Wrap-around, arcs longer than $\pi$, kernels whose superlevel arcs have any length in $[0,2\pi]$, and masses that are not multiples of $\delta_n$ are all covered. The discrete theorem is on the cycle itself; masses are preserved exactly by $\mathbb E_n$; the arc comparison happens in the continuum with the exact $Q,R\le\pi$.
- (c) The only places where $Q,R\le\pi$ matter are Lemma 8.16 (via Lemma 8.7(b)) and the symmetric decreasing property of $\mathbf 1_{[-Q,Q]}$. Both are automatic from $0\le\varphi_1,\varphi_2\le1$.

### 8.5 Arc energy and the circle block inequality

#### Lemma 8.18 (arc energy and $h$)

**Source:** paper Lemma 8.18.

For $0<Q,R\le\pi$ put $\mathcal A(Q,R)=\frac1{4QR}\int_{-Q}^{Q}\int_{-R}^{R}K(\theta-\theta')\,d\theta'\,d\theta$, $x_n(X)=\frac{\sin nX}{nX}$, and $h(X)=\mathcal A(X,X)-\log(X/\pi)$. Then:

- (a) $\mathcal A(Q,R)=-\sum_{n\ge1}\frac{\sin(nQ)\sin(nR)}{n^3QR}$, absolutely convergent.
- (b) $2\mathcal A(Q,R)-\mathcal A(Q,Q)-\mathcal A(R,R)=\sum_{n\ge1}\frac{(x_n(Q)-x_n(R))^2}n\ge0$.
- (c) $\mathcal A(Q,Q)=2\int_0^1(1-x)\log(2\sin Qx)\,dx$, and $h(Q)=\log(2\pi)-\frac32+2\int_0^1(1-x)\log\frac{\sin Qx}{Qx}\,dx$.
- (d) $h$ is strictly decreasing on $(0,\pi]$, $h(\pi)=0$, and $h(0^+)=\log(2\pi)-\frac32\approx0.33788$. Hence $h\ge0$ on $(0,\pi]$.
- (e) For $n_0\ge1$: $-\frac1{2n_0^2Q^2}\le\mathcal A(Q,Q)+\sum_{n=1}^{n_0}\frac{\sin^2nQ}{n^3Q^2}\le0$. This is Wang's (7.11) with $n_0=80$.

*Proof.*

- (a) For $0<\lambda<1$, $K_\lambda(t)=\log|1-\lambda e^{it}|=-\sum_n\lambda^n\cos(nt)/n$, absolutely and uniformly convergent.
  - $\int_{-Q}^{Q}\int_{-R}^{R}\cos n(\theta-\theta')=\frac{4\sin nQ\sin nR}{n^2}$, since the sine–sine part vanishes by oddness. Termwise integration gives $\frac1{4QR}\iint K_\lambda=-\sum_n\lambda^n\frac{\sin nQ\sin nR}{n^3QR}$.
  - As $\lambda\uparrow1$, the right side converges (dominated by $\sum n^{-3}$).
  - On the left, $K_\lambda\to K$ pointwise off $t\in2\pi\mathbb Z$. Domination: $\log|1-\lambda e^{it}|\le\log2$. Also $|1-\lambda e^{it}|^2=(\lambda-\cos t)^2+\sin^2t$, which is $\ge\sin^2t$, and $\ge1$ when $\cos t\le0$. So $|K_\lambda(t)|\le\log2+|\log|\sin t||$, which is integrable.
- (b) Termwise, $\frac{\sin nQ\sin nR}{n^3QR}=\frac{x_n(Q)x_n(R)}n$. So the left side is $\sum_n\frac1n\big(x_n(Q)^2+x_n(R)^2-2x_n(Q)x_n(R)\big)$.
- (c) The difference $t=\theta-\theta'$ of two independent uniform points of $[-Q,Q]$ has density $\frac{2Q-|t|}{4Q^2}$ on $[-2Q,2Q]$. $K$ is even, and $K(t)=\log(2\sin(t/2))$ for $0<t<2\pi$. Substituting $t=2Qx$ gives the first formula.
  - For the second, use $\int_0^1(1-x)\,dx=\frac12$ and $\int_0^1(1-x)\log x\,dx=-\frac34$ in $\log(2\sin Qx)=\log2+\log Q+\log x+\log\frac{\sin Qx}{Qx}$.
- (d) $p(t)=\sin t-t\cos t$ has $p(0)=0$ and $p'(t)=t\sin t>0$ on $(0,\pi)$. So $\operatorname{sinc}$ is strictly decreasing and positive on $(0,\pi)$.
  - For fixed $x\in(0,1)$, $Q\mapsto\log\operatorname{sinc}(Qx)$ is strictly decreasing on $(0,\pi]$. Also $(1-x)\log\operatorname{sinc}(Qx)$ is integrable, including at $Q=\pi$, $x\to1$, where it is $\sim(1-x)\log(1-x)$. Hence $h$ is strictly decreasing.
  - $\mathcal A(\pi,\pi)=0$ by (a), so $h(\pi)=0-\log1=0$.
- (e) The tail $\sum_{n>n_0}\frac{\sin^2nQ}{n^3Q^2}\in\big[0,\frac1{Q^2}\sum_{n>n_0}n^{-3}\big]$, and $\sum_{n>n_0}n^{-3}<\int_{n_0}^\infty x^{-3}dx=\frac1{2n_0^2}$. $\square$

#### Theorem 8.19 (circle block inequality; Wang Thm. 5.1)

**Source:** paper Theorem 8.19.

Assume (H1), (H2). Let $I'\subset(0,1)$ be a quantile interval with angular image $J$, masses $q'=|I'|$, $r'=\hat\xi(I')$, and normalized masses $Q,R$ (Lemma 8.1). Then
$$\frac{\mathcal E(I')}{q'r'}-\log\frac{q'r'}2-\frac{C_{\rm eff}}{q'}\ \ge\ \log\frac{2H}{a_\pi b_\pi}+h(Q)+h(R)+\sum_{n\ge1}\frac{(x_n(Q)-x_n(R))^2}n-\frac{\pi C_{\rm eff}}{a_\pi Q}.\tag{8.5}$$
Consequently, if the right side of (8.5) is $\ge0$ (respectively $>0$) for all $(Q,R)\in(0,Q_{\max}]\times(0,R_{\max}]$, then (8.4) holds (respectively strictly) for every quantile interval $I'$.

*Proof.*

1. *Physical to normalized masses.* By Lemma 8.1, $q'=a_\pi Q/\pi$ and $r'=b_\pi R/\pi$.
2. *Unfolding.* On $[-\pi,\pi]$, extended $2\pi$-periodically, put $\varphi_1(\theta)=\mathbf 1_J(|\theta|)\alpha(|\theta|)/a_\pi$ and $\varphi_2(\theta)=\mathbf 1_J(|\theta|)B(|\theta|)/b_\pi$. These are measurable with $0\le\varphi_1,\varphi_2\le1$ (Lemma 8.1(1),(2): $0\le\alpha\le a_\pi$ and $0\le B\le b_\pi$). Also $\int_{\mathbb T}\varphi_1=2Q$ and $\int_{\mathbb T}\varphi_2=2R$.
   - Split each variable into its positive and negative halves. For $t_1,t_2\in J$ the four sign pairs give $K(t_1-t_2)$ twice and $K(t_1+t_2)$ twice, by evenness of $K$. With Lemma 8.2(a) and Lemma 8.3 (Fubini), and the symmetry of $\log|d(\theta)-d(\theta')|$ in $(\theta,\theta')$,
$$\iint_{\mathbb T^2}\varphi_1(\theta)\varphi_2(\theta')K(\theta-\theta')=\frac2{a_\pi b_\pi}\int_J\!\int_JB(\theta)\alpha(\theta')\log\frac{|d(\theta)-d(\theta')|}H\,d\theta'\,d\theta.\tag{8.6}$$

   - With Lemma 8.1(3), this gives
$$\frac{\mathcal E(I')}{q'r'}=\log H+\frac1{2QR}\iint_{\mathbb T^2}\varphi_1\varphi_2\,K.\tag{8.7}$$

   - This is Wang's (5.3), in the equivalent form: (8.6) divided by $2QR$. The factors: $\pi^2\mathcal E=\iint B\alpha\log|\cdot|$, $q'r'\pi^2=a_\pi b_\pi QR$, and $\iint B\alpha\log H=\pi^2q'r'\log H$.
3. *Rearrangement.* Put $\mathcal L=\log2-K=-\log|\sin(t/2)|$ on $[-\pi,\pi]$, periodically extended. It is $\ge0$, even, nonincreasing in $|t|$ on $(0,\pi]$, and integrable. For $N\in\mathbb N$ (a truncation level, not the number of atoms), $\mathcal L_N=\min(\mathcal L,N)$ (with $\mathcal L_N(0)=N$) takes values in $[0,N]$ and is symmetric decreasing.
   - Apply Theorem 8.8 with $\kappa=\mathcal L_N=\min(\mathcal L,N)$, $\bar\kappa=N$, and the $\varphi_1,\varphi_2$ of step 2 (values in $[0,1]$, masses $2Q,2R$): $\iint\varphi_1(\theta)\varphi_2(\theta')\mathcal L_N(\theta-\theta')\le\int_{-Q}^{Q}\int_{-R}^{R}\mathcal L_N(\theta-\theta')$.
   - Then let $N\to\infty$: both integrands are $\ge0$ and increase to the corresponding $\mathcal L$-integrands off the null diagonal $\theta=\theta'$. Monotone convergence gives $\iint\varphi_1\varphi_2\,\mathcal L\le\int_{-Q}^{Q}\int_{-R}^{R}\mathcal L(\theta-\theta')<\infty$.
   - Since $\iint\varphi_1\varphi_2\cdot\log2=4QR\log2$ depends only on the masses, $\iint\varphi_1\varphi_2K\ge\int_{-Q}^{Q}\int_{-R}^{R}K=4QR\,\mathcal A(Q,R)$.
4. By (8.7), $\frac{\mathcal E(I')}{q'r'}\ge\log H+2\mathcal A(Q,R)$.
5. By Lemma 8.18(b) and the definition of $h$, $2\mathcal A(Q,R)=\log\frac Q\pi+h(Q)+\log\frac R\pi+h(R)+\Sigma(Q,R)$, where $\Sigma(Q,R)=\sum_n(x_n(Q)-x_n(R))^2/n$.
6. With $\log\frac{q'r'}2=\log\frac{a_\pi b_\pi QR}{2\pi^2}$, the $\log\frac{QR}{\pi^2}$ terms cancel and leave $\log H-\log\frac{a_\pi b_\pi}2=\log\frac{2H}{a_\pi b_\pi}$.
7. Finally $\frac{C_{\rm eff}}{q'}=\frac{\pi C_{\rm eff}}{a_\pi Q}$. This proves (8.5).
8. *Consequence.* The left side of (8.5) is $\frac1{q'r'}\big[\mathcal E-q'r'\log\frac{q'r'}2-C_{\rm eff}r'\big]$ with $q'r'>0$. The pair $(Q,R)$ of any quantile interval lies in $(0,Q_{\max}]\times(0,R_{\max}]$ (Lemma 8.1(5)). $\square$

*Remarks.*

- (i) $h$ appears only at $Q,R\in(0,\pi]$, where $h\ge0$ (Lemma 8.18(d)). The fact $h\ge0$ is not itself used in (8.5); it is used only in the terminal-range certificate (§9).
- (ii) The coupling between $Q$ and $R$ (both come from the same $J$) is discarded. The rectangle is a superset, which is conservative.
- (iii) Wang's text applies the circle Riesz (Baernstein) inequality "first to $\min(\mathcal L,N)$ and then by monotone convergence". Step 3 has the same structure, with Theorem 8.8 in place of the cited theorem.
- (iv) The monotonicity of $\alpha$ and $B$ is used exactly once, to get $0\le\varphi_1,\varphi_2\le1$. Without the cap $\varphi_1\le1$, $\varphi_1$ could exceed $1$ and Theorem 8.8 would not apply.

#### Corollary 8.20 (scalar reduction for $C_{\rm eff}\le0$; Wang (7.9)–(7.11))

**Source:** paper Corollary 8.20.

Assume (H1), (H2) and $C_{\rm eff}\le0$. Put
$$\Upsilon=\log\frac{2H}{a_\pi b_\pi}+h(Q_{\max})+h(R_{\max}),\qquad\varpi=-\frac{\pi C_{\rm eff}}{a_\pi}\ge0 .$$
Then for all $(Q,R)\in(0,Q_{\max}]\times(0,R_{\max}]$ the right side of (8.5) is
$$\ge\ \mathcal S(Q,R):=\Upsilon+\frac\varpi Q+(\operatorname{sinc}Q-\operatorname{sinc}R)^2,$$
and
$$\inf_{\text{rectangle}}\mathcal S\ \ge\ \min\Big\{\ \Upsilon+\frac\varpi{\min(Q_{\max},R_{\max})}\ ,\ \min_{1\le m\le m_1}\Big[\Upsilon+\frac\varpi{Q^{(m)}}+\big(\operatorname{sinc}R_{\max}-\operatorname{sinc}Q^{(m-1)}\big)^2\Big]\Big\},$$
where $R_{\max}=Q^{(0)}<Q^{(1)}<\dots<Q^{(m_1)}=Q_{\max}$ is any partition. The second term is present only if $R_{\max}<Q_{\max}$.

*Proof.*

1. $h$ is decreasing on $(0,\pi]$ and $Q\le Q_{\max}\le\pi$, $R\le R_{\max}\le\pi$ (Lemma 8.1(5)). So $h(Q)+h(R)\ge h(Q_{\max})+h(R_{\max})$.
2. All terms of $\Sigma$ are $\ge0$. Keep only $n=1$, where $x_1=\operatorname{sinc}$. Also $-\pi C_{\rm eff}/(a_\pi Q)=\varpi/Q$. This proves the first claim.
3. *Case $Q\le\min(Q_{\max},R_{\max})$.* $\mathcal S\ge\Upsilon+\varpi/Q\ge\Upsilon+\varpi/\min(Q_{\max},R_{\max})$, since $\varpi\ge0$.
4. *Case $Q\in[Q^{(m-1)},Q^{(m)}]\subset[R_{\max},Q_{\max}]$.*
   - $R\le R_{\max}\le Q^{(m-1)}\le Q\le\pi$. Since $\operatorname{sinc}$ is decreasing on $(0,\pi]$: $\operatorname{sinc}R\ge\operatorname{sinc}R_{\max}\ge\operatorname{sinc}Q^{(m-1)}\ge\operatorname{sinc}Q$.
   - Hence $(\operatorname{sinc}R-\operatorname{sinc}Q)^2\ge(\operatorname{sinc}R_{\max}-\operatorname{sinc}Q^{(m-1)})^2$ and $\varpi/Q\ge\varpi/Q^{(m)}$. $\square$

*Remarks.*

- The partition bound needs only evaluations of $\operatorname{sinc}$ at partition points and converges to $\min_{[R_{\max},Q_{\max}]}\mathcal S(\cdot,R_{\max})$ as the mesh tends to $0$, whether or not $Q\mapsto\mathcal S(Q,R_{\max})$ is monotone. It is **not** monotone in general (paper Appendix B, item 12), so "evaluate at $Q_{\max}$" must not be used without a derivative certificate; the certificates of §9 use the partition bound.
- For $h(Q_{\max})$ and $h(R_{\max})$, Lemma 8.18(e) gives rigorous two-sided bounds from a finite sum. A checker must use the *lower* bound $h(X)\ge-\sum_{n\le n_0}\frac{\sin^2nX}{n^3X^2}-\frac1{2n_0^2X^2}-\log\frac X\pi$ with outward rounding.

---

## Exterior formulas and identification of the terminal reference

**Source:** paper Lemma 9.1 and the terminal-family calculation immediately following it. Positivity of the reference density alone does not supply strict separation; the extra sign hypothesis in Lemma 9.1(iv) is essential.

### Lemma 9.1 (exterior formulas for the reference $\eta_{k,a}$ in the variable $v$)

**Source:** paper Lemma 9.1.

Let $1\le a<2$ and $k\ge1$ with $\eta_{k,a}\ge0$. In the shifted normalized coordinates of Definition 3.5, put:

- $s=\sqrt{a/2}$, $\rho_0=\frac{\sqrt2-\sqrt a}{\sqrt2+\sqrt a}$, $D_0=\frac{(\sqrt2+\sqrt a)^2}4$, $H=\frac{2-a}4$, $c=\frac{a+2}2$, $A=\frac k{k+1}$ (this is the main mass fraction of Lemma 3.4, since $k=A/(1-A)$);
- $C=\log H+k\log D_0$ (the platform constant, Proposition 6.3(4)).

For $x<a$ write $x=c-H(u+u^{-1})$ with $u>1$ (Joukowski variable; $u=1/\rho_x$ in the notation of Lemma 7.2, and $x=0\leftrightarrow u=1/\rho_0$), and put $v=\rho_0u$. Then:

- (i) $H=\rho_0D_0$, and $x=c-D_0v-H\rho_0/v$.
- (ii) For $x<a$, $x\ne0$ (i.e. $v>\rho_0$, $v\ne1$): $W_0(x)=k\log|x|+\int\log|x-d|\,d\eta_{k,a}(d)=-(k+1)\,\mathfrak E(v)$, where
$$\mathfrak E(v)=A\log\frac{v-\rho_0^2}{|1-v|}-\log v-\log D_0 .$$
  At $x=0$ we have $W_0(0)=-\infty$. Also $\mathfrak E(v)\to-C/(k+1)$ as $v\downarrow\rho_0$ (i.e. $x\uparrow a$).

- (iii) For the same $x$: $W_0'(x)=\dfrac{(k+1)\mathfrak E'(v)}{D_0(1-\rho_0^2/v^2)}$, with $\mathfrak E'(v)=A\big(\frac1{v-\rho_0^2}+\frac1{1-v}\big)-\frac1v$.
- (iv) **Assume in addition** $A<s$ and that $\mathfrak E(v_0)<0$ for some $v_0\in(\rho_0,1)$ (equivalently, $W_0(x_0)>0$ for some $x_0\in(0,a)$). Then:
  - $\mathfrak E$ has a unique root $v_+$ in $(v_0,1)$. It lies on the increasing branch, and $\mathfrak E'(v_+)>0$.
  - $\mathfrak E$ has a unique root $v_-$ in $(1,\infty)$, and $\mathfrak E'(v_-)<0$.
  - The component of $\{W_0<0\}$ containing $0$ is $(x_-,x_+)$ with $x_\pm=x(v_\pm)$. In particular $x_-<0<x_+<a$, and both crossings are simple ($W_0'(x_\pm)\ne0$).
  - Moreover $\rho_\pm=1/u_\pm=\rho_0/v_\pm$ and $K_\pm=H(u_\pm-u_\pm^{-1})$.
  - The extra hypothesis holds automatically when $A<s$ and $C\ge0$ (in particular for the terminal family, where $C=0$). For the rows R1, R2 it is certified per slab (Certificate 9.2).

*Remark (the extra hypothesis in (iv) is needed).* Positivity $\eta_{k,a}\ge0$, even with $A<s$, does not imply it. Take $k=2$, $a=1$. Then $A=2/3<s=1/\sqrt2$ and (6.3) holds strictly. Since $\eta_{2,1}$ is a probability measure on $[1,2]$, for $0<x<1$ we get $W_0(x)\le2\log x+\log(2-x)=\log\big(x^2(2-x)\big)<0$. Also $C=\log\frac14+2\log\frac{3+2\sqrt2}4=\log\frac{17+12\sqrt2}{64}<0$. So $W_0<0$ on all of $(0,a]$: there is no crossing in $(0,a)$, and the conclusion of (iv) fails.

*Proof.*

- (i) $2-a=(\sqrt2-\sqrt a)(\sqrt2+\sqrt a)$.
- (ii) Proposition 6.3(6) (with $e^{\tau_x}=u$, $\rho_x=1/u$) gives $W_0(x)=k\log|x|+\log(Hu)-2k\log(1-\rho_0/u)$. The same computation as Lemma 5.1(iii), with the atom at $0$ in place of $-1$, gives $|x|=H\frac{(u-\rho_0)|1-\rho_0u|}{\rho_0u}$.
  - Substituting, $W_0=C+(k+1)\log u-k\log\frac{u-\rho_0}{|1-\rho_0u|}$.
  - Put $u=v/\rho_0$ and use $\frac C{k+1}=(1-A)\log\rho_0+\log D_0$ (from (i)).
- (iii) is the chain rule with $dx/dv=-D_0(1-\rho_0^2/v^2)$.
- The limit in (ii): as $v\downarrow\rho_0$, $\frac{v-\rho_0^2}{1-v}\to\rho_0$, so $\mathfrak E\to(A-1)\log\rho_0-\log D_0=-C/(k+1)$ by the identity above.
- (iv) This is the shape analysis of Lemma 5.2(iv) with $q\to\rho_0$, for either sign of $C$. Note that $\eta_{k,a}\ge0$ is equivalent to $A\le s$, and that $s=\frac{1-\rho_0}{1+\rho_0}$.
  - The map $v\mapsto x(v)$ is strictly decreasing on $(\rho_0,\infty)$ ($dx/dv<0$), with $x(\rho_0)=a$ and $x(1)=0$. By (ii), $W_0<0\iff\mathfrak E>0$ for $v\ne1$.
  - *On $(\rho_0,1)$.* Here $v(v-\rho_0^2)(1-v)>0$ and $\mathfrak E'\,v(v-\rho_0^2)(1-v)=P(v):=v^2-(1+\rho_0^2-A(1-\rho_0^2))v+\rho_0^2$.
    - $P(\rho_0)=\rho_0(1-\rho_0)\big[A(1+\rho_0)-(1-\rho_0)\big]<0$, because $A<s$. Also $P(1)=A(1-\rho_0^2)>0$.
    - So $P$ has exactly one root $v^\ast$ in $(\rho_0,1)$. Hence $\mathfrak E$ is strictly decreasing on $(\rho_0,v^\ast]$ and strictly increasing on $[v^\ast,1)$, with $\mathfrak E\to+\infty$ as $v\uparrow1$.
    - We have $\mathfrak E(v^\ast)\le\mathfrak E(v_0)<0$. So $\mathfrak E$ has exactly one root $v_+$ in $(v^\ast,1)$, and $\mathfrak E'(v_+)>0$.
    - Also $\mathfrak E<0$ on $[\min(v_0,v^\ast),v_+)$. So $v_+$ is the only root in $(v_0,1)$, and $\mathfrak E>0$ on $(v_+,1)$ while $\mathfrak E<0$ just below $v_+$.
  - *On $(1,\infty)$.* Here $\mathfrak E'=A\big(\frac1{v-\rho_0^2}-\frac1{v-1}\big)-\frac1v<0$. Also $\mathfrak E\to+\infty$ as $v\downarrow1$ and $\mathfrak E\to-\infty$ as $v\to\infty$. So there is a single root $v_-$, $\mathfrak E'(v_-)<0$, and $\mathfrak E>0$ exactly on $(1,v_-)$.
  - *In the variable $x$.* $W_0<0$ on $(x_-,0)\cup(0,x_+)$, and $W_0(0)=-\infty$. Also $W_0(x_\pm)=0$, and $W_0>0$ just outside $[x_-,x_+]$ on both sides. So the component containing $0$ is $(x_-,x_+)$. Simplicity follows from (iii), since $\mathfrak E'(v_\pm)\ne0$.
  - *The case $C\ge0$.* Then $\mathfrak E(\rho_0^+)=-C/(k+1)\le0$ and $\mathfrak E$ is strictly decreasing just to the right of $\rho_0$. So $\mathfrak E(v_0)<0$ for $v_0$ slightly above $\rho_0$. $\square$

The quantities entering Corollary 8.20 are then:

- $\sigma_+=1/W_0'(x_+)$ and $\sigma_-=-1/W_0'(x_-)$;
- $a_\pi=1+\frac{2k\rho_0}{1+\rho_0}$, $b_\pi=\sum_\pm\frac{4\sigma_\pm\rho_\pm}{1-\rho_\pm^2}$, $R_\xi=\xi(I)=\sum_\pm\frac{2\sigma_\pm\rho_\pm}{1-\rho_\pm}$ (Lemmas 7.10 and 8.1);
- $Q_{\max}=\pi/a_\pi$, $R_{\max}=\pi R_\xi/b_\pi$, $M_0=x_+-x_-$, and $C_{\rm eff}=C+(L-M_0)/R_\xi$.

**The terminal family.** For $q\in(0,q_s)$ take $\rho_0=q$, i.e. $a=2s^2$ with $s=\frac{1-q}{1+q}$, and $k$ with $A=k/(k+1)=A(q)$ (Definition 5.3). Then $H=\frac{2q}{(1+q)^2}$ and $D_0=\frac2{(1+q)^2}=H/q$, and:

- *$C=0$ exactly.* By (i), $\frac C{k+1}=(1-A)\log q+\log\frac Hq=\log H-A\log q=0$, since $A=\log H/\log q$.
- *$\eta_{k,a}$ is the normalized residual of $\mu_{A(q)}$.* The arcsine measure $\omega$ and the balayage $\omega_{-1}$ of Lemma 5.1, shifted by $+1$, are $e_I$ and $\omega_{0,I}$ (their densities agree, since $2s=\sqrt{2a}$ and $a^\circ+1=a$), so $\mu_{A(q)}=A\delta_{-1}+(1-A)\,\eta_{k,a}(\cdot+1)$ with $k=A/(1-A)$.
- *$M_0=\Lambda(q)\ge D$.* In the shifted variable $W_0=V_{\mu_{A(q)}}(\cdot-1)/(1-A)$, and $E_{\mu_{A(q)}}$ is a single interval (Lemma 5.2(v) with $C(A)=0$), so the main width of $W_0$ is $|E_{\mu_{A(q)}}|=\Lambda(q)\ge D$.

## Computer-assisted certificate inputs

**Source:** paper Certificate 5.5, Certificate 9.2, §9.4 and Appendix A; audit §§10–13. All paths in this section are relative to this document's directory **Erdos_1038/**. The actual package is **Erdos_1038/cert/**, with implementations in `cert/cert2/` and `cert/cert3/`. It is not the stale sibling `../cert/` used as a default by older replay drivers.

The analytic proof above reduces the theorem to the following specific predicates. Successful interval certification supplies these predicates; samples or a plotted minimum would not suffice.

### Arithmetic and verification meaning

The first implementation uses exact rational arithmetic (`Fraction`) with outward dyadic rounding at \(2^{-220}\) in [cert/cert2/ia.py](cert/cert2/ia.py); [iad.py](cert/cert2/iad.py) propagates interval first derivatives. The second uses a separate integer fixed-point interval library at \(2^{-112}\), [cert/cert3/ivl.py](cert/cert3/ivl.py). Addition, multiplication, reciprocals and square roots enclose their real values with outward rounding; division is accepted only when the denominator interval excludes zero. Logarithm, exponential, sine/cosine and \(\pi\) use explicit convergent-series remainder bounds and range reduction (including Machin bounds for \(\pi\)). These are the interval-library obligations inspected in the audit and described in paper Appendix A.1.

Floating-point guesses used to propose a root bracket, a partition or a reduction integer have no authority to accept a sign. The exact interval tests must validate the bracket, branch, remainder and inequality before the checker can pass. A positive printed margin is a rounded-down display of a certified lower bound, not an exact minimum of the function. A cover passes only after its stack of slabs is exhausted; an unresolved slab is refined or rejected, never silently accepted.

### Certificate A: the small-ratio constants and a family upper value

**Source:** Proposition 4.1 and Certificate 5.5.

For \(K=29/20\) and \(\bar\varepsilon=2-(K+1)K^{-K/(K+1)}\), [smallk_check.py](cert/cert2/smallk_check.py) certifies
\[
0<\bar\varepsilon<\frac1{25},\qquad
\log3-K\log2-\frac{6\bar\varepsilon}{e}>0.
\]
The stored enclosures are \(0.033642075\le\bar\varepsilon\le0.033642076\) and a lower margin exceeding \(0.01929\). These prove the strict last AM–GM estimate in Proposition 4.1.

[onecut_check.py](cert/cert2/onecut_check.py) certifies
\[
\mathfrak f(1236/10000)>0>\mathfrak f(1237/10000),\qquad
\mathfrak f(\widehat q)>0,\qquad \Lambda(\widehat q)<L_{\rm hi}.
\]
For the last inequality it brackets the increasing-branch root \(u_+\in(1,1/\widehat q)\) with strict negative/positive signs and the decreasing-branch root \(u_->1/\widehat q\) with strict positive/negative signs; rational bisection preserves these signs. Since \(u+u^{-1}\) is increasing for \(u>1\), the resulting interval root bounds give a rigorous upper width bound. The second implementation [side3.py](cert/cert3/side3.py), checks S1 and S3b, independently certifies the family value and domain, including derivative signs on its final root boxes. This establishes (D-upper) and is the only numerical information about \(D\) needed here. The threshold bracket is supplementary; the definition of \(q_s\) remains its unique exact zero.

### Certificate B: the two finite reference rows

**Source:** Certificate 9.2, affine rows R1 and R2; Lemma 9.1; Corollary 8.20.

Use the target \(L=L_{\rm hi}\) and the following exact domains:

| Row | Full mass-ratio domain | Reference endpoint |
|---|---|---|
| R1 | \(36/25\le k\le21/10\) | \(a(k)=1153/500-k/4\), hence \(1781/1000\le a\le973/500\) |
| R2 | \(21/10\le k\le21/5\) | \(a(k)=9/5\) |

On **every parameter value** in each row the certificates prove the following:

1. \(A=k/(k+1)<s=\sqrt{a/2}\). This supplies (H1), strictly.
2. A root box \([p_+,r_+]\subset(\rho_0,1)\) has \(\mathfrak E(p_+)<0<\mathfrak E(r_+)\) and \(\mathfrak E'>0\) throughout the box. A box \([p_-,r_-]\subset(1,\infty)\) has \(\mathfrak E(p_-)>0>\mathfrak E(r_-)\) and \(\mathfrak E'<0\) throughout. All signs hold for the entire parameter slab. In particular the value \(v_0=p_+\) supplies the extra hypothesis of Lemma 9.1(iv). The certified roots give \(x_-<0<x_+<a\), \(\sigma_\pm>0\), and therefore (H2).
3. With the definitions following Lemma 9.1,
   \[
   Q_{\max}\le\pi,\qquad 0<R_{\max}<Q_{\max},\qquad C_{\rm eff}<0.
   \]

4. Put
   \[
   \Upsilon=\log\frac{2H}{a_\pi b_\pi}+h(Q_{\max})+h(R_{\max}),\qquad
   \varpi=-\frac{\pi C_{\rm eff}}{a_\pi}>0.
   \]
   The code certifies \(\Upsilon+\varpi/R_{\max}>0\). The ideal mathematical partition criterion of Corollary 8.20 is: for a finite partition
   \(R_{\max}=t_0<t_1<\cdots<t_m=Q_{\max}\) the cell tests are
   \[
   \Upsilon+\frac{\varpi}{t_j}
    +\big(\operatorname{sinc}R_{\max}-\operatorname{sinc}t_{j-1}\big)^2>0
       \quad(1\le j\le m).
   \]
   Strict positivity of these cell bounds proves the inequality for every allowed \(Q\). The programs implement this criterion by partitioning an **outward enclosure** of \([R_{\max},Q_{\max}]\) on each parameter slab; they do not output exact parameter-dependent vertices. For bounds \(R_{\max}\le R_{\rm hi}\), \(\Upsilon\ge B_{\rm lo}\), \(\varpi\ge P_{\rm lo}\ge0\), a covering cell \([t_{\rm lo},t_{\rm hi}]\) has the safe cert3 lower bound
   \[
   B_{\rm lo}+\frac{P_{\rm lo}}{t_{\rm hi}}
   +\left[\max\left(0,\operatorname{sinc}_{\rm lo}(R_{\rm hi})
          -\operatorname{sinc}_{\rm hi}(t_{\rm lo})\right)\right]^2.
   \]
   Here the sinc subscripts denote rigorous lower/upper interval or table bounds. Cert2 uses the lower endpoint of the interval square of the sinc difference. The outward cells cover all actual \(Q\) in the second branch; the first-branch bound covers \(Q\le R_{\max}\). Restricting cells to the actual interval gives the ideal partition argument. Thus the accepted positive bounds imply positivity on **all** \((Q,R)\in(0,Q_{\max}]\times(0,R_{\max}]\), without assuming that the full scalar expression is monotone.

The diagonal energies are enclosed using Lemma 8.18(e), including its explicit negative tail:
\[
h(X)\ge-\sum_{n=1}^{N}\frac{\sin^2(nX)}{n^3X^2}
 -\frac{1}{2N^2X^2}-\log(X/\pi),\qquad 0<X\le\pi.
\]
The first implementation is [cover_mv.py](cert/cert2/cover_mv.py), using [cover_check.py](cert/cert2/cover_check.py), `ia.py` and `iad.py`. Its commands, from `Erdos_1038/cert/cert2/`, are `python cover_mv.py chunk R1 i 7 96` and `python cover_mv.py chunk R2 i 7 96` for each integer \(i=0,\ldots,6\). The seven exact chunks in each row tile its closed domain, with 96 initial slabs per chunk. For a slab \(\mathcal K\) with midpoint \(k_m\), the mean-value enclosure is
\[
X(\mathcal K)\subset X(k_m)+X'(\mathcal K)(\mathcal K-k_m).
\]
Interval automatic differentiation encloses \(X'\), including
\(v_\pm'=-\mathfrak E_k/\mathfrak E_v\) on certified whole-slab root boxes. The denominator is sign-definite. The exact affine coefficients of \(a(k)\) are shared by the value and derivative calculations.

[cover3.py](cert/cert3/cover3.py) independently certifies the same predicates using `ivl.py`, natural interval extensions, algebraic cancellations, diagonal-energy lower tables and angular partitions. The inspected stored fine covers have 3,300 R1 leaves and 4,200 R2 leaves. These counts describe existing execution records; the proof is based on their certified inequalities and exact domain coverage, not their counts.

### Certificate C: the complete terminal tail

**Source:** paper Certificate 9.2, terminal row and side checks; paper Appendix A.3; audit §11 correction.

Set \(q_2=21/500\). The side certificates in [terminal_check.py](cert/cert2/terminal_check.py) and [side3.py](cert/cert3/side3.py), S2–S4, prove
\[
\mathfrak f(q_2)>0,\qquad
\frac{418951734}{10^8}\le k(q_2)\le\frac{418951735}{10^8}<\frac{21}{5}.
\]
For **every** \(0<q\le q_2\), take the zero-platform terminal reference
\[
a(q)=2\left(\frac{1-q}{1+q}\right)^2,\quad
D_0(q)=\frac{2}{(1+q)^2},\quad H(q)=qD_0(q),\quad
k(q)=\frac{\log(1/q)}{\log D_0(q)}-1,
\quad L=D.
\]
The checker certifies correct branch root boxes with sign-definite \(\mathfrak E'\), simple crossings, \(x_-<0<x_+<a\), nonnegative interval enclosures of \(\sigma_\pm\), and the uniform scalar predicate
\[
\tag{terminal-scalar}
\log\frac{2H}{a_\pi b_\pi}+h(Q_{\max})+h(R_{\max})>0.
\]
The analytic root signs make the actual \(\sigma_\pm\) **strictly** positive for each positive \(q\). The remaining hypotheses need no circular numerical premise: \(A<s\) follows from \(\mathfrak f(q)>0\); \(Q_{\max}\le\pi\) and \(R_{\max}<\pi\) follow from Lemma 8.1; and
\[
C=0,\qquad M_0=\Lambda(q)\ge D,\qquad
C_{\rm eff}=\frac{D-\Lambda(q)}{R_\xi}\le0
\]
follow from the exact terminal identity and the **definition of \(D\)**. No assertion about \(M(f)\) is used here. Because \(h\) is decreasing and nonnegative on \((0,\pi]\), \(\varpi\ge0\), and the sinc square is nonnegative, (terminal-scalar) implies the required strict scalar inequality on the whole rectangle. No terminal assumption \(R_{\max}<Q_{\max}\) is necessary.

The command `python terminal_check.py 32`, run from `Erdos_1038/cert/cert2/`, certifies the complete compactified domain; its existing record refines 32 initial slabs to 36 leaves with certified margin at least \(0.03381\). `cert/cert3/cover3.py` provides the separate terminal implementation; its stored fine cover has 3,000 leaves with smallest printed lower margin \(0.0686173\).

**The limit adjoining \(q=0\).** Write \(r=1/\log(1/q)\). Then \(q=e^{-1/r}\), \(0<r\le r_2=1/\log(500/21)\), and
\[
\frac1{k+1}=d_qr,\qquad
kq=\frac{e^{-1/r}}{d_qr}-e^{-1/r}.
\]
The second expression has a finite limit, because \(\tau e^{-\tau}\to0\) and is decreasing for \(\tau\ge1\). However \(k\) itself diverges. Nor is the scalar logarithm's argument bounded: with
\[
w_\pm=\frac1{v_\pm|\mathfrak E'(v_\pm)|},
\qquad
\frac{2H}{a_\pi b_\pi}=\frac{k+1}{2a_\pi(w_++w_-)},
\]
the limiting equation is \(-\log|1-v|-\log2=0\). Its simple roots and their derivatives give
\[
v_+\to\tfrac12,\quad v_-\to\tfrac32,\quad
w_+\to1,\quad w_-\to\tfrac13,\quad a_\pi\to1,
\qquad \frac{2H}{a_\pi b_\pi}\sim\frac{3(k+1)}8\to\infty.
\]
For completeness, the root limits follow from uniform convergence of \(\mathfrak E\) and \(\mathfrak E'\) on small compact neighborhoods of these two simple limiting roots, preserving opposite endpoint signs and the derivative sign; the branch uniqueness in Lemma 9.1 then identifies the enclosed roots. Also \(a_\pi=1+2kq/(1+q)\to1\).

The implemented correction is to enclose **bounded scaled quantities** and give a one-sided lower bound on the favorable divergent factor. On a slab \(0<r\le r_{\rm hi}\), \(1/r\ge1/r_{\rm hi}\), and
\(\log(k+1)=-\log(d_qr)\ge-\log(d_{q,\rm hi}r_{\rm hi})\).
The bounded factors supply the rest of a lower enclosure. Thus no interval reciprocal through zero and no finite value of \(k\) at \(q=0\) is required. The slab adjoining zero certifies all sufficiently small **positive** \(q\). This corrects Certificate 9.2's statement that the parametrization keeps every quantity finite; the actual implemented enclosure handles the divergence.

### Existing execution evidence and its limits

This document was prepared by reading the current sources and execution records. **No interval checker or Lean build was rerun while preparing this document.** The earlier sequential audit in this conversation recorded fresh execution on 30 September 2026; its results are stored in [audit_cert_runs/re-audit-20260930/results.json](audit_cert_runs/re-audit-20260930/results.json), [summary.json](audit_cert_runs/re-audit-20260930/summary.json) and [hashes.json](audit_cert_runs/re-audit-20260930/hashes.json). These records report all 41 main-suite jobs passing, all 14 pinned implementation hashes matching before and after execution, and exact leaf-cover/positive-lower-bound validation by [verify_reaudit.py](audit_cert_runs/re-audit-20260930/verify_reaudit.py). The certificate subset specified above suffices for this proof; the supremum, global lower digits for \(D\), and fixed-degree computations from the broader replay are not premises here.

Stored logs document a successful execution; the mathematical certification comes from the implementing enclosure formulas, verified predicates and complete cover. The interval implementations remain inspected Python proof components, rather than Lean-kernel certificates. [diagnostic_checks.json](audit_cert_runs/re-audit-20260930/diagnostic_checks.json), `audit_recheck.py`, floating-point minima, quadrature and searches are diagnostics only. They prove neither an interval-wide sign nor a unique or attained family minimum.

## Why the parameter cover is exhaustive

**Source:** paper Certificate 9.2 and Theorem 10.1.

After the single-root case and the small-ratio branch, the only remaining normal forms have finite \(k>29/20\). The exact inequalities
\[
\frac{36}{25}<\frac{29}{20}<\frac{21}{10}<\frac{21}{5},\qquad
k(q_2)<\frac{21}{5}
\]
show that the small branch overlaps R1, R1 meets R2, and R2 overlaps the terminal branch.

To prove that the terminal reference supplies **every** required large mass ratio, rather than only a sequence of ratios, observe that \(k(q)=\tau/d_q-1\) is continuous on \((0,q_2]\), \(d_q\to\log2>0\), and \(\tau\to\infty\) as \(q\downarrow0\). Thus \(k(q)\to\infty\). For any finite \(k_*\ge k(q_2)\), select a sufficiently small positive \(q_0\) with \(k(q_0)>k_*\); the intermediate value theorem on \([q_0,q_2]\) gives \(q\) with \(k(q)=k_*\). This uses continuity and the terminal limit, not an assumed minimizer of \(\Lambda\). In fact differentiation gives \(k'(q)=-\mathfrak f(q)/(q(1+q)d_q^2)<0\), but monotonicity is not needed for coverage.

Every reference is in the domain of the analytic lemmas. R1 has \(1<a<2\), R2 has \(a=9/5\), and the terminal row satisfies
\[
2(479/521)^2\le a(q)<2,\qquad a(q)>1.
\]
For the latter, \(q\le21/500<1/4\) and \(0<d_q<\log2\) give \(\tau>2\log2>2d_q\), so \(k(q)>1\). Its (H1) follows from \(q<q_s\); its (H2) follows analytically from \(A<s\), \(C=0\) and Lemma 9.1(iv), and is also checked by the root boxes. The affine rows supply both hypotheses slab by slab. Targets remain admissible even at contact by Lemma 6.7. The terminal limit is used only to cover arbitrarily large finite \(k\); there is no reference assigned to an infinite mass ratio.

## Strict lower theorem and the two requested conclusions

**Source:** paper Proposition 8.6, Theorem 8.19, Corollary 8.20, Certificate 9.2 and Theorem 10.1; nonattainment consequence in Theorem 10.2.

Let \(f\in\mathcal P\). Atomization gives \(S_{\widetilde f}\subseteq S_f\); the atomized polynomial remains in \(\mathcal P\) and has the same finite positive degree. Reflect it if necessary and perform the endpoint normalization of Lemmas 3.3–3.4. These subsequent reflections and translations preserve its measure. If the result has a single distinct root, then \(M(f)\ge2>D\) by (D-upper). Otherwise Definition 3.5 gives positive residual masses \(q_i\), a finite nonempty set of distinct residual atoms, \(k\ge1\), and
\[
M(f)\ge M(\widetilde f)\ge\mathcal J_k=M_k+2\sum_{i=1}^N R_i.
\]
If \(k\le29/20\), Proposition 4.1 gives \(\mathcal J_k>2>D\). Assume henceforth \(k>29/20\).

Choose the reference from the exhaustive cover. It satisfies (H1) and (H2), and the target is admissible. Theorem 6.14 therefore applies, including if the target is in atomic contact. Theorem 7.1 retains the correction
\[
\dot M-\int g\,d\xi=-\Gamma a_\pi(d_N-2)\ge0
\]
because \(\Gamma>0\), \(a_\pi>0\) and \(d_N\le2\). The block inequality follows without requiring strictness at this step.

For any quantile block \(I'\), Lemma 8.1 supplies \(q'>0\), \(r'>0\), \(Q>0\) and \(R>0\). Theorem 8.19 bounds its normalized energy by the explicit scalar expression (8.5), and Corollary 8.20 together with the relevant certificate proves that expression **strictly positive**. Consequently
\[
\mathcal E(I')>q'r'\log(q'r'/2)+C_{\rm eff}r'.
\]
To trace strictness quantitatively, for each of the finitely many actual target blocks define
\[
\delta_i=\mathcal E(I_i)-q_i r_i\log(q_i r_i/2)-C_{\rm eff}r_i>0.
\]
All quantities are finite by Lemma 8.3 and \(q_i,r_i>0\). The minimization in Proposition 8.6 gives, for the actual \(R_i>0\),
\[
\begin{aligned}
\mathcal J_k
&\ge M_0+\sum_i\big[\mathcal E(I_i)-q_i r_i\log(q_i r_i/2)-Cr_i\big]\\
&=M_0+(C_{\rm eff}-C)\sum_i r_i+\sum_i\delta_i\\
&=L+\sum_i\delta_i>L,
\end{aligned}
\]
since \(\sum_i r_i=R_\xi\) and \(C_{\rm eff}-C=(L-M_0)/R_\xi\). This does not assume a uniform positive block mass across degrees: each fixed finite polynomial has finitely many blocks of strictly positive mass, so its sum of slacks is strictly positive.

For R1 or R2, \(L=L_{\rm hi}>D\) by (D-upper). For the terminal row, \(L=D\). In both cases \(\mathcal J_k>D\), and the weak inequalities from atomization and residual widths preserve that strict comparison. We have proved
\[
\boxed{M(f)>D\quad\text{for every nonconstant monic real polynomial with all roots in }[-1,1].}
\]
Every use of \(\Lambda(q)\ge D\) above concerned a reference-family value and followed from the definition of infimum. No intermediate step used the desired universal polynomial lower bound.

**Universal lower bound.** For every such \(f\), the proved strict inequality immediately gives \(M(f)\ge D\).

**Nonattainment.** If a finite-degree \(f\) in this class satisfied \(M(f)=D\), the strict inequality would give \(D>D\), a contradiction. Hence every such \(f\) satisfies \(M(f)\ne D\). This proves nonattainment without invoking a sharpness construction or claiming an attained family minimum. \(\square\)

## Appendix: current formalization status and remaining verification links

**Sources:** paper Appendix D as corrected by audit §16; the later [LEAN_BUILD_VERIFICATION.md](Lean/LEAN_BUILD_VERIFICATION.md) is authoritative for current execution status.

The initial 30 September build report records `lake build` with exit 0 (2,972 jobs), and `lake build LeanProject.Stage11C` with exit 0 (2,970 jobs), using Lean **v4.34.1** and locked Mathlib revision `d13f23b723b8a846827a245b89c10fc7d3f11612`. Thus all 90 supplied project modules and the root module successfully compiled; `Stage11C` was then built separately. See [lean_build.log](Lean/lean_build.log) and [lean_extra_build.log](Lean/lean_extra_build.log). Later reduction-route updates and complete numerical certificates extend the root closure to 203 proof modules, including `Stage11C`. Current evidence and exact scope are recorded in audit §§18–26 and [cov-full-20261001/verification.json](audit_cert_runs/cov-full-20261001/verification.json).

The explicit axiom check in [AxiomAudit.lean](Lean/AxiomAudit.lean), recorded in [lean_axioms.log](Lean/lean_axioms.log), successfully checked these existing declarations, with dependencies `[propext, Classical.choice, Quot.sound]`:

| Built and explicitly axiom-checked statement | What it establishes under its declared hypotheses |
|---|---|
| `EP1038.sup_theorem` | The separate supremum bound and equality characterization |
| `EP1038.volume_bounds_1525` | The universal elementary lower bound \(61/40\), alongside the upper bound |
| `EP1038.Stage9.iInf_le_D` | The separate approximation direction \(\inf_f M(f)\le D\) |

Those initial checks did not include the strict lower theorem or nonattainment. Audit §26 now supplies and checks both complete declarations.

Other successfully built modules establish relevant statements with their declared hypotheses: [Atomize.lean](Lean/LeanProject/Atomize.lean), [Normalization.lean](Lean/LeanProject/Normalization.lean) and [Residual.lean](Lean/LeanProject/Residual.lean) cover reduction and elementary-width results; [CircRearr.lean](Lean/LeanProject/CircRearr.lean), `CircLog.lean` and the `ArcEnergy` modules develop circle rearrangement and arc energies; [BlockEnergy.lean](Lean/LeanProject/BlockEnergy.lean) establishes the angular block-energy inequality; [ScalarRed.lean](Lean/LeanProject/ScalarRed.lean) and [BlockRed.lean](Lean/LeanProject/BlockRed.lean) prove scalar and algebraic block reductions. Audit §21 now supplies their actual-block application links, including the mass/energy/radius identities; at that stage, certification of the specific reference rows and parameter predicates remained. Audit §26 now completes those certificates.

There are also **successfully built partial developments** relevant to this proof. [Stage10B1.lean](Lean/LeanProject/Stage10B1.lean) through [Stage10C13.lean](Lean/LeanProject/Stage10C13.lean) develop the inverse-series and convex-supporting arguments. [Stage10ComponentBridge.lean](Lean/LeanProject/Stage10ComponentBridge.lean) connects supporting inequalities to actual separated and atomic-contact component widths, with its positive first-atom hypothesis supplied by the normal form. Its `correctedNegSet` adds the point zero because Lean's totalized `Real.log 0 = 0` differs from the extended logarithm used here; that correction restores the intended component and does not change measure. At contact it isolates the main component before the critical zero rather than merging across it.

[Stage11A.lean](Lean/LeanProject/Stage11A.lean) and [Stage11B.lean](Lean/LeanProject/Stage11B.lean) prove cosine and transform computations; [Stage11C.lean](Lean/LeanProject/Stage11C.lean) adds polynomial and limit results with a Lipschitz condition in the cosine coordinate. The new [BernsteinLipschitz.lean](Lean/LeanProject/BernsteinLipschitz.lean) constructs the required common-bound approximants. [AdjointJump.lean](Lean/LeanProject/AdjointJump.lean), [AtomicAdjoint.lean](Lean/LeanProject/AtomicAdjoint.lean), and [AtomicVelocity.lean](Lean/LeanProject/AtomicVelocity.lean) prove integrability, positive-jump assembly, and the endpoint-corrected inequality for a finite angular step velocity. The exact jump equality used in §7 is now proved in `JumpAdjointEquality.lean` and applied to the actual quantile in `AtomicAdjointEquality.lean`; audit §29 records the new proof. Likewise supporting or rearrangement lemmas must be used with their exact hypotheses; compilation alone does not create a missing final theorem.

[AngleCDF.lean](Lean/LeanProject/AngleCDF.lean) now constructs the reference cumulative distribution and inverse quantile, with its integral law. [QuantileAngle.lean](Lean/LeanProject/QuantileAngle.lean) represents the actual residual quantile by finite nonnegative angular jumps, retaining repeated roots. [DerivativeDictionary.lean](Lean/LeanProject/DerivativeDictionary.lean) and [SupportingAdjoint.lean](Lean/LeanProject/SupportingAdjoint.lean) derive the endpoint Poisson parameters and positive slope coefficients from the separated reference and identify the existing `Stage10.Mdot` with `widthVariation`. [MaterialDictionary.lean](Lean/LeanProject/MaterialDictionary.lean) independently defines the static material difference-quotient expression of (7.2), proves its almost-everywhere identity with `HT F/r`, constructs the spatial adjoint measure and proves its integrable spatial integral equals `adjointIntegral`. The integrated `polynomial_material_reduction` supplies the supporting bound for every admissible polynomial conditional on a separated, platform-compatible reference. All 83 new proved declarations passed fresh axiom checks using only the standard logical axioms.

[ActualBlocks.lean](Lean/LeanProject/ActualBlocks.lean) constructs the actual fibers indexed by distinct original residual roots, proves their finite partition and exact multiplicity masses, positive auxiliary masses and residual-radius identity. [BlockLogKernel.lean](Lean/LeanProject/BlockLogKernel.lean) proves absolute joint logarithmic-kernel integrability. [ActualBlockEnergy.lean](Lean/LeanProject/ActualBlockEnergy.lean) proves the physical double-integral identity, ordinary Fubini, normalized rectangle bounds and application of the angular block-energy inequality. [ActualBlockMaterial.lean](Lean/LeanProject/ActualBlockMaterial.lean) proves the actual pointwise and integrated static material block lower bounds. [ActualBlockReduction.lean](Lean/LeanProject/ActualBlockReduction.lean) applies the algebraic strict reduction: an eligible reference and `ScalarPositive` at the calibrated effective constant imply `L<J≤M(f)`. It also connects finite scalar margins to that predicate and discharges the small-ratio branch `k≤29/20` with `J>2`. The universal `polynomial_certificate_reduction` leaves only `k>29/20` (hence `k≥36/25`) in the reference-certificate branch. All 87 new proved declarations passed fresh axiom checks using only the standard logical axioms; see audit §21.

[ReferenceSeparation.lean](Lean/LeanProject/ReferenceSeparation.lean) constructs the actual interval quantile and proves the positive exterior certificate identity `WS(k,T₀,x(v))=−(k+1)E(k,a,v)`, so a negative upper bound constructs the separated reference. [R1Reference.lean](Lean/LeanProject/R1Reference.lean) proves exact basic bounds and strict `(H1)` throughout R1, establishes nonnegative density, provides a uniform slab interface and applies the reference to the conditional strict normal-form bound. All 29 new proved declarations passed fresh axiom checks with dependencies contained in the three standard logical axioms; see audit §22. The full-row numerical upper bounds and scalar positivity are premises; §§23–24 supply both on the pilot slab.

[CertificateExterior.lean](Lean/LeanProject/CertificateExterior.lean) and [CertificateEndpoints.lean](Lean/LeanProject/CertificateEndpoints.lean) now prove the actual potential/slope dictionary on both exterior branches and identify certificate roots, rho/sigma coefficients and width with the actual reference. [R1Pilot.lean](Lean/LeanProject/R1Pilot.lean) and [R1PilotRoots.lean](Lean/LeanProject/R1PilotRoots.lean) prove an actual negative certificate and both actual endpoint-root boxes throughout the pilot slab `[1.8,1.8002]`, using kernel-checked rational logarithm series. All 72 new proved declarations passed fresh axiom checks; see audit §23. The next update discharges actual scalar positivity on this pilot slab.

[ScalarIntervals.lean](Lean/LeanProject/ScalarIntervals.lean), [R1PilotData.lean](Lean/LeanProject/R1PilotData.lean), [R1PilotActual.lean](Lean/LeanProject/R1PilotActual.lean), [ScalarPilotMargins.lean](Lean/LeanProject/ScalarPilotMargins.lean) and [R1PilotScalar.lean](Lean/LeanProject/R1PilotScalar.lean) complete the actual scalar certificate throughout k∈[1.8,1.8002]. For every L≤Lhi=18344304757628/10^13, the actual scalar expression exceeds 1/100 throughout its rectangle. The actual normal-form bound Lhi<J no longer assumes a numerical certificate. All 28 new proved declarations passed fresh axiom checks using only the standard logical axioms; see audit §24. The original diagonal-energy-tail and finite-partition strategy is certified with 64 rational enclosure steps and three exact Q cells. Candidate generation is not trusted as a proof premise.

[DWitnessData.lean](Lean/LeanProject/DWitnessData.lean), [DTargetComparison.lean](Lean/LeanProject/DTargetComparison.lean) and [ParameterCoverage.lean](Lean/LeanProject/ParameterCoverage.lean) add 45 proved declarations; see audit §25. An admissible one-cut-family witness with two strict rational log-certified root signs proves \(D<L_{\rm hi}<2\). This applies the actual pilot scalar certificate at D and proves pilot \(M(f)>D\) under the normal-form reduction hypotheses. Terminal admissibility, mass-ratio identity, Λ(q)≥D, exact overlap bounds, continuity and IVT prove that every k≥4.2 is represented by an admissible q∈(0,.042]. The full R1/R2/terminal geometric partition and pilot-complement split are proved. The numerical upper endpoint for D is now Lean verified; the lower endpoint remains open.

The four actual reference/scalar certificate statements are now proved by [CompleteCoverage.lean](Lean/LeanProject/CompleteCoverage.lean), as documented in audit §26. Exact certificates cover all of R1 and R2; terminal certificates combine five compact slabs with an analytic positive-q tail. [TerminalGeometry.lean](Lean/LeanProject/TerminalGeometry.lean) constructs the actual terminal reference dictionary, identifies its width with \(\Lambda(q)\), and proves its calibrated effective constant at D is nonpositive. Thus no reference, scalar-sign, width-identification or coverage premise remains.

`COV` proves actual reference/scalar certification for every required ratio. `universal_strict_lower` proves \(D<M(f)\) for every admissible polynomial; `universal_lower` and `lower_nonattainment` give the weak inequality and nonattainment. `exact_infimum_and_nonattainment` proves the official infimum equals D together with the official nonattainment statement. The root build and all 3,445 new axiom checks succeeded, using only the three standard logical axioms. See [verification.json](audit_cert_runs/cov-full-20261001/verification.json) and the [current dependency diagram](proof_diagrams/dependency-stage-29.png).

**Unresolved issues.** No analytic gap or missing formal implication remains in this strict lower-bound/nonattainment route. The separate numerical lower endpoint \(1.8344304757\le D\) remains unformalized. The original actual material derivative, both raw PV conventions and exact jump adjoint equality are now proved by the six modules added in audit §29. They are not hypotheses of the complete theorem. The numerical upper endpoint \(D<1.8344304757628\) is proved. External Python certificate suites and the original paper/registration files were not altered or used as trusted theorem premises by this completion.


### Completed original auxiliary statements 7–8

[MaterialDerivative.lean](Lean/LeanProject/MaterialDerivative.lean) and [ActualMaterialDerivative.lean](Lean/LeanProject/ActualMaterialDerivative.lean) prove the actual derivative of `WS(k,T_s,T_s(u))` at each interior point of the actual residual-root blocks. [PrincipalValue.lean](Lean/LeanProject/PrincipalValue.lean) proves both original raw PV conventions, including the literal cutoff integral against the spatial equilibrium measure. [MaterialFirstVariation.lean](Lean/LeanProject/MaterialFirstVariation.lean) assembles these statements and proves they hold almost everywhere under the actual adjoint measure. [JumpAdjointEquality.lean](Lean/LeanProject/JumpAdjointEquality.lean) uses a proved integrable joint majorant and DCT to retain exact equality. [AtomicAdjointEquality.lean](Lean/LeanProject/AtomicAdjointEquality.lean) gives the actual residual-quantile identity, with its endpoint correction.

All 69 added theorems passed axiom checks using only `propext`, `Classical.choice` and `Quot.sound`; the root build succeeded. See [audit §29](INFORMAL_AUDIT.md#29-actual-material-derivative-raw-pv-and-exact-jump-adjoint-equality-1-october-2026), [verification](audit_cert_runs/auxiliary78-20261001/verification.json) and [completed 7–8 dependency diagram](proof_diagrams/dependency-stage-29-auxiliary.png). The independent numerical lower endpoint for D remains open.

### Exact numerical-D cover completed (audit §30)

The three `DLower*` modules prove exact T/M/S coverage and actual-leaf membership of every admissible q, including arbitrarily small positive q. All 110 stored leaf endpoints are kernel checked; no stored numerical width bound is imported. The root build and 46 new axiom checks passed. See [audit §30](INFORMAL_AUDIT.md#30-integrated-current-status-after-exact-numerical-d-coverage-1-october-2026), [coverage proof](Lean/LeanProject/DLowerCoverage.lean), [verification](audit_cert_runs/d-lower-cover-20261001/verification.json) and [current diagram](proof_diagrams/dependency-stage-30.png). The T/S width bounds and central implicit-root/Taylor estimates still remain for the numerical lower endpoint.

### Completed numerical-D implication 5 → 6

[DLowerInfimum.lean](Lean/LeanProject/DLowerInfimum.lean) proves that statement 5, the actual uniform family lower bound, implies statement 6, the exact enclosure L≤D<U. Nonemptiness of the actual family and `le_csInf` transfer the lower bound to D; the existing certified witness supplies the strict upper endpoint. The region and actual-leaf consumer theorems keep numerical certificates 2 and 4 explicit. All 7 new theorems and the root build passed verification. See [audit §31](INFORMAL_AUDIT.md#31-completed-numerical-d-implication-5--6-1-october-2026), [verification](audit_cert_runs/d-infimum-transfer-20261001/verification.json) and [numerical dependency diagram](proof_diagrams/dependency-stage-31-infimum-transfer-numerical.png). Statements 5 and 6 remain conditional until their actual numerical inputs are proved.

### Actual numerical-D obligations 2 and 3 completed (audit §32)

The actual T/S family widths are now proved at least 1.8344304757 on all 95 leaves, with exact positive-tail coverage. The actual selected roots and volume width are C²; their genuine first/second derivatives equal cert3's implicit/width formulas. `actual_TS_width_lower` and `actual_central_root_calculus` have no unproved numeric/regularity input. The root build and all 1110 new axiom checks passed. See [audit §32](INFORMAL_AUDIT.md#32-obligations-2-and-3-completed-actual-ts-lower-bounds-and-central-root-calculus-1-october-2026) and [current numerical graph](proof_diagrams/dependency-stage-32-numerical.png). The sole remaining numerical input is **4, the actual M Taylor bound**. Both 4⇒5 and 4⇒6 assemblers are proved; the unconditional numeric lower bound on D still awaits 4.



### Actual central Taylor certificate and numerical D enclosure completed (audit §33)

[DLowerM.lean](Lean/LeanProject/DLowerM.lean) now proves every actual central M width at least 1.8344304757, with all 15 root-box, mean-value, derivative and Taylor certificates discharged in Lean. The original 15 exact leaves and second-order Taylor strategy are retained. `actual_numerical_family_lower` and `actual_numerical_D_enclosure` then prove, without certificate arguments, the actual full-family lower bound and **1.8344304757 ≤ D < 1.8344304757628**. All numbered obligations 1–8 in the recent remaining-work list are complete. The prior symbolic strict lower theorem, exact infimum and nonattainment are preserved. See [audit §33](INFORMAL_AUDIT.md#33-obligation-4-completed-actual-central-taylor-certificate-and-numerical-d-enclosure-1-october-2026), [verification](audit_cert_runs/d-lower4-20261001/verification.json) and the [completed numerical dependency graph](proof_diagrams/dependency-stage-33-numerical.png).
