# Erdős 1038 — Lean source package

This archive contains the complete current proof import closure, the completed
Formal Conjectures statement entrypoint, dependency pins and reproducibility checks.
There are **315 proof modules including the root**, plus `Lean/Verify.lean`.
All numerical certificates needed by the proof are Lean source; Python candidate
generation and historical experiment outputs are not required to compile it.

## Build

Requirements: an Elan/Lean installation, Python 3 and network access for the first
fetch of the pinned dependencies and mathlib cache. Lean is selected automatically
by `Lean/lean-toolchain`.

```sh
cd erdos1038-lean-20261001
sh scripts/build.sh
```

Equivalent Lean commands:

```sh
cd Lean
lake exe cache get
lake -q --log-level=error build LeanProject
lake env lean Verify.lean
```

Lean: `leanprover/lean4:v4.34.1`.
Mathlib: `d13f23b723b8a846827a245b89c10fc7d3f11612` (tag `v4.34.1`).
All nine dependency revisions are recorded in `Lean/lake-manifest.json`.
Keep that lockfile. `lake update` would change the environment being verified.
Dependencies and compiled `.olean`/`.lake` artifacts are fetched separately and are
not in this source archive.

## Statements

Read [Lean/LeanProject/Submission.lean](Lean/LeanProject/Submission.lean) first.
The following reference theorem names are available after `import LeanProject`:

| Reference | Completed theorem |
| --- | --- |
| Exact infimum, unknown answer filled by `ENNReal.ofReal Dval` | `Erdos1038.erdos_1038.parts.i` |
| Supremum | `Erdos1038.erdos_1038.parts.ii` |
| Infimum < 1.835 | `Erdos1038.erdos_1038.variants.inf_upperBound` |
| Classical infimum lower bound | `Erdos1038.erdos_1038.varaints.inf_lowerBound` |

The original unused `n : ℕ` and original `varaints` spelling are preserved.
Additional theorems give strict universal lower bounds, nonattainment, the upper
bound equality cases and the exact rational enclosure
`1.8344304757 ≤ D < 1.8344304757628`.
These decimals are bounds on D, not an exact replacement for D.

[STATEMENT_CORRESPONDENCE.md](STATEMENT_CORRESPONDENCE.md) explains the domains,
measure types, exact answer and the relation to the reference file.
[PROOF_GUIDE.md](PROOF_GUIDE.md) maps the final conclusions to their proof sources.

## Verification included in the archive

`verification/package_verification.json` records the build of the extracted source
archive. Its project `.lake/build` directory started empty; installed external
dependency checkouts and their pinned compiled caches were reused. Project proof
modules were compiled from the packaged source. This is not a claim that all of
mathlib was rebuilt or that an entirely offline machine needs no dependencies.

`Lean/Verify.lean` checks 18 final/reference/bridge statements. Their reported axiom
dependencies are checked against `propext`, `Classical.choice`, and `Quot.sound`.
`check_sources.py` also checks the import closure, source snapshot hashes, and absence
of `sorry`, `admit`, `sorryAx`, `native_decide` and explicit `axiom` declarations outside
comments/strings. This source scan supplements Lean checking.
`SOURCE_MANIFEST.json` contains payload SHA-256 checksums (excluding itself).

## Reference and historical documentation

`reference_statements/DeepMind_1038.lean` is an unchanged, uncompiled reference. Its
original `answer(sorry)` and unfinished reference proofs remain in that reference
file only. It is outside the Lean build root and is never imported.
The standalone project does not import `FormalConjecturesUtil`; its `category`,
`AMS`, `answer` and exposure metadata are not part of the exported theorem types.
Compilation in the upstream Formal Conjectures repository has not been performed.

The informal paper, audit and lower-bound notes are included as working-history
snapshots. Earlier sections record obligations that were later discharged. Some
links to old experiment outputs are outside this archive. The current Lean
entrypoint and package verification record govern the compiled result.
Stage-33 diagram snapshots are included in `proof_diagrams/`.

This package is a local, checked source artifact. OpenMath admission, the designated
AutoLab hill/checker, leaderboard submission and any upstream PR are separate steps.
See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for reference attribution.

## Documentation revision, 2026-10-03

The mathematical proof/configuration bytes remain identical to the original 2026-10-01 compiled archive. The paper’s provenance/comparison and completed formal-status appendix are updated. CONTRIBUTIONS.md and EXACT_STATEMENTS.md identify the provisional reusable M2 candidates. Original verification records refer to the original archive; the new packaging receipt identifies this revision. Run `lake env lean ../VerifyContributions.lean` from Lean/ for the additional 26 declaration/axiom checks. No official AutoLab registration or acceptance is asserted.
